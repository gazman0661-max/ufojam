#!/usr/bin/env python3
"""CI: AndroidIAPP eklentisini (yoksa) indirir, project.godot'a Billing autoload'unu ve
eklenti kaydını ekler. Eklenti repoda zaten varsa indirmeyi atlar, sadece kaydı tamamlar."""
import glob, io, json, os, re, shutil, sys, tempfile, urllib.request, zipfile

REPO = "code-with-max/godot-google-play-iapp"
PROJECT = "project.godot"


def http_get(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "ci"})
    tok = os.environ.get("GITHUB_TOKEN")
    if tok and "api.github.com" in url:
        req.add_header("Authorization", f"Bearer {tok}")
    with urllib.request.urlopen(req, timeout=120) as r:
        return r.read()


def find_gd():
    hits = glob.glob("addons/**/GooglePlayBilling.gd", recursive=True)
    return hits[0].replace("\\", "/") if hits else None


def download_plugin() -> None:
    url = os.environ.get("IAPP_URL", "").strip()
    if not url:
        rels = json.loads(http_get(f"https://api.github.com/repos/{REPO}/releases?per_page=15"))
        for rel in rels:
            if rel.get("draft") or rel.get("prerelease"):
                continue
            zips = [a for a in rel.get("assets", []) if a["name"].lower().endswith(".zip")]
            if zips:
                url = zips[0]["browser_download_url"]
                print(f"Eklenti sürümü: {rel.get('tag_name')} -> {zips[0]['name']}")
                break
    if not url:
        sys.exit("HATA: AndroidIAPP indirme linki bulunamadı. Workflow'daki IAPP_URL'ye zip linkini yaz "
                 "veya eklentiyi addons/ içine commit'le.")
    data = http_get(url)
    tmp = tempfile.mkdtemp()
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        z.extractall(tmp)
    # zip içinde addons/ varsa onu, yoksa GooglePlayBilling.gd'nin klasörünü kopyala
    src_addons = None
    for root, dirs, _ in os.walk(tmp):
        if "addons" in dirs:
            src_addons = os.path.join(root, "addons")
            break
    os.makedirs("addons", exist_ok=True)
    if src_addons:
        shutil.copytree(src_addons, "addons", dirs_exist_ok=True)
    else:
        gd = glob.glob(os.path.join(tmp, "**", "GooglePlayBilling.gd"), recursive=True)
        if not gd:
            sys.exit("HATA: indirilen zip içinde GooglePlayBilling.gd yok. Doğru eklenti zip'i mi?")
        shutil.copytree(os.path.dirname(gd[0]), "addons/AndroidIAPP", dirs_exist_ok=True)


def patch_project(gd_path: str) -> None:
    top = gd_path.split("/")[1]
    cfgs = sorted(glob.glob(f"addons/{top}/**/plugin.cfg", recursive=True))
    text = open(PROJECT, encoding="utf-8").read()

    if re.search(r"^Billing\s*=", text, re.M) is None:
        line = f'Billing="*res://{gd_path}"'
        if re.search(r"^IAP\s*=.*$", text, re.M):
            text = re.sub(r"^(IAP\s*=.*)$", lambda m: m.group(1) + "\n" + line, text, count=1, flags=re.M)
        elif "[autoload]" in text:
            text = text.replace("[autoload]", "[autoload]\n\n" + line, 1)
        else:
            text += "\n[autoload]\n\n" + line + "\n"
        print("Billing autoload eklendi:", line)

    if cfgs:
        cfg = f"res://{cfgs[0]}"
        m = re.search(r"^enabled\s*=\s*PackedStringArray\((.*)\)\s*$", text, re.M)
        if m and "[editor_plugins]" in text:
            if cfg not in m.group(1):
                inner = m.group(1).strip()
                new_inner = (inner + ", " if inner else "") + f'"{cfg}"'
                text = text[:m.start()] + f"enabled=PackedStringArray({new_inner})" + text[m.end():]
                print("Eklenti etkinleştirildi:", cfg)
        else:
            text += f'\n[editor_plugins]\n\nenabled=PackedStringArray("{cfg}")\n'
            print("Eklenti etkinleştirildi:", cfg)
    else:
        print("UYARI: plugin.cfg bulunamadı; eklenti editor_plugins'e eklenemedi.")

    open(PROJECT, "w", encoding="utf-8").write(text)


def main() -> None:
    gd = find_gd()
    if gd is None:
        print("Eklenti repoda yok, indiriliyor...")
        download_plugin()
        gd = find_gd()
    if gd is None:
        sys.exit("HATA: GooglePlayBilling.gd hâlâ bulunamadı.")
    print("Eklenti:", gd)
    patch_project(gd)


if __name__ == "__main__":
    main()
