# UFO Bus Jam — Godot 4.3 (GDScript) portu

Flutter projesinin Godot karşılığı. Açmak için: Godot 4.3+ → Import → bu klasördeki `project.godot`.
İlk açılışta Godot görselleri/sesleri kendisi içe aktarır (1-2 dk sürebilir). Sonra F5.

## Dosya haritası (Dart → GDScript)
| Dart | Godot |
|---|---|
| game/models.dart | scripts/models.gd |
| game/geometry.dart | scripts/geo.gd |
| game/rules.dart | scripts/rules.gd |
| game/engine.dart | scripts/game_state.gd |
| game/level_repo.dart + level_data/stage_extras/ring_data/*_order | scripts/level_repo.gd, stage_data.gd + data/levels.json (otomatik dönüştürüldü) |
| ui/ring_shapes.dart | data/levels.json ("shapes") |
| ui/game_screen.dart | scripts/game_screen.gd |
| ui/game_popup.dart | scripts/popup.gd |
| ui/panel_ui.dart, settings_screen.dart | scripts/panel_ui.gd, settings_screen.gd, info_screen.gd |
| ui/home_screen / splash_screen / win_overlay / legal_dialog | home.gd / splash.gd / win_overlay.gd / legal_dialog.gd |
| progress/settings/stats/audio/legal/l10n | autoload: progress.gd, settings.gd, stats.gd, audio.gd, legal.gd, l10n.gd |

## Bilinen farklar / dürüst notlar
- Bu port Godot çalıştırılamadan yazıldı (test edilmedi). İlk açılışta küçük sözdizimi/çalışma hatası çıkabilir; Godot hata satırını gösterir.
- Mantık (motor, kurallar, geometri, seviye üretimi, veri) birebir aynıdır. Çarpışma sonuçları sadece hız için önbelleğe alınır (sonuç aynı).
- Çizim Flutter widget'ları yerine `_draw()` ile yapılır; yerleşim formülleri aynı ama piksel düzeyinde küçük farklar olabilir (yazı tipi Godot varsayılanı, Material ikonlar vektörle çizildi, bulanık gölgeler katmanlı yaklaşık).
- Reklam: Dart sürümündeki gibi demo (izle = hemen ödül).
- Seviye 1000+ ve 292 stage verisi `data/levels.json` içinde; `convert_data.py` ile yeniden üretilebilir.
