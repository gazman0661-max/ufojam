class_name PanelUI
extends RefCounted
# panel_ui.dart karşılığı: PanelScreen (kurdele başlık + koyu panel), GlossyButton, PanelSection, PanelText.

static func panel_bg() -> Color:
	return UI.argb(0xFF1A1040)
static func section_color() -> Color:
	return UI.argb(0xFFC9B3FF)

# ---------------------------------------------------------------- Parlak düğme
class GlossyButton extends Control:
	signal pressed
	var label := ""
	var icon := ""          # "grid", "lang", "help", "stats", "shield", ""
	var checked = null       # null: onay kutusu yok
	var orange := false
	var btn_h := 64.0
	var _down := false

	func _init(p_label: String, p_icon: String = "", p_checked = null, p_orange: bool = false, p_h: float = 64.0) -> void:
		label = p_label
		icon = p_icon
		checked = p_checked
		orange = p_orange
		btn_h = p_h
		custom_minimum_size = Vector2(0, p_h)
		mouse_filter = Control.MOUSE_FILTER_PASS

	func _gui_input(e: InputEvent) -> void:
		if (e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT) or e is InputEventScreenTouch:
			if e.pressed:
				_down = true
			else:
				if _down and Rect2(Vector2.ZERO, size).has_point(e.position):
					pressed.emit()
				_down = false
			queue_redraw()

	func _draw() -> void:
		var c0 := UI.argb(0xFFFFA84D) if orange else UI.argb(0xFFB089FF)
		var c1 := UI.argb(0xFFFF7A00) if orange else UI.argb(0xFF6A3BFF)
		var edge := UI.argb(0xFFB34A00) if orange else UI.argb(0xFF2F1C9A)
		var sc := 0.97 if _down else 1.0
		var r := Rect2(Vector2.ZERO, Vector2(size.x, btn_h - 5.0))
		var rr := Rect2(r.get_center() - r.size * sc / 2.0, r.size * sc)
		UI.fill_rrect(self, Rect2(rr.position + Vector2(0, 5), rr.size), rr.size.y / 2.0, edge)
		UI.grad_rrect_v(self, rr, rr.size.y / 2.0, c0, c1)
		UI.stroke_rrect(self, rr, rr.size.y / 2.0, Color(1, 1, 1, 0.65), 2.0)
		var pts := UI.rrect_pts(Rect2(rr.position, Vector2(rr.size.x, rr.size.y * 0.5)), rr.size.y / 2.0)
		var cols := PackedColorArray()
		for p in pts:
			cols.append(Color(1, 1, 1, lerpf(0.35, 0.04, clampf((p.y - rr.position.y) / (rr.size.y * 0.5), 0, 1))))
		draw_polygon(pts, cols)
		var lines := label.split("\n")
		var fs := 20.0 if lines.size() == 1 else 19.0
		var cx := rr.get_center().x
		var cy := rr.get_center().y
		var left_pad := 0.0
		if checked != null:
			var bx := Rect2(rr.position.x + 18, cy - 15, 30, 30)
			UI.fill_rrect(self, bx, 8, Color(0, 0, 0, 0.3))
			UI.stroke_rrect(self, bx, 8, Color(1, 1, 1, 0.8), 2.0)
			if checked:
				draw_polyline(PackedVector2Array([bx.position + Vector2(7, 15), bx.position + Vector2(13, 21), bx.position + Vector2(24, 9)]), Color(0.49, 0.89, 0.55), 4.0, true)
			left_pad = 24.0
		elif icon != "":
			var ic := Vector2(rr.position.x + 34, cy)
			draw_circle(ic, 15, Color(1, 1, 1, 0.9))
			draw_circle(ic, 9, c1)
			left_pad = 20.0
		for i in lines.size():
			var lh := fs * 1.2
			var yy := cy - lines.size() * lh / 2.0 + i * lh
			UI.text_c(self, Rect2(rr.position.x + left_pad, yy, rr.size.x, lh), lines[i], fs, Color.WHITE, true, Color(0, 0, 0, 0.45))

# ---------------------------------------------------------------- Bölüm başlığı / yazı
class PanelSection extends Control:
	var text := ""
	func _init(t: String) -> void:
		text = t
		custom_minimum_size = Vector2(0, 24 + 12 + 18)
	func _draw() -> void:
		UI.text_c(self, Rect2(0, 24, size.x, 18), text, 15, PanelUI.section_color())

class PanelText extends Control:
	var text := ""
	var heading := false
	func _init(t: String, h: bool = false) -> void:
		text = t
		heading = h
	func _fs() -> float:
		return 18.0 if heading else 15.5
	func _lines() -> Array:
		return UI.wrap(text, _fs(), maxf(size.x, 200.0), heading)
	func _ready() -> void:
		resized.connect(_upd)
		_upd()
	func _upd() -> void:
		var n := _lines().size()
		custom_minimum_size = Vector2(0, n * _fs() * 1.4 + (14 if heading else 6))
		queue_redraw()
	func _draw() -> void:
		var y := 8.0 if heading else 0.0
		for ln in _lines():
			var col := Color.WHITE if heading else Color(1, 1, 1, 0.8)
			UI.text_tl(self, Vector2(0, y), ln, _fs(), col, heading)
			y += _fs() * 1.4

class PanelGap extends Control:
	func _init(h: float = 12.0) -> void:
		custom_minimum_size = Vector2(0, h)

# ---------------------------------------------------------------- Panel ekranı
class PanelScreen extends Control:
	var title := ""
	var vbox: VBoxContainer
	var scroll: ScrollContainer

	func _init(p_title: String) -> void:
		title = p_title

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_STOP
		scroll = ScrollContainer.new()
		scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		add_child(scroll)
		var m := MarginContainer.new()
		m.add_theme_constant_override("margin_left", 18)
		m.add_theme_constant_override("margin_right", 18)
		m.add_theme_constant_override("margin_top", 20)
		m.add_theme_constant_override("margin_bottom", 30)
		m.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		scroll.add_child(m)
		vbox = VBoxContainer.new()
		vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		vbox.add_theme_constant_override("separation", 0)
		m.add_child(vbox)
		resized.connect(_layout)
		L.changed.connect(queue_redraw)
		_layout()

	func _top() -> float:
		return _safe_top()

	func _safe_top() -> float:
		var sa := DisplayServer.get_display_safe_area()
		var win := DisplayServer.window_get_size()
		if win.y <= 0:
			return 0.0
		return maxf(0.0, sa.position.y * size.y / win.y)

	func _layout() -> void:
		if scroll == null:
			return
		var t := _top()
		scroll.position = Vector2(0, t + 88)
		scroll.size = Vector2(size.x, size.y - t - 88)

	func add_item(c: Control) -> void:
		vbox.add_child(c)

	func on_back() -> void:
		Nav.pop()

	var _back_down := false
	func _gui_input(e: InputEvent) -> void:
		if (e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT) or e is InputEventScreenTouch:
			var br := Rect2(14, _top() + 18, 52, 52)
			if e.pressed:
				_back_down = br.has_point(e.position)
			else:
				if _back_down and br.has_point(e.position):
					Nav.pop()
				_back_down = false

	func _draw() -> void:
		var W := size.x
		var H := size.y
		var t := _top()
		UI.draw_cover(self, UI.tex("bg_station"), Rect2(Vector2.ZERO, size))
		draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 140.0 / 255.0))
		# panel
		var pr := Rect2(0, t + 88, W, H - t - 88 + 40)
		UI.shadow_rrect(self, pr, 36, Color(0.49, 0.3, 1.0, 0.53), 20.0, Vector2.ZERO, -4.0)
		UI.fill_rrect(self, pr, 36, UI.with_a(PanelUI.panel_bg(), 238))
		UI.stroke_rrect(self, pr, 36, Color(1, 1, 1, 45.0 / 255.0), 1.5)
		# geri düğmesi
		var bc := Vector2(14 + 26, t + 18 + 26)
		draw_circle(bc + Vector2(0, 3), 26, Color(0, 0, 0, 0.5))
		draw_circle(bc, 26, UI.with_a(UI.argb(0xFF2A1466), 230))
		draw_arc(bc, 25, 0, TAU, 40, Color(1, 1, 1, 170.0 / 255.0), 2.5, true)
		UI.icon_arrow_back(self, bc, 52, Color.WHITE)
		# kurdele
		_ribbon(Rect2((W - 260) / 2.0, t + 6, 260, 76))

	func _ribbon(r: Rect2) -> void:
		var w := r.size.x
		var h := r.size.y
		var tail_w := w * 0.18
		var tail_top := h * 0.20
		var tail_bot := h * 0.98
		var body_top := h * 0.03
		var body_bot := h * 0.82
		var o := r.position
		var edge := Color(1, 1, 1, 215.0 / 255.0)
		var left := PackedVector2Array([o + Vector2(0, tail_top), o + Vector2(tail_w + 6, tail_top), o + Vector2(tail_w + 6, tail_bot), o + Vector2(0, tail_bot), o + Vector2(tail_w * 0.38, (tail_top + tail_bot) / 2)])
		var right := PackedVector2Array([o + Vector2(w, tail_top), o + Vector2(w - tail_w - 6, tail_top), o + Vector2(w - tail_w - 6, tail_bot), o + Vector2(w, tail_bot), o + Vector2(w - tail_w * 0.38, (tail_top + tail_bot) / 2)])
		for poly: PackedVector2Array in [left, right]:
			var cols := PackedColorArray()
			for p in poly:
				cols.append(UI.argb(0xFF5B2FD6).lerp(UI.argb(0xFF34188F), clampf((p.y - o.y - tail_top) / (tail_bot - tail_top), 0, 1)))
			draw_polygon(poly, cols)
			var cl := poly.duplicate()
			cl.append(poly[0])
			draw_polyline(cl, edge, 2.5, true)
		var body := Rect2(o + Vector2(tail_w * 0.75, body_top), Vector2(w - tail_w * 1.5, body_bot - body_top))
		UI.shadow_rrect(self, body, 14, Color(0, 0, 0, 0.5), 6.0)
		var pts := UI.rrect_pts(body, 14)
		var cols2 := PackedColorArray()
		for p in pts:
			var tt := clampf((p.y - body.position.y) / body.size.y, 0, 1)
			if tt < 0.5:
				cols2.append(UI.argb(0xFFB089FF).lerp(UI.argb(0xFF7C4DFF), tt * 2))
			else:
				cols2.append(UI.argb(0xFF7C4DFF).lerp(UI.argb(0xFF5A2BD6), (tt - 0.5) * 2))
		draw_polygon(pts, cols2)
		UI.stroke_rrect(self, body, 14, edge, 2.5)
		UI.text_c(self, Rect2(o.x + 34, o.y, w - 68, h - 10), title, 26, Color.WHITE, true, UI.argb(0xFF2A1466))
