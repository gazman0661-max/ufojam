class_name LegalDialog
extends Control
# legal_dialog.dart karşılığı: ilk açılış Kullanım Şartları + Gizlilik onayı.

signal decided(ok)
var _rects := {}
var _down := ""

static func show_consent(parent: Node) -> bool:
	var d := LegalDialog.new()
	d.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	parent.add_child(d)
	var ok = await d.decided
	d.queue_free()
	if ok:
		Legal.accept()
		return true
	Legal.quit_game()
	return false

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	z_index = 200
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS

func _gui_input(e: InputEvent) -> void:
	accept_event()
	if not ((e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT) or e is InputEventScreenTouch):
		return
	var hit := ""
	for k in _rects:
		if (_rects[k] as Rect2).has_point(e.position):
			hit = k
	if e.pressed:
		_down = hit
		queue_redraw()
	else:
		if hit != "" and hit == _down:
			Audio.play(Audio.Sfx.CLICK)
			match hit:
				"terms": _read(L.t("Kullanım Şartları", "Terms of Use"), Legal.terms_url(), Legal.terms_text())
				"privacy": _read(L.t("Gizlilik Politikası", "Privacy Policy"), Legal.privacy_url(), Legal.privacy_text())
				"accept": decided.emit(true)
				"reject": decided.emit(false)
		_down = ""
		queue_redraw()

func _read(title: String, url: String, sections: Array) -> void:
	if Legal.open_url(url):
		return
	var info = load("res://scripts/settings_screen.gd").make_info(title, sections)
	Nav.push(info)

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 175.0 / 255.0))
	var W := size.x
	var cw := minf(420.0, W - 36.0)
	var h := 20 + 84 + 8 + 36 + 10 + 4 * 21.7 + 16 + 3 * 52 + 20 + 60 + 12 + 50 + 10 + 3 * 17 + 20
	var r := Rect2((W - cw) / 2.0, (size.y - h) / 2.0, cw, h)
	_rects.clear()
	UI.shadow_rrect(self, r, 30, Color(0.49, 0.3, 1.0, 0.53), 28.0, Vector2.ZERO, -4.0)
	UI.grad_rrect_v(self, r, 30, UI.argb(0xFF2A1466), PanelUI.panel_bg())
	UI.stroke_rrect(self, r, 30, Color(1, 1, 1, 70.0 / 255.0), 1.5)
	var y := r.position.y + 20
	UI.draw_contain(self, UI.tex("ufo10_blue"), Rect2(r.position.x, y, r.size.x, 84))
	y += 92
	UI.text_c(self, Rect2(r.position.x, y, r.size.x, 36), L.t("Hoş Geldin!", "Welcome!"), 30, Color.WHITE, true, UI.argb(0xFF2A1466))
	y += 46
	var msg := L.t("Oynamaya başlamadan önce Kullanım Şartları'nı ve Gizlilik Politikası'nı okuyup kabul etmen gerekiyor.",
		"Before you start playing, you need to read and accept the Terms of Use and the Privacy Policy.")
	for ln in UI.wrap(msg, 15.5, r.size.x - 40, false):
		UI.text_c(self, Rect2(r.position.x + 20, y, r.size.x - 40, 21.7), ln, 15.5, Color(1, 1, 1, 220.0 / 255.0), false)
		y += 21.7
	y += 16
	for key in ["terms", "privacy"]:
		var lab := L.t("Kullanım Şartları", "Terms of Use") if key == "terms" else L.t("Gizlilik Politikası", "Privacy Policy")
		var tr := Rect2(r.position.x + 20, y, r.size.x - 40, 52)
		_rects[key] = tr
		UI.fill_rrect(self, tr, 18, Color(1, 1, 1, 22.0 / 255.0))
		UI.stroke_rrect(self, tr, 18, Color(1, 1, 1, 55.0 / 255.0), 1.2)
		draw_circle(tr.position + Vector2(26, 26), 12, PanelUI.section_color())
		UI.text_tl(self, tr.position + Vector2(52, 16), lab, 17, Color.WHITE, true)
		UI.text_tl(self, Vector2(tr.end.x - 74, tr.position.y + 18), L.t("Oku", "Read"), 14, UI.with_a(PanelUI.section_color(), 220), true)
		y += 62
	y += 8
	# kabul
	var ab := Rect2(r.position.x + 20, y, r.size.x - 40, 60)
	_rects["accept"] = ab
	UI.fill_rrect(self, Rect2(ab.position + Vector2(0, 5), ab.size - Vector2(0, 5)), 27, UI.argb(0xFF2F1C9A))
	UI.grad_rrect_v(self, Rect2(ab.position, ab.size - Vector2(0, 5)), 27, UI.argb(0xFFB089FF), UI.argb(0xFF6A3BFF))
	UI.stroke_rrect(self, Rect2(ab.position, ab.size - Vector2(0, 5)), 27, Color(1, 1, 1, 0.65), 2.0)
	UI.text_c(self, Rect2(ab.position, ab.size - Vector2(0, 5)), L.t("Kabul Et", "Accept"), 20, Color.WHITE, true, Color(0, 0, 0, 0.45))
	y += 72
	var rb := Rect2(r.position.x + 20, y, r.size.x - 40, 50)
	_rects["reject"] = rb
	UI.fill_rrect(self, rb, 25, UI.with_a(UI.argb(0xFF2A1466), 200))
	UI.stroke_rrect(self, rb, 25, Color(1, 1, 1, 110.0 / 255.0), 2.0)
	UI.text_c(self, rb, L.t("Reddet", "Decline"), 17, Color.WHITE, true)
	y += 60
	var note := L.t("Kabul Et'e dokunarak her ikisini de kabul etmiş olursun. Reddedersen oyun kapanır.",
		"By tapping Accept, you accept both of them. If you decline, the game will close.")
	for ln in UI.wrap(note, 12.5, r.size.x - 40, false):
		UI.text_c(self, Rect2(r.position.x + 20, y, r.size.x - 40, 17), ln, 12.5, Color(1, 1, 1, 140.0 / 255.0), false)
		y += 17
