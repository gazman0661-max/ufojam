class_name WinOverlay
extends Control
# win_overlay.dart karşılığı: kutlama ekranı (havai fişek, coin yığını, x2 coin, Sonraki).

signal next_pressed
signal menu_pressed
signal double_pressed

var level_number := 1
var reward := 20
var doubled := false
var _t := 0.0
var _bursts: Array = []
var _flyers: Array = []
var _next_burst := 0.15
var _next_flyer := 0.6
var _hero_color := 2
var _hero_ufo := 1
var _rng := RandomNumberGenerator.new()
var _rects := {}
var _down := ""
const NAMES := ["red", "blue", "green", "yellow", "purple", "orange", "pink", "lightblue", "white", "black", "brown", "lime", "teal", "maroon", "navy"]
var COLS: Array = []

func _ready() -> void:
	z_index = 50
	mouse_filter = Control.MOUSE_FILTER_STOP
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	_rng.randomize()
	for v in [0xFFE53935, 0xFF3F6FFF, 0xFF43C443, 0xFFFFD600, 0xFF9C4DFF, 0xFFFF8F00, 0xFFFF6FB0, 0xFF5CC8FF, 0xFFF2F2F2, 0xFF8D5A3C, 0xFFB4E33D, 0xFF26C6A6]:
		COLS.append(UI.argb(v))
	_hero_color = _rng.randi() % COLS.size()
	_hero_ufo = (_hero_color + 1 + _rng.randi() % (COLS.size() - 1)) % COLS.size()
	get_tree().create_timer(0.9).timeout.connect(func():
		if is_inside_tree():
			Audio.play(Audio.Sfx.COIN))
	set_process(true)

func _process(d: float) -> void:
	_t += d
	while Settings.screen_fx and _t >= _next_burst:
		var n := 2 if _rng.randf() < 0.3 else 1
		for i in n:
			var base: Color = COLS[_rng.randi() % COLS.size()]
			var pal := [base, COLS[_rng.randi() % COLS.size()], Color.WHITE, UI.argb(0xFFFFE066)]
			_bursts.append({"t0": _next_burst + i * 0.08, "pos": Vector2(0.08 + _rng.randf() * 0.84, 0.05 + _rng.randf() * 0.5),
				"pal": pal, "petals": 10 + _rng.randi() % 8, "size": 0.16 + _rng.randf() * 0.16, "rot": _rng.randf() * PI})
		_next_burst += 0.22 + _rng.randf() * 0.2
	while _t >= _next_flyer:
		_flyers.append({"t0": _next_flyer, "dur": 2.2 + _rng.randf() * 1.2, "y": 0.06 + _rng.randf() * 0.5,
			"ltr": _rng.randi() % 2 == 0, "color": _rng.randi() % COLS.size(), "size": 0.13 + _rng.randf() * 0.07, "wob": _rng.randf() * 6.28})
		_next_flyer += 1.1 + _rng.randf() * 1.4
	_bursts = _bursts.filter(func(b): return _t - b["t0"] <= 1.6)
	_flyers = _flyers.filter(func(f): return _t - f["t0"] <= f["dur"] + 0.2)
	queue_redraw()

func _gui_input(e: InputEvent) -> void:
	accept_event()
	if not ((e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT) or e is InputEventScreenTouch):
		return
	var hit := ""
	for k in _rects:
		if (_rects[k] as Rect2).has_point(e.position):
			hit = k
	if e.pressed:
		_down = hit
	else:
		if hit != "" and hit == _down:
			match hit:
				"next": next_pressed.emit()
				"menu": menu_pressed.emit()
				"double": if not doubled: double_pressed.emit()
		_down = ""

func _pop(t0: float, l: float) -> float:
	return clampf((_t - t0) / l, 0.0, 1.0)

func _elastic(x: float) -> float:
	if x <= 0.0: return 0.0
	if x >= 1.0: return 1.0
	return pow(2.0, -10.0 * x) * sin((x - 0.1) * TAU / 0.4) + 1.0

func _back(x: float) -> float:
	var c1 := 1.70158
	var c3 := c1 + 1.0
	return 1.0 + c3 * pow(x - 1.0, 3.0) + c1 * pow(x - 1.0, 2.0)

func _draw() -> void:
	var w := size.x
	var h := size.y
	var fade := _pop(0, 0.35)
	var hero_in := _elastic(_pop(0.1, 0.9))
	var banner_in := _elastic(_pop(0.35, 0.9))
	var coin_in := _back(_pop(0.8, 0.5))
	var btn_in := _back(_pop(1.1, 0.5))
	var bob := sin(_t * 2.4) * 6.0
	var jump := absf(sin(_t * 5.0)) * 14.0
	var beam_pulse := 0.7 + 0.3 * sin(_t * 4.0)
	var btn_pulse := 1.0 + 0.04 * sin(_t * 5.0)
	var ufo_w := w * 0.62
	var ufo_top := h * 0.10
	var alien_h := w * 0.34
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.62 * fade))
	_fireworks(w, h)
	for f in _flyers:
		_flyer(f, w, h)
	# ana UFO
	var uc := Vector2(w / 2.0, ufo_top + bob + ufo_w * 233.0 / 256.0 / 2.0)
	draw_set_transform(uc, 0.0, Vector2.ONE * hero_in)
	var uh := ufo_w * 233.0 / 256.0
	UI.draw_contain(self, UI.tex("ufo10_" + NAMES[_hero_ufo]), Rect2(Vector2(-ufo_w / 2.0, -uh / 2.0), Vector2(ufo_w, uh)))
	var bw := ufo_w * 0.62
	var bh := alien_h * 1.25
	var bx := -bw / 2.0
	var by := uh / 2.0 - ufo_w * 0.10
	draw_texture_rect(UI.tex("beam"), Rect2(bx, by, bw, bh), false, Color(1, 1, 1, 0.85 * beam_pulse))
	var ah := alien_h
	var at := UI.tex("alien_" + NAMES[_hero_color])
	var aw := ah * at.get_size().x / at.get_size().y
	draw_set_transform(uc + Vector2(0, (by + bh - ah / 2.0) * hero_in - jump * hero_in), sin(_t * 5.0) * 0.08, Vector2.ONE * hero_in)
	draw_texture_rect(at, Rect2(Vector2(-aw / 2.0, -ah / 2.0), Vector2(aw, ah)), false, Color(1, 1, 1, 0.85 * beam_pulse + 0.15))
	draw_set_transform_matrix(Transform2D.IDENTITY)
	# afiş
	var fs := minf(w * 0.17, 76.0)
	draw_set_transform(Vector2(w / 2.0, h * 0.43 + fs / 2.0 + 10), 0.0, Vector2.ONE * banner_in)
	var tr := Rect2(-w / 2.0, -fs / 2.0, w, fs)
	var s := L.t("HARİKA!", "AWESOME!")
	UI.text_outlined_c(self, tr, s, fs, UI.argb(0xFFFFC107), UI.argb(0xFF29B6F6), fs * 0.34)
	UI.text_outlined_c(self, tr, s, fs, UI.argb(0xFFFFD54F), UI.argb(0xFF1A237E), fs * 0.2)
	UI.text_c(self, Rect2(-w / 2.0, fs / 2.0, w, 24), L.t("Seviye %d tamam" % level_number, "Level %d complete" % level_number), 17, Color.WHITE, true, Color(0, 0, 0, 0.7))
	draw_set_transform_matrix(Transform2D.IDENTITY)
	# coin yığını
	var amount := reward * 2 if doubled else reward
	var cw := w * 0.34 * 0.34
	var cy := h * 0.55 + w * 0.34 * 0.31
	draw_set_transform(Vector2(w / 2.0, cy), 0.0, Vector2.ONE * coin_in)
	var spots := [Vector2(-cw * 0.95, cw * 0.55), Vector2(0, cw * 0.62), Vector2(cw * 0.95, cw * 0.55), Vector2(-cw * 0.5, cw * 0.18), Vector2(cw * 0.5, cw * 0.18), Vector2(0, -cw * 0.2)]
	for i in spots.size():
		var sc := 1.0 + 0.04 * sin(_t * 4 + i)
		var cs: float = cw * sc
		draw_texture_rect(UI.tex("coin"), Rect2(spots[i] - Vector2(cs, cs) / 2.0, Vector2(cs, cs)), false)
	var ctxt := "+%d" % amount
	var cr := Rect2(-w / 2.0, w * 0.34 * 0.31 - 30, w, 34)
	UI.text_outlined_c(self, cr, ctxt, 30, Color.WHITE, UI.argb(0xFF3E2723), 6)
	draw_set_transform_matrix(Transform2D.IDENTITY)
	_rects.clear()
	# x2 coin
	if not doubled:
		var lab := L.t("x2 COIN", "x2 COINS")
		var lw := UI.text_width(lab, 20, true) + 30 + 44
		var r := Rect2((w - lw) / 2.0, h * 0.665, lw, 44)
		_rects["double"] = r
		var a := clampf(btn_in, 0, 1)
		UI.shadow_rrect(self, r, 14, Color(0, 0, 0, 0.54 * a), 10.0, Vector2(0, 5))
		UI.grad_rrect_v(self, r, 14, Color(0.26, 0.77, 0.26, a), Color(0.18, 0.62, 0.31, a))
		UI.stroke_rrect(self, r, 14, Color(0.1, 0.42, 0.2, a), 3.0)
		UI.icon_video(self, Vector2(r.position.x + 33, r.get_center().y), 22, Color(1, 1, 1, a))
		UI.text_c(self, Rect2(r.position.x + 48, r.position.y, lw - 48, 44), lab, 20, Color(1, 1, 1, a), true)
	# Sonraki
	var nlab := L.t("Sonraki", "Next")
	var nw := UI.text_width(nlab, 26, true) + 92
	var nb := Rect2((w - nw) / 2.0, h * 0.76, nw, 56)
	_rects["next"] = nb
	var sc2 := btn_in * btn_pulse
	draw_set_transform(nb.get_center(), 0.0, Vector2.ONE * sc2)
	var lr := Rect2(-nb.size / 2.0, nb.size)
	UI.fill_rrect(self, Rect2(lr.position + Vector2(0, 5), lr.size), 16, UI.argb(0xFFBF360C))
	UI.shadow_rrect(self, lr, 16, Color(0, 0, 0, 0.54), 14.0, Vector2(0, 8))
	UI.grad_rrect_v(self, lr, 16, UI.argb(0xFFFFB300), UI.argb(0xFFFF8F00))
	UI.stroke_rrect(self, lr, 16, UI.argb(0xFFE65100), 3.0)
	UI.text_c(self, lr, nlab, 26, Color.WHITE, true, UI.argb(0xFF8D3A00))
	draw_set_transform_matrix(Transform2D.IDENTITY)
	var mlab := L.t("Menü", "Menu")
	var mr := Rect2((w - 100) / 2.0, h * 0.76 + 70, 100, 40)
	_rects["menu"] = mr
	UI.text_c(self, mr, mlab, 14, Color(1, 1, 1, 0.7 * clampf(btn_in, 0, 1)), true)

func _flyer(f: Dictionary, w: float, h: float) -> void:
	var p := clampf((_t - f["t0"]) / f["dur"], 0.0, 1.0)
	var fw: float = w * f["size"]
	var x: float = (-fw + (w + fw * 2) * p) if f["ltr"] else (w + fw - (w + fw * 2) * p)
	var y: float = h * f["y"] + sin(_t * 3 + f["wob"]) * 10.0
	var col: Color = COLS[f["color"]]
	var fh := fw * 170.0 / 256.0
	var c := Vector2(x, y + fh / 2.0)
	draw_texture_rect(UI.radial_tex(), Rect2(c - Vector2(fw, fw) * 0.8, Vector2(fw, fw) * 1.6), false, Color(col.r, col.g, col.b, 0.55))
	draw_set_transform(c, (1 if f["ltr"] else -1) * 0.12, Vector2.ONE)
	UI.draw_contain(self, UI.tex("ufo4_" + NAMES[f["color"]]), Rect2(Vector2(-fw / 2.0, -fh / 2.0), Vector2(fw, fh)))
	draw_set_transform_matrix(Transform2D.IDENTITY)

func _fireworks(w: float, h: float) -> void:
	for b in _bursts:
		var age: float = _t - b["t0"]
		if age < 0:
			continue
		var life := clampf(age / 1.4, 0.0, 1.0)
		var center := Vector2(b["pos"].x * w, b["pos"].y * h)
		var max_r: float = b["size"] * w
		if age < 0.25:
			var f := age / 0.25
			draw_circle(center, max_r * 0.5 * (0.5 + f * 0.5), Color(1, 1, 1, 0.28 * (1 - f)))
		var out := 1.0 - pow(1.0 - life, 3.0)
		var alpha := clampf(1.0 - life * life, 0.0, 1.0)
		var petals: int = b["petals"]
		for i in petals:
			var ang: float = b["rot"] + i * (TAU / petals)
			var col: Color = b["pal"][i % b["pal"].size()]
			var dir := Vector2(cos(ang), sin(ang))
			var a := center + dir * max_r * out * 0.55
			var z := center + dir * max_r * out
			draw_line(a, z, Color(col.r, col.g, col.b, alpha), clampf(6 - 4 * life, 1.5, 6.0), true)
			draw_circle(z, 2.4 * (1 - life) + 0.8, Color(1, 1, 1, alpha * 0.9))
			if i % 2 == 0:
				var drop := Vector2(0, life * life * max_r * 0.5)
				draw_circle(z + dir * max_r * 0.15 + drop, 1.8, Color(col.r, col.g, col.b, alpha * 0.8))
