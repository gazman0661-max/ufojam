class_name Rules
extends RefCounted
# rules.dart karşılığı: kural katmanı (seviye numarasından üretilir).

const BUDGET_CHANCE_NORMAL := 0
const BUDGET_CHANCE_HARD := 50
const ROTOR_CHANCE_NORMAL := 40
const ROTOR_CHANCE_HARD := 90
const FAULTY_CHANCE_NORMAL := 30
const FAULTY_CHANCE_HARD := 75
const BELT_CHANCE_NORMAL := 20
const BELT_CHANCE_HARD := 60

class Rng extends RefCounted:
	var s: int
	func _init(seed_v: int) -> void:
		s = seed_v & 0x7fffffff
	func next_v() -> int:
		s = (s * 1103515245 + 12345) & 0x7fffffff
		return s >> 8
	func below(n: int) -> int:
		return next_v() % n

static func build_rules(n: int, stage: int, ufo_count: int) -> Models.LevelRules:
	var unlock_vals: Array = Models.MECH_UNLOCK.values()
	if Models.is_relief_level(n) and not unlock_vals.has(n):
		return Models.LevelRules.new()
	var hard := Models.is_hard_level(n)
	var mechs: Array = []

	# ---- hamle bütçesi
	var move_budget := 0
	var b_unlock: int = Models.MECH_UNLOCK[Models.Mech.BUDGET]
	if n >= b_unlock:
		var on := n == b_unlock
		if not on:
			var r := Rng.new(n * 7919 + 17)
			on = r.below(100) < (BUDGET_CHANCE_HARD if hard else BUDGET_CHANCE_NORMAL)
		if on:
			var slack: int = 9 - int((n - b_unlock) / 10)
			if slack < 3:
				slack = 3
			if hard:
				slack = slack - 2
				if slack < 3:
					slack = 3
			move_budget = ufo_count + slack
			mechs.append(Models.Mech.BUDGET)

	var used: Array = []

	# ---- dönen UFO
	var rotors: Array = []
	var rotor_on := 3.4
	var rotor_off := 1.8
	var r_unlock: int = Models.MECH_UNLOCK[Models.Mech.ROTOR]
	if n >= r_unlock:
		var r := Rng.new(n * 6271 + 5)
		var cand: Array = StageData.rotors.get(stage, [])
		var on: bool = n == r_unlock or r.below(100) < (ROTOR_CHANCE_HARD if hard else ROTOR_CHANCE_NORMAL)
		if on and not cand.is_empty():
			var want := 0
			if n == r_unlock:
				want = 1
			elif hard:
				var mx: int = 3 + int((n - 26) / 60)
				want = 2 + r.below((5 if mx > 5 else mx) - 1)
			else:
				var mx2: int = 1 + int((n - r_unlock) / 60)
				want = 1 + r.below(3 if mx2 > 3 else mx2)
			var pick: Array = []
			for id in cand:
				if pick.size() >= want:
					break
				pick.append(id)
			if not pick.is_empty():
				rotors = pick
				used.append_array(pick)
				mechs.append(Models.Mech.ROTOR)
				rotor_on = 2.6 if hard else 3.4
				rotor_off = 2.0 if hard else 1.8

	# ---- arızalı UFO
	var faulty := {}
	var fault_slack := 6
	var f_unlock: int = Models.MECH_UNLOCK[Models.Mech.FAULTY]
	if n >= f_unlock:
		var r := Rng.new(n * 4177 + 29)
		var cand: Array = StageData.faulty.get(stage, [])
		var on: bool = n == f_unlock or r.below(100) < (FAULTY_CHANCE_HARD if hard else FAULTY_CHANCE_NORMAL)
		if on and not cand.is_empty():
			var want := 0
			if n == f_unlock:
				want = 1
			elif hard:
				want = 2 + r.below(2)
			else:
				want = 1 + r.below(2)
			var slack: int = 7 - int((n - f_unlock) / 30)
			if slack < 4:
				slack = 4
			if hard:
				slack = 4
			fault_slack = slack
			var i := 0
			while i + 1 < cand.size() and faulty.size() < want:
				var id: int = cand[i]
				if not used.has(id):
					faulty[id] = int(cand[i + 1]) + slack
					used.append(id)
				i += 2
			if not faulty.is_empty():
				mechs.append(Models.Mech.FAULTY)

	# ---- bant UFO
	var belts: Array = []
	var belt_win := 0.3
	var b2_unlock: int = Models.MECH_UNLOCK[Models.Mech.BELT]
	if n >= b2_unlock:
		var r := Rng.new(n * 3571 + 41)
		var cand: Array = StageData.belts.get(stage, [])
		var on: bool = n == b2_unlock or r.below(100) < (BELT_CHANCE_HARD if hard else BELT_CHANCE_NORMAL)
		if on and not cand.is_empty():
			var want := 0
			if n == b2_unlock:
				want = 1
			else:
				want = (2 + r.below(2)) if hard else (1 + r.below(2))
			var pick: Array = []
			for id in cand:
				if pick.size() >= want:
					break
				if used.has(id):
					continue
				pick.append(id)
			if not pick.is_empty():
				belts = pick
				used.append_array(pick)
				mechs.append(Models.Mech.BELT)
				belt_win = 0.22 if hard else 0.3

	if mechs.is_empty():
		return Models.LevelRules.new()
	var lr := Models.LevelRules.new()
	lr.mechs = mechs
	lr.move_budget = move_budget
	lr.rotors = rotors
	lr.rotor_on = rotor_on
	lr.rotor_off = rotor_off
	lr.faulty = faulty
	lr.fault_slack = fault_slack
	lr.belts = belts
	lr.belt_win = belt_win
	return lr
