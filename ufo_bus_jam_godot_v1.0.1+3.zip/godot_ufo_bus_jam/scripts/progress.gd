extends Node
# progress.dart karşılığı

var level: int = 1
var coins: int = 0
var guides_seen: Array = []
const START_STOCK := 1
var boost_stock: Array = [START_STOCK, START_STOCK, START_STOCK]
# --- Satın alma (IAP) durumu ---
var loaded: bool = false          # load_all() bitti mi (IAP bunu bekler)
var no_ads: bool = false          # "Reklamları Kaldır" alındı mı (sadece geçiş reklamlarını kapatır)
var iap_tokens: Array = []        # işlenmiş satın alma token'ları (çift ödül vermeyi önler)
const IAP_TOKEN_KEEP := 60

func load_all() -> void:
	level = int(Store.get_v("level", 1))
	coins = int(Store.get_v("coins", 0))
	var g = Store.get_v("guides", [])
	guides_seen = []
	if typeof(g) == TYPE_ARRAY:
		for e in g:
			guides_seen.append(str(e))
	var st = Store.get_v("boostStock", null)
	if typeof(st) == TYPE_ARRAY and st.size() == 3:
		boost_stock = []
		for e in st:
			boost_stock.append(maxi(0, int(e)))
	no_ads = bool(Store.get_v("noAds", false))
	var tk = Store.get_v("iapTokens", [])
	iap_tokens = []
	if typeof(tk) == TYPE_ARRAY:
		for e in tk:
			iap_tokens.append(str(e))
	loaded = true

func has_guide(id: String) -> bool:
	return guides_seen.has(id)

func add_guide(id: String) -> void:
	if not guides_seen.has(id):
		guides_seen.append(id)

func save() -> void:
	Store.set_v("level", level)
	Store.set_v("coins", coins)
	Store.set_v("guides", guides_seen)
	Store.set_v("boostStock", boost_stock)
	Store.set_v("noAds", no_ads)
	Store.set_v("iapTokens", iap_tokens)
	Store.save()

func reset() -> void:
	level = 1
	coins = 0
	guides_seen = []
	boost_stock = [START_STOCK, START_STOCK, START_STOCK]
	# no_ads ve iap_tokens bilerek sıfırlanmaz: gerçek parayla alınan şeyler silinmemeli
	save()

# ---- IAP yardımcıları ----
func has_token(t: String) -> bool:
	return iap_tokens.has(t)

func add_token(t: String) -> void:
	if not iap_tokens.has(t):
		iap_tokens.append(t)
		while iap_tokens.size() > IAP_TOKEN_KEEP:
			iap_tokens.pop_front()

func add_boosters(n_each: int) -> void:
	for i in 3:
		boost_stock[i] += n_each
