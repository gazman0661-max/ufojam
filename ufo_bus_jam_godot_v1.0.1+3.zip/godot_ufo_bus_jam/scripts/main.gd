extends Control
# main.dart karşılığı: kayıtlı verileri yükler, SplashScreen ile başlar.

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	Nav.root = self
	Progress.load_all()
	Stats.load_all()
	Settings.load_all()
	L.load_lang()
	Legal.load_all()
	Audio.init()
	var sp = load("res://scripts/splash.gd").new()
	Nav.push(sp)
