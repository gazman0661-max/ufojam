extends Control
# game_screen.dart karşılığı. Flutter widget ağacı yerine tek bir Control üzerinde _draw() ile çizilir;
# yerleşim/geometri/animasyon formülleri birebir aynıdır.

var start_level := 1

# ---- sabitler (game_screen.dart)
const ARM_GAP := 19.0
const ARM_LANES := 3
const ARM_ROWS := 40
const ARM_LANE_GAP := 11.5
const KERNELS := 2
const KERNEL_SIZE := 13.0
const COUNTER_TICK_PER_SEC := 40.0
const COUNTER_H := 8.0
const COUNTER_BOX := 18.0
const GRID_UFO_SCALE := 1.0
const MIN_TAP := 34.0
const GROW_MAX := 2.0
const GROW_GAP := 0.05
const CAM_DENS_LO := 0.8
const CAM_DENS_HI := 1.4
const TARGET_UNIT := 46.0
const CAM_MIN := 0.72
const CAM_MIN_LAYERED := 0.88
const LAND_MS := 2200
const DEPART_MS := 2800
const DEPART_RISE := 1.0
const DEPART_SPLIT := 0.30
const SLOT_FREE_MS := 2000
const DEPART_WAIT_MS := 500
const BEAM_MS := 1400
const BUMP_MS := 380
const FLY_MS := 1000
const WALK_FRAC := 0.62
const UNLOCK_BOARD := 2
const UNLOCK_SHUFFLE := 3
const BOOSTER_COIN_PRICE := 250

enum TutKind { INFO, TAP_UFO, WATCH, TAP_BTN }

class G extends RefCounted:
	var grow_of: Array = []
	var W := 0.0
	var H := 0.0
	var hud_h := 56.0
	var top_inset := 0.0
	var arm_top := 0.0
	var arm_wait := 0.0
	var ring_top := 0.0
	var ring_h := 0.0
	var cx := 0.0
	var cy := 0.0
	var r := 0.0
	var entry_l := 0.375
	var entry_r := 0.625
	var entry_pt_l := Vector2.ZERO
	var entry_pt_r := Vector2.ZERO
	var arms: Array = []
	var arm_cum: Array = []
	var alien := 0.0
	var road_w := 0.0
	var shape: Dictionary = {}
	var sc := 1.0
	var img_left := 0.0
	var img_top := 0.0
	var ring_pts: Array = []
	var ring_cum: Array = []
	var ring_gap: Array = []
	var ring_len := 1.0
	var k := 1.0
	var ufo_scale := 1.0
	var slot_size := 0.0
	var slots_h := 0.0
	var slots_top := 0.0
	var hover_h := 0.0
	var slots_left := 0.0
	var grid_left := 0.0
	var grid_top := 0.0
	var grid_w := 0.0
	var grid_h := 0.0
	var panel_left := 0.0
	var panel_top := 0.0
	var panel_w := 0.0
	var panel_h := 0.0
	var unit := 0.0
	var unit_x := 0.0
	var b_min_x := 0.0
	var b_min_y := 0.0
	var b_w := 1.0
	var b_h := 1.0
	var boost_h := 78.0
	var slot_count := 0
	func pad_top() -> float:
		return slots_top + hover_h

var level: Models.LevelData
var game: GameState
var bouncing := {}
var pending := {}
var landed := {}
var spin_start := {}
var depart_start := {}
var full_chimed := {}
var last_board := {}
var gate_flash := {}
var birth := {}
var bumps := {}
var beaming := {}
var beam_from := {}
var flies: Array = []
var arm_vis := [0.0, 0.0]
var last_tick := 0
var fly_id := 0
var last_w := 390.0
var last_h := 700.0
var last_top := 0.0
var message = null
var msg_token := 0
var ended := false
var revived := false
var vip_armed := false
var new_boost := -1
var popup_open := false
var break_open := false
var last_rot := 0
var last_layer_ev := 0
var last_fault_ev := 0
var layer_flash_ms := -100000
var seen_spawned := {}
var portal_flash := {}
var cnt := {}
var launch_from := {}   # id -> [Rect2, start_ms, dur_ms]
var spawn_ms := {}
var _g: G
var _g_key := ""
var _grow_key := ""
var _grow_val: Array = []
var _hit_rects: Array = []   # [[Rect2, kind, arg]]
var _press_target = null

# öğretici durumu
var tut_queue: Array = []
var tut = null
var tut_idx := 0
var tut_step_ms := 0
var tut_hold := false
var tut_ufo = null
var tut_mem = null
var tut_boarded := false
var tut_flag := false
var tut_mark := 0
var tut_shown := false
var boost_rects := [Rect2(), Rect2(), Rect2()]
var tut_rects := {}

func _ready() -> void:
	texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	mouse_filter = Control.MOUSE_FILTER_STOP
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	Audio.music(Audio.MusicTrack.GAME)
	last_tick = Time.get_ticks_msec()
	_load(start_level)
	L.changed.connect(queue_redraw)
	set_process(true)

func _exit_tree() -> void:
	Audio.music(Audio.MusicTrack.MENU)

func on_back() -> void:
	Nav.pop()

func _after(ms: int, fn: Callable) -> void:
	get_tree().create_timer(ms / 1000.0).timeout.connect(func():
		if is_inside_tree():
			fn.call())

func _safe_top() -> float:
	var sa := DisplayServer.get_display_safe_area()
	var win := DisplayServer.window_get_size()
	return maxf(0.0, sa.position.y * size.y / maxf(win.y, 1.0))

func _safe_bottom() -> float:
	var sa := DisplayServer.get_display_safe_area()
	var win := DisplayServer.window_get_size()
	return maxf(0.0, (win.y - sa.end.y) * size.y / maxf(win.y, 1.0))

func _load(n: int) -> void:
	Stats.level_start(n)
	level = LevelRepo.get_level(n)
	game = GameState.new(level)
	bouncing.clear(); pending.clear(); landed.clear(); spin_start.clear(); depart_start.clear()
	full_chimed.clear(); last_board.clear(); gate_flash.clear(); birth.clear(); flies.clear()
	arm_vis = [0.0, 0.0]
	ended = false
	revived = false
	vip_armed = false
	bumps.clear(); beaming.clear(); beam_from.clear()
	message = null
	cnt.clear(); launch_from.clear(); spawn_ms.clear()
	last_rot = game.rot_version
	last_layer_ev = game.layer_events
	last_fault_ev = game.fault_events
	layer_flash_ms = -100000
	break_open = false
	portal_flash.clear()
	seen_spawned.clear()
	for u in game.ufos:
		if u.spawned:
			seen_spawned[u.spec.id] = true
			spawn_ms[u.spec.id] = Time.get_ticks_msec()
	_g_key = ""
	_tut_init(n)
	_maybe_unlock_popup(n)
	var g0 := _geom(size.x if size.x > 0 else last_w, size.y if size.y > 0 else last_h)
	game.entry_l = g0.entry_l
	game.entry_r = g0.entry_r
	Audio.play(Audio.Sfx.LEVEL_START)

func _rules_line() -> String:
	var p: Array = []
	if level.rules.move_budget > 0:
		p.append(L.t("👆 Hamle %d" % game.moves_left(), "👆 Moves %d" % game.moves_left()))
	if level.layer_count() > 1:
		p.append(L.t("⬆ Kat %d/%d" % [game.cur_layer + 1, level.layer_count()], "⬆ Floor %d/%d" % [game.cur_layer + 1, level.layer_count()]))
	if not level.rules.rotors.is_empty():
		p.append("🔄 %d" % level.rules.rotors.size())
	if not level.rules.faulty.is_empty():
		p.append("🔧 %d" % level.rules.faulty.size())
	if not level.rules.belts.is_empty():
		p.append("⇆ %d" % level.rules.belts.size())
	return "   ".join(p)

func _flash(m: String) -> void:
	msg_token += 1
	var tok := msg_token
	message = m
	_after(1100, func():
		if tok == msg_token:
			message = null)

# ------------------------------------------------------------ zaman

func _process(_d: float) -> void:
	if game == null:
		return
	last_w = size.x
	last_h = size.y - _safe_bottom()
	last_top = _safe_top()
	_tick()
	queue_redraw()

func _tick() -> void:
	var now := Time.get_ticks_msec()
	var dt: float = (now - last_tick) / 1000.0
	if dt > 0.1: dt = 0.1
	if dt < 0: dt = 0
	last_tick = now
	var k := minf(1.0, dt * 8.0)
	for a in 2:
		arm_vis[a] += (game.arm_head[a] - arm_vis[a]) * k
	for u in game.ufos:
		var id: int = u.spec.id
		if u.in_grid or not landed.has(id):
			continue
		var pend: int = pending.get(id, 0)
		var target := float(maxi(0, u.spec.seats - maxi(0, u.boarded - pend)) * Models.CAP_PER_PASSENGER)
		var cur: float = cnt.get(id, float(u.spec.capacity()))
		cnt[id] = maxf(target, cur - dt * COUNTER_TICK_PER_SEC) if cur > target else target
	_tut_watch()
	if ended or popup_open or _tut_pauses_game():
		return
	var g := _geom(last_w, last_h)
	game.entry_l = g.entry_l
	game.entry_r = g.entry_r
	var ev := game.step(dt)
	if not ev.is_empty():
		_handle_board(ev)
	if game.has_departing():
		for id in game.slots.duplicate():
			if id < 0 or not game.ufos[id].departed:
				continue
			var ds = depart_start.get(id, null)
			if ds != null and now - ds >= SLOT_FREE_MS:
				game.release_slot(id)
	_track_spawns(now)
	if game.rot_version != last_rot:
		last_rot = game.rot_version
	if game.layer_events != last_layer_ev:
		last_layer_ev = game.layer_events
		if Settings.screen_fx:
			layer_flash_ms = now
		Settings.vibe(Settings.MEDIUM)
		Audio.play(Audio.Sfx.LAYER_UP)
		_flash(L.t("⬆ %d. kat yükseldi!" % (game.cur_layer + 1), "⬆ Floor %d unlocked!" % (game.cur_layer + 1)))
	if game.fault_events != last_fault_ev:
		last_fault_ev = game.fault_events
	_check_end()

func _track_spawns(now: int) -> void:
	for u in game.ufos:
		if not u.spawned or not u.in_grid:
			continue
		var id: int = u.spec.id
		if not seen_spawned.has(id):
			seen_spawned[id] = true
			spawn_ms[id] = now
			if u.spec.group >= 0:
				Audio.play(Audio.Sfx.PORTAL_SPAWN)
				if Settings.screen_fx:
					portal_flash[u.spec.group] = now

func _handle_breaks() -> void:
	if break_open:
		return
	break_open = true
	while is_inside_tree() and not ended and not game.break_queue.is_empty():
		var id: int = game.break_queue[0]
		Audio.play(Audio.Sfx.UFO_BREAK)
		popup_open = true
		var p := GamePopup.show_popup(self, {
			"emoji": "🔧", "title": L.t("UFO bozuldu!", "UFO broke down!"),
			"message": L.t("Sayacı 0'a indi. Reklam izleyip tamir edersen sahada kalır. Vazgeçersen bozulup gider, birkaç hamle sonra aynı yerine geri gelir.",
				"Its counter hit 0. Watch an ad to repair it and it stays on the field. If you give up, it breaks down and leaves, then comes back to the same spot after a few moves."),
			"accent": UI.argb(0xFFFF9800),
			"buttons": [
				{"label": L.t("Vazgeç", "Cancel"), "kind": GamePopup.Kind.GHOST, "value": false},
				{"label": L.t("İzle", "Watch"), "icon": "play", "kind": GamePopup.Kind.REWARD, "value": true}]})
		var repair = await p.closed
		if not is_inside_tree():
			break
		var watched: bool = repair == true
		popup_open = false
		if watched:
			game.repair_ufo(id)
			Audio.play(Audio.Sfx.UFO_REPAIR)
		else:
			game.break_ufo(id)
		_flash(L.t("🔧 Tamir edildi", "🔧 Repaired") if watched else L.t("UFO bozulup gitti", "The UFO broke down and left"))
	break_open = false

# ------------------------------------------------------------ yol yardımcıları

func _path_at(g: G, s: float) -> Dictionary:
	var d := GameState.frac_s(s) * g.ring_len
	var cum: Array = g.ring_cum
	var lo := 0
	var hi := cum.size() - 1
	while hi - lo > 1:
		var mid := (lo + hi) >> 1
		if cum[mid] <= d:
			lo = mid
		else:
			hi = mid
	var a: Vector2 = g.ring_pts[lo]
	var b: Vector2 = g.ring_pts[(lo + 1) % g.ring_pts.size()]
	var seg: float = cum[lo + 1] - cum[lo]
	var t: float = 0.0 if seg <= 0 else clampf((d - cum[lo]) / seg, 0.0, 1.0)
	var dx := b.x - a.x
	var dy := b.y - a.y
	var ln := sqrt(dx * dx + dy * dy)
	var hx: float = -1.0 if ln == 0 else dx / ln
	var hy: float = 0.0 if ln == 0 else dy / ln
	var ga: float = g.ring_gap[lo]
	var gb: float = g.ring_gap[(lo + 1) % g.ring_gap.size()]
	return {"x": a.x + dx * t, "y": a.y + dy * t, "nx": hy, "ny": -hx, "gap": ga + (gb - ga) * t}

func _ring_point(g: G, s: float, off: float) -> Vector2:
	var p := _path_at(g, s)
	return Vector2(p["x"] + p["nx"] * off, p["y"] + p["ny"] * off)

func _cell_point(g: G, i: int) -> Vector2:
	var p := _path_at(g, game.cell_s(i))
	var off: float = ((i % GameState.RING_LANES) - (GameState.RING_LANES - 1) / 2.0) * p["gap"]
	return Vector2(p["x"] + p["nx"] * off, p["y"] + p["ny"] * off)

func _arm_point(g: G, arm: int, q: float, off: float) -> Vector2:
	var pts: Array = g.arms[arm]
	var cum: Array = g.arm_cum[arm]
	var i := 1
	while i < pts.size() - 1 and cum[i] < q:
		i += 1
	var a: Vector2 = pts[i - 1]
	var b: Vector2 = pts[i]
	var seg_len: float = cum[i] - cum[i - 1]
	var t: float = 0.0 if seg_len <= 0 else (q - cum[i - 1]) / seg_len
	var dx := b.x - a.x
	var dy := b.y - a.y
	var ln := sqrt(dx * dx + dy * dy)
	var ux: float = 0.0 if ln == 0 else dx / ln
	var uy: float = -1.0 if ln == 0 else dy / ln
	return Vector2(a.x + dx * t - uy * off, a.y + dy * t + ux * off)

# ------------------------------------------------------------ yerleşim

func _spin_fade(f: float) -> float:
	var a := clampf(f / 0.14, 0.0, 1.0)
	var b := clampf((1.0 - f) / 0.14, 0.0, 1.0)
	var m := minf(a, b)
	return m * m * (3 - 2 * m)

func _seat_scale(seats: int) -> float:
	return 1.0 if seats >= 10 else (0.9 if seats >= 6 else 0.8)

func _ufo_class(seats: int) -> int:
	return 10 if seats >= 10 else (6 if seats >= 6 else 4)

func _sprite_w(_seats: int) -> float:
	return 0.97

func _sprite_h(seats: int) -> float:
	return 0.82 if seats >= 10 else (0.62 if seats >= 6 else 0.65)

func _cam_zoom_for(lv: Models.LevelData) -> float:
	if lv.layer_count() > 1:
		var dens := 0.0
		for l in lv.layer_count():
			var b: Array = lv.bounds_of(l)
			dens = maxf(dens, lv.layer_size(l) / ((b[2] - b[0]) * (b[3] - b[1])))
		var t := clampf((dens - CAM_DENS_LO) / (CAM_DENS_HI - CAM_DENS_LO), 0.0, 1.0)
		return 1.0 - t * (1.0 - CAM_MIN_LAYERED)
	var dens2: float = lv.ufos.size() / (lv.board_w() * lv.board_h())
	var t2 := clampf((dens2 - CAM_DENS_LO) / (CAM_DENS_HI - CAM_DENS_LO), 0.0, 1.0)
	return 1.0 - t2 * (1.0 - CAM_MIN)

func _fit_ring_zoom(W: float, H: float, k_max: float, boost_h: float) -> float:
	var lv := game.level
	var sh := StageData.shape_for(lv.stage)
	var slot_count := game.slots.size() + game.locked_slots
	var bounds: Array = []
	for l in lv.layer_count():
		bounds.append(lv.bounds_of(l))
	var k := k_max
	while true:
		var sc := minf((W - 6.0) / sh["fitW"], 0.42) * k
		var ring_h: float = sh["contentH"] * sc
		var slot_size := minf(72.0, (W - 16.0) / slot_count) * k
		var hover_h := maxf(36.0 * k, slot_size * 0.8)
		var area_top := ring_h + 2.0 + hover_h + slot_size + COUNTER_H + 2.0
		var area_h := maxf(120.0, H - area_top - boost_h - 4.0)
		var need := false
		for b in bounds:
			var wl: float = (W - 28.0) / (b[2] - b[0])
			var hl: float = area_h / (b[3] - b[1])
			var unit := maxf(14.0, minf(minf(wl, hl), 64.0))
			if hl < wl and unit < TARGET_UNIT:
				need = true
		if not need or k <= CAM_MIN + 1e-6:
			return maxf(k, minf(k_max, CAM_MIN))
		k -= 0.02
	return k

func _geom(W: float, H: float) -> G:
	var key := "%s|%s|%s|%d|%d|%d|%d" % [snappedf(W, 0.01), snappedf(H, 0.01), snappedf(last_top, 0.01), level.number, game.slots.size() + game.locked_slots, game.cur_layer, game.slots.size()]
	if _g != null and key == _g_key:
		return _g
	var g := G.new()
	g.W = W
	g.H = H
	g.top_inset = last_top
	g.arm_top = 0.0
	var sh := StageData.shape_for(game.level.stage)
	g.shape = sh
	var k_ufo := _cam_zoom_for(game.level)
	g.k = _fit_ring_zoom(W, H, k_ufo, g.boost_h)
	g.ufo_scale = GRID_UFO_SCALE * k_ufo
	g.sc = minf((W - 6.0) / sh["fitW"], 0.42) * g.k
	g.img_left = W / 2.0 - sh["centerX"] * g.sc
	g.img_top = g.arm_top
	var tp := func(p: Array) -> Vector2: return Vector2(g.img_left + p[0] * g.sc, g.img_top + p[1] * g.sc)
	g.ring_pts = []
	for p in sh["ring"]:
		g.ring_pts.append(tp.call(p))
	g.ring_cum = [0.0]
	var n: int = g.ring_pts.size()
	for i in n:
		var a: Vector2 = g.ring_pts[i]
		var b: Vector2 = g.ring_pts[(i + 1) % n]
		g.ring_cum.append(g.ring_cum.back() + a.distance_to(b))
	g.ring_len = g.ring_cum.back()
	g.ring_gap = []
	for i in n:
		var a2: Vector2 = g.ring_pts[i]
		var b2: Vector2 = g.ring_pts[(i + 1) % n]
		var dx := b2.x - a2.x
		var dy := b2.y - a2.y
		var ln := sqrt(dx * dx + dy * dy)
		var nx: float = 0.0 if ln == 0 else dy / ln
		var ny: float = 0.0 if ln == 0 else -dx / ln
		var w := nx * nx
		var vert: float = sh["gapTop"] if ny < 0 else sh["gapBottom"]
		g.ring_gap.append((sh["gapSide"] * w + vert * (1 - w)) * g.sc)
	var min_y := 1e9
	var max_y := -1e9
	for p in g.ring_pts:
		min_y = minf(min_y, p.y)
		max_y = maxf(max_y, p.y)
	g.cx = W / 2.0
	g.cy = (min_y + max_y) / 2.0
	g.r = (max_y - min_y) / 2.0
	g.road_w = sh["trackW"] * g.sc
	g.ring_top = g.arm_top
	g.ring_h = sh["contentH"] * g.sc
	var s_of := func(j: Array) -> float:
		var q: Vector2 = tp.call(j)
		var best := 0
		var bd := 1e18
		for i in g.ring_pts.size():
			var d: float = (g.ring_pts[i] as Vector2).distance_squared_to(q)
			if d < bd:
				bd = d
				best = i
		return g.ring_cum[best] / g.ring_len
	g.entry_l = s_of.call(sh["armL"][0])
	g.entry_r = s_of.call(sh["armR"][0])
	g.arm_wait = g.road_w / 2.0 + 14.0 * g.k
	g.entry_pt_l = _ring_point(g, g.entry_l, 0)
	g.entry_pt_r = _ring_point(g, g.entry_r, 0)
	g.arms = []
	g.arm_cum = []
	for a in 2:
		var src: Array = sh["armL"] if a == 0 else sh["armR"]
		var pts: Array = []
		for p in src:
			pts.append(tp.call(p))
		pts[0] = g.entry_pt_l if a == 0 else g.entry_pt_r
		var cum: Array = [0.0]
		for i in range(1, pts.size()):
			cum.append(cum.back() + (pts[i] as Vector2).distance_to(pts[i - 1]))
		g.arms.append(pts)
		g.arm_cum.append(cum)
	g.alien = 20.0 * g.k
	g.slot_count = game.slots.size() + game.locked_slots
	g.slot_size = minf(72.0, (W - 16.0) / g.slot_count) * g.k
	g.hover_h = maxf(36.0 * g.k, g.slot_size * 0.8)
	g.slots_h = g.hover_h + g.slot_size + 10.0 + COUNTER_H
	g.slots_top = g.ring_top + g.ring_h + 2.0
	g.slots_left = (W - g.slot_size * g.slot_count) / 2.0
	var grid_area_top := g.slots_top + g.hover_h + g.slot_size + COUNTER_H + 2.0
	var grid_area_h := maxf(120.0, H - grid_area_top - g.boost_h - 4.0)
	var lb: Array = level.bounds_of(game.cur_layer)
	var sb_w: float = lb[2] - lb[0]
	var sb_h: float = lb[3] - lb[1]
	var s_unit := maxf(14.0, minf(minf((W - 28.0) / sb_w, grid_area_h / sb_h), 64.0))
	var max_stretch := 3.0 if game.level.layer_count() > 1 else 1.3
	var s_unit_x := maxf(s_unit, minf((W - 28.0) / sb_w, s_unit * max_stretch))
	g.panel_w = s_unit_x * sb_w
	g.panel_h = s_unit * sb_h
	g.panel_left = (W - g.panel_w) / 2.0
	g.panel_top = grid_area_top + maxf(0.0, (grid_area_h - g.panel_h) / 2.0)
	g.b_min_x = lb[0]
	g.b_min_y = lb[1]
	g.b_w = maxf(0.5, lb[2] - lb[0])
	g.b_h = maxf(0.5, lb[3] - lb[1])
	g.unit = maxf(s_unit, minf(minf(g.panel_w / g.b_w, g.panel_h / g.b_h), 64.0))
	g.unit_x = maxf(g.unit, minf(g.panel_w / g.b_w, g.unit * max_stretch))
	g.grid_w = g.unit_x * g.b_w
	g.grid_h = g.unit * g.b_h
	g.grid_left = g.panel_left + (g.panel_w - g.grid_w) / 2.0
	g.grid_top = g.panel_top + (g.panel_h - g.grid_h) / 2.0
	var gk := "%d|%.2f|%.2f|%.3f" % [game.level.number, g.unit, g.unit_x, g.ufo_scale]
	if gk != _grow_key:
		_grow_key = gk
		_grow_val = _compute_grow(g)
	g.grow_of = _grow_val
	_g = g
	_g_key = key
	return g

func _compute_grow(g: G) -> Array:
	var us: Array = game.level.ufos
	var res: Array = []
	var grid_w := g.unit_x * g.b_w
	var grid_h := g.unit * g.b_h
	for i in us.size():
		var a = us[i]
		var da: float = g.unit * Models.ufo_diameter(a.seats) * g.ufo_scale
		var best := GROW_MAX
		for j in us.size():
			if i == j:
				continue
			var b = us[j]
			if game.level.layer_of_ufo(i) != game.level.layer_of_ufo(j):
				continue
			var dx: float = (b.x - a.x) * g.unit_x
			var dy: float = (b.y - a.y) * g.unit
			var dist := sqrt(dx * dx + dy * dy)
			if dist < 1e-6:
				continue
			var th := atan2(dy, dx)
			var db: float = g.unit * Models.ufo_diameter(b.seats) * g.ufo_scale
			var rs := _ellipse_r(da, a.seats, th) + _ellipse_r(db, b.seats, th)
			best = minf(best, dist / (rs * (1 + GROW_GAP)))
		var cx: float = (a.x - g.b_min_x) * g.unit_x
		var cy: float = (a.y - g.b_min_y) * g.unit
		var hw: float = da * _sprite_w(a.seats) / 2.0
		var hh: float = da * _sprite_h(a.seats) / 2.0
		best = minf(best, minf(cx, grid_w - cx) / hw)
		best = minf(best, minf(cy, grid_h - cy) / hh)
		res.append(maxf(1.0, best))
	return res

func _ellipse_r(d: float, seats: int, th: float) -> float:
	var ea := d * _sprite_w(seats) / 2.0
	var eb := d * _sprite_h(seats) / 2.0
	return ea * eb / sqrt(pow(eb * cos(th), 2) + pow(ea * sin(th), 2))

func _hover_size(g: G, seats: int) -> float:
	return g.slot_size * 0.98 * _seat_scale(seats)

func _hover_cx(g: G, k: int) -> float:
	return g.slots_left + k * g.slot_size + g.slot_size / 2.0

func _hover_cy(g: G, sz: float) -> float:
	return g.slots_top + 0.36 * sz + 2.0

func _hover_bottom(g: G, sz: float) -> float:
	return _hover_cy(g, sz) + 0.30 * sz

func _pad_stand(g: G, k: int) -> Vector2:
	return Vector2(_hover_cx(g, k), g.pad_top() + g.slot_size * 0.43 - 2.0)

func _fit_for(g: G, id: int) -> float:
	return g.grow_of[id] if id < g.grow_of.size() else 1.0

func _grid_ufo_px(g: G, sp) -> float:
	return g.unit * Models.ufo_diameter(sp.seats) * g.ufo_scale * _fit_for(g, sp.id)

func _ufo_center(g: G, s) -> Vector2:
	return Vector2(g.grid_left + (s.x - g.b_min_x) * g.unit_x, g.grid_top + (s.y - g.b_min_y) * g.unit)

# ------------------------------------------------------------ oyun akışı

func _on_tap_ufo(id: int) -> void:
	if ended:
		return
	var u = game.ufos[id]
	if not u.in_grid:
		return
	if not _tut_allow_tap(id):
		return
	var g := _geom(last_w, last_h)
	if vip_armed:
		var k := game.tap_vip(id)
		if k < 0:
			_flash(L.t("VIP yuva dolu", "VIP slot is full"))
			return
		vip_armed = false
		if tut == null:
			Progress.boost_stock[2] = maxi(0, Progress.boost_stock[2] - 1)
			Progress.save()
			Stats.booster_used()
		Settings.vibe(Settings.MEDIUM)
		if not game.break_queue.is_empty():
			_handle_breaks()
		Audio.play(Audio.Sfx.VIP_TELEPORT)
		beam_from[id] = _ufo_center(g, u.spec)
		beaming[id] = true
		_start_launch(g, id, BEAM_MS)
		_after(BEAM_MS, func():
			landed[id] = true
			beaming.erase(id)
			beam_from.erase(id))
		_tut_after_tap(id)
		return
	if game.missed_belt(id):
		Settings.vibe(Settings.SELECTION)
		Audio.play(Audio.Sfx.WARN)
		_flash(L.t("Ortadayken dokun!", "Tap it when it's in the middle!"))
		return
	if not game.can_launch(id):
		Settings.vibe(Settings.HEAVY)
		Audio.play(Audio.Sfx.UFO_BLOCKED)
		game.note_wasted_tap()
		var dist := game.blocker_distance(id)
		bumps[id] = [Time.get_ticks_msec(), 0.0 if dist < 0 else dist]
		_tut_after_tap(id)
		return
	_start_launch(g, id, LAND_MS) # tap() öncesi grid konumunu kaydet
	var k2 := game.tap(id)
	if k2 < 0:
		launch_from.erase(id)
		Settings.vibe(Settings.HEAVY)
		Audio.play(Audio.Sfx.WARN)
		_flash(L.t("Maks.", "Max."))
		return
	Settings.vibe(Settings.LIGHT)
	Audio.play(Audio.Sfx.UFO_CALL)
	spin_start[id] = Time.get_ticks_msec()
	if not game.break_queue.is_empty():
		_handle_breaks()
	_after(LAND_MS, func(): landed[id] = true)
	_tut_after_tap(id)

func _start_launch(g: G, id: int, dur: int) -> void:
	var sp = game.ufos[id].spec
	var sz := _grid_ufo_px(g, sp)
	var c := _ufo_center(g, sp)
	launch_from[id] = [Rect2(c - Vector2(sz, sz) / 2.0, Vector2(sz, sz)), Time.get_ticks_msec(), dur]

func _handle_board(events: Array) -> void:
	var g := _geom(last_w, last_h)
	var now := Time.get_ticks_msec()
	if not events.is_empty():
		tut_boarded = true
	for e in events:
		var u = game.ufos[e.ufo_id]
		Audio.beam()
		if u.departed and not full_chimed.has(e.ufo_id):
			full_chimed[e.ufo_id] = true
			_after(FLY_MS, func(): Audio.play(Audio.Sfx.UFO_FULL))
		var slot := maxi(0, u.last_slot)
		var sz := _hover_size(g, u.spec.seats)
		var stand := _pad_stand(g, slot)
		var tx := _hover_cx(g, slot)
		var ty := _hover_bottom(g, sz) - sz * 0.12
		var pt := _cell_point(g, e.cell)
		var f := {"id": fly_id, "ufo": e.ufo_id, "color": e.color, "fx": pt.x, "fy": pt.y, "px": stand.x, "py": stand.y, "tx": tx, "ty": ty, "t0": now}
		fly_id += 1
		flies.append(f)
		pending[e.ufo_id] = pending.get(e.ufo_id, 0) + 1
		last_board[e.ufo_id] = now
		if Settings.screen_fx:
			gate_flash[e.gate] = now
		var fid: int = f["id"]
		var fu: int = f["ufo"]
		_after(FLY_MS, func():
			flies = flies.filter(func(x): return x["id"] != fid)
			pending[fu] = maxi(0, pending.get(fu, 1) - 1)
			bouncing[fu] = true
			_after(140, func(): bouncing.erase(fu)))

func _all_departed() -> bool:
	var now := Time.get_ticks_msec()
	for u in game.ufos:
		if u.in_grid or not u.departed:
			continue
		var ds = depart_start.get(u.spec.id, null)
		if ds == null or now - ds < DEPART_MS + 150:
			return false
	return true

func _check_end() -> void:
	if ended:
		return
	if game.won():
		if not _all_departed():
			return
		ended = true
		_on_win()
	elif game.lost():
		ended = true
		_on_lose()

func _on_win() -> void:
	var reward := level.reward()
	Stats.level_win(level.number)
	Progress.coins += reward
	if Progress.level <= level.number:
		Progress.level = level.number + 1
	Progress.save()
	await get_tree().create_timer(0.4).timeout
	if not is_inside_tree():
		return
	Audio.duck_music(4900)
	Audio.play(Audio.Sfx.WIN)
	var w := WinOverlay.new()
	w.level_number = level.number
	w.reward = reward
	w.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(w)
	popup_open = true
	w.double_pressed.connect(func():
		var ok = await _watch_ad("double_coins", L.t("Coinleri ikiye katla", "Double your coins"),
			L.t("Reklam izleyerek bu bölümün ödülünü x2 yap (+%d coin daha)." % reward, "Watch an ad to double this level's reward (+%d more coins)." % reward))
		if ok and is_instance_valid(w):
			Progress.coins += reward
			Progress.save()
			w.doubled = true)
	w.menu_pressed.connect(func():
		Audio.play(Audio.Sfx.CLICK)
		w.queue_free()
		Nav.pop())
	w.next_pressed.connect(func():
		Audio.play(Audio.Sfx.CLICK)
		w.queue_free()
		popup_open = false
		_load(level.number + 1))

func _on_lose() -> void:
	var moves := game.out_of_moves()
	Stats.level_lose(level.number, moves)
	await get_tree().create_timer(0.8).timeout
	if not is_inside_tree():
		return
	Audio.duck_music(2000)
	Audio.play(Audio.Sfx.LOSE)
	popup_open = true
	var btns: Array = []
	if not revived:
		btns.append({"label": L.t("+5 hamle (reklam)", "+5 moves (ad)") if moves else L.t("+2 park yeri (reklam)", "+2 parking slots (ad)"),
			"icon": "video", "kind": GamePopup.Kind.REWARD, "value": "revive"})
	btns.append({"label": L.t("Tekrar dene", "Try again"), "icon": "replay", "value": "retry"})
	btns.append({"label": L.t("Menü", "Menu"), "kind": GamePopup.Kind.GHOST, "value": "menu"})
	var p := GamePopup.show_popup(self, {
		"emoji": "👆" if moves else "😵",
		"title": L.t("Hamlen bitti", "Out of moves") if moves else L.t("Park yerleri doldu", "Parking slots are full"),
		"message": L.t("Dokunuş hakkın doldu. Kapalı veya kilitli UFO'lara dokunmak da hamle sayılır!", "You've used all your taps. Tapping blocked or locked UFOs also counts as a move!") if moves
			else L.t("Hiçbir UFO yolcu alamıyor. Halkadaki renklere göre UFO seç!", "No UFO can take any passengers. Pick UFOs based on the colors on the ring!"),
		"accent": UI.argb(0xFFFF5C7A), "stacked": true, "buttons": btns})
	while true:
		var v = await p.closed
		if not is_inside_tree():
			return
		if v == "revive":
			var ok = await _watch_ad("revive_moves" if moves else "revive_slots",
				L.t("+5 hamle", "+5 moves") if moves else L.t("+2 park yeri", "+2 parking slots"),
				L.t("Reklam izleyerek 5 ek hamle kazan ve devam et.", "Watch an ad to get 5 extra moves and keep playing.") if moves
				else L.t("Reklam izleyerek 2 ek park yeri kazan ve devam et.", "Watch an ad to get 2 extra parking slots and keep playing."))
			if ok:
				if moves:
					game.grant_moves(5)
				else:
					game.grant_slots(2)
				revived = true
				ended = false
				popup_open = false
				return
			# reklam izlenmedi: pencereyi yeniden aç
			p = GamePopup.show_popup(self, {
				"emoji": "👆" if moves else "😵",
				"title": L.t("Hamlen bitti", "Out of moves") if moves else L.t("Park yerleri doldu", "Parking slots are full"),
				"accent": UI.argb(0xFFFF5C7A), "stacked": true, "buttons": btns})
			continue
		popup_open = false
		if v == "retry":
			_load(level.number)
		else:
			Nav.pop()
		return

# Ödüllü reklam (Ads.watch): önce İzle/Vazgeç onayı; reklam şimdilik demo (hemen izlenmiş sayılır)
func _watch_ad(tag: String, title: String, msg: String) -> bool:
	Stats.ad_offered(tag)
	var p := GamePopup.show_popup(self, {
		"icon": "video", "title": title, "message": msg, "accent": UI.argb(0xFF2ECC8F), "dismissible": true,
		"buttons": [
			{"label": L.t("Vazgeç", "Cancel"), "kind": GamePopup.Kind.GHOST, "value": false},
			{"label": L.t("İzle", "Watch"), "icon": "play", "kind": GamePopup.Kind.REWARD, "value": true}]})
	var ok = await p.closed
	if ok != true or not is_inside_tree():
		return false
	Stats.ad_watched(tag)
	return true

# ------------------------------------------------------------ booster'lar

func _locked(unlock_level: int) -> bool:
	if level.number < unlock_level:
		_flash(L.t("Seviye %d'de açılır" % unlock_level, "Unlocks at level %d" % unlock_level))
		return true
	return false

func _use_board() -> void:
	if tut != null:
		_flash(L.t("Önce öğreticiyi bitir", "Finish the tutorial first"))
		return
	if ended or _locked(UNLOCK_BOARD):
		return
	if Progress.boost_stock[0] <= 0:
		_ask_booster(0, L.t("Hemen Bin", "Board Now"))
		return
	var ev := game.direct_board()
	if ev.is_empty():
		_flash(L.t("Park yerinde bekleyen UFO yok", "No UFO waiting in the parking slots"))
		return
	Progress.boost_stock[0] = maxi(0, Progress.boost_stock[0] - 1)
	Progress.save()
	Stats.booster_used()
	Audio.play(Audio.Sfx.BOOSTER_BOARD)
	_handle_board(ev)
	_flash(L.t("Hemen bin!", "Boarded!"))

func _use_shuffle() -> void:
	if tut != null:
		_flash(L.t("Önce öğreticiyi bitir", "Finish the tutorial first"))
		return
	if ended or _locked(UNLOCK_SHUFFLE):
		return
	if Progress.boost_stock[1] <= 0:
		_ask_booster(1, L.t("Karıştır", "Shuffle"))
		return
	Progress.boost_stock[1] = maxi(0, Progress.boost_stock[1] - 1)
	Progress.save()
	Stats.booster_used()
	Audio.play(Audio.Sfx.SHUFFLE)
	game.shuffle_queue(level.number * 31 + game.remaining_total())
	_flash(L.t("Sıradaki yolcular karıştı!", "Upcoming passengers shuffled!"))

func _use_vip() -> void:
	var st = _step()
	var tut_btn: bool = tut != null and st != null and st["kind"] == TutKind.TAP_BTN and st.get("boost", -1) == 2
	if tut != null and not tut_btn:
		_flash(L.t("Önce öğreticiyi bitir", "Finish the tutorial first"))
		return
	if ended or _locked(Models.VIP_UNLOCK_LEVEL):
		return
	if game.slots.is_empty() or game.slots[0] != -1:
		_flash(L.t("VIP yuva dolu", "VIP slot is full"))
		return
	if tut_btn:
		vip_armed = true
		_tut_advance(0)
		return
	if not vip_armed and Progress.boost_stock[2] <= 0:
		_ask_booster(2, L.t("Işınla", "Teleport"))
		return
	vip_armed = not vip_armed
	if vip_armed:
		_flash(L.t("Işınlamak için bir UFO seç", "Pick a UFO to teleport"))

func _ask_booster(idx: int, bname: String) -> void:
	if ended:
		return
	if tut != null:
		_flash(L.t("Önce öğreticiyi bitir", "Finish the tutorial first"))
		return
	var can_buy := Progress.coins >= BOOSTER_COIN_PRICE
	var assets := ["booster_board", "booster_shuffle", "booster_vip"]
	var asset: String = assets[clampi(idx, 0, 2)]
	var p := GamePopup.show_popup(self, {
		"badge_tex": UI.tex(asset), "title": L.t("%s al" % bname, "Get %s" % bname), "dismissible": true,
		"body_h": 40.0 + (0.0 if can_buy else 26.0),
		"body_draw": _booster_body.bind(idx, asset, can_buy),
		"buttons": [
			{"label": L.t("Reklam izle  +1", "Watch ad  +1"), "icon": "video", "kind": GamePopup.Kind.REWARD, "value": "ad"},
			{"label": L.t("%d coin ile al" % BOOSTER_COIN_PRICE, "Buy for %d coins" % BOOSTER_COIN_PRICE), "leading_tex": UI.tex("coin"), "kind": GamePopup.Kind.GOLD, "value": "coin", "enabled": can_buy},
			{"label": L.t("Vazgeç", "Cancel"), "kind": GamePopup.Kind.GHOST, "value": null}]})
	var choice = await p.closed
	if not is_inside_tree() or choice == null:
		return
	if choice == "ad":
		var watched = await _watch_ad("booster_ad", "+1 %s" % bname, L.t("Reklam izleyerek 1 adet %s kazan." % bname, "Watch an ad to earn 1 %s." % bname))
		if not watched:
			return
		Progress.boost_stock[idx] += 1
		Progress.save()
		_flash("+1 %s" % bname)
	elif choice == "coin":
		if Progress.coins < BOOSTER_COIN_PRICE:
			return
		Progress.coins -= BOOSTER_COIN_PRICE
		Progress.boost_stock[idx] += 1
		Progress.save()
		Stats.coin_buy()
		_flash("+1 %s" % bname)

func _booster_body(ci: CanvasItem, r: Rect2, idx: int, asset: String, can_buy: bool) -> void:
	var s1 := L.t("Stok %d" % Progress.boost_stock[idx], "Stock %d" % Progress.boost_stock[idx])
	var s2 := str(Progress.coins)
	var w1 := UI.text_width(s1, 15, true) + 24 + 26
	var w2 := UI.text_width(s2, 15, true) + 24 + 26
	var x0 := r.position.x + (r.size.x - (w1 + 10 + w2)) / 2.0
	for pair in [[x0, w1, s1, asset], [x0 + w1 + 10, w2, s2, "coin"]]:
		var cr := Rect2(pair[0], r.position.y, pair[1], 34)
		UI.fill_rrect(ci, cr, 20, Color(0, 0, 0, 90.0 / 255.0))
		UI.stroke_rrect(ci, cr, 20, Color(1, 1, 1, 50.0 / 255.0), 1.2)
		ci.draw_texture_rect(UI.tex(pair[3]), Rect2(cr.position.x + 12, cr.position.y + 7, 20, 20), false)
		UI.text_c(ci, Rect2(cr.position.x + 38, cr.position.y, pair[1] - 38, 34), pair[2], 15, Color.WHITE, true)
	if not can_buy:
		UI.text_c(ci, Rect2(r.position.x, r.position.y + 44, r.size.x, 20), L.t("Yeterli coin yok.", "Not enough coins."), 13.5, Color(1, 1, 1, 0.54), false)

func _unlock_body(ci: CanvasItem, r: Rect2, bname: String, d_lines: Array) -> void:
	UI.text_c(ci, Rect2(r.position.x, r.position.y, r.size.x, 26), bname, 19, Color.WHITE, true)
	var y := r.position.y + 32.0
	for ln in d_lines:
		UI.text_c(ci, Rect2(r.position.x, y, r.size.x, 20), ln, 15, Color(1, 1, 1, 215.0 / 255.0), false)
		y += 20.0
	UI.text_c(ci, Rect2(r.position.x, y + 10, r.size.x, 20), L.t("Hediye: %d adet" % Progress.START_STOCK, "Gift: %d" % Progress.START_STOCK), 14.5, Color(1.0, 0.75, 0.0), true)

func _maybe_unlock_popup(n: int) -> void:
	new_boost = -1
	var idx := -1
	var bname := ""
	var asset := ""
	var desc := ""
	if n == UNLOCK_BOARD:
		idx = 0
		bname = L.t("Hemen Bin", "Board Now")
		asset = "booster_board"
		desc = L.t("Park yerinde bekleyen UFO'lara halkadan anında yolcu bindirir.", "Instantly boards passengers from the ring onto the UFOs waiting in the parking slots.")
	elif n == UNLOCK_SHUFFLE:
		idx = 1
		bname = L.t("Karıştır", "Shuffle")
		asset = "booster_shuffle"
		desc = L.t("Kollarda bekleyen yolcuların sırasını değiştirir.", "Changes the order of the passengers waiting on the arms.")
	elif n == Models.VIP_UNLOCK_LEVEL:
		idx = 2
		bname = L.t("Işınla & VIP yuva", "Teleport & VIP slot")
		asset = "booster_vip"
		desc = L.t("Altın VIP yuva açıldı! Işınla ile istediğin UFO'yu oraya gönder.", "The golden VIP slot is now open! Use Teleport to send any UFO there.")
	if idx < 0:
		return
	var id := "unlock_%d" % idx
	if Progress.has_guide(id):
		return
	Progress.add_guide(id)
	Progress.save()
	new_boost = idx
	popup_open = true
	await get_tree().process_frame
	if not is_inside_tree():
		return
	var d_lines := UI.wrap(desc, 15, 280.0, false)
	var p := GamePopup.show_popup(self, {
		"badge_tex": UI.tex(asset), "title": L.t("🔓 Yeni açıldı!", "🔓 Unlocked!"), "accent": UI.argb(0xFFFFB300),
		"body_h": 26.0 + d_lines.size() * 20.0 + 30.0,
		"body_draw": _unlock_body.bind(bname, d_lines),
		"buttons": [{"label": L.t("Harika!", "Awesome!"), "kind": GamePopup.Kind.GOLD, "value": null}]})
	await p.closed
	popup_open = false

func _ask_unlock_slot() -> void:
	if ended or game.locked_slots <= 0:
		return
	if tut != null:
		_flash(L.t("Önce öğreticiyi bitir", "Finish the tutorial first"))
		return
	var ok = await _watch_ad("slot_unlock", L.t("Yeni park yeri", "New parking slot"), L.t("Reklam izleyerek kilitli bir park yerini aç.", "Watch an ad to unlock a locked parking slot."))
	if ok and is_inside_tree():
		game.unlock_slot()
		_g_key = ""

# ------------------------------------------------------------ giriş

func _gui_input(e: InputEvent) -> void:
	var pos := Vector2.ZERO
	var pressed := false
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
		pos = e.position
		pressed = e.pressed
	elif e is InputEventScreenTouch:
		pos = e.position
		pressed = e.pressed
	else:
		return
	if pressed:
		_press_target = _hit_test(pos)
	else:
		var t = _hit_test(pos)
		if t != null and _press_target != null and t[0] == _press_target[0] and t[1] == _press_target[1]:
			_dispatch(t)
		_press_target = null

func _hit_test(p: Vector2):
	for i in range(_hit_rects.size() - 1, -1, -1):
		var h: Array = _hit_rects[i]
		if (h[0] as Rect2).has_point(p):
			return [h[1], h[2]]
	return null

func _dispatch(t: Array) -> void:
	match t[0]:
		"back": Nav.pop()
		"refresh": _load(level.number)
		"ufo": _on_tap_ufo(t[1])
		"booster":
			if t[1][1] == "plus":
				_ask_booster(t[1][0], [L.t("Hemen Bin", "Board Now"), L.t("Karıştır", "Shuffle"), L.t("Işınla", "Teleport")][t[1][0]])
			else:
				if new_boost == t[1][0]:
					new_boost = -1
				match t[1][0]:
					0: _use_board()
					1: _use_shuffle()
					2: _use_vip()
		"slot": _ask_unlock_slot()
		"tut_next": _tut_advance(0)
		"tut_skip": _tut_skip_all()
		"tut_block": pass

# ------------------------------------------------------------ öğretici
# Adım sözlüğü: {kind, title, text, button, ufo:Callable, boost:int, region:String, done:Callable, timeout, hold, on_enter:Callable}

func _s(kind: int, text: String, o: Dictionary = {}) -> Dictionary:
	var d := {"kind": kind, "text": text, "title": "", "button": L.t("Devam", "Continue"), "timeout": 9000, "hold": 0}
	d.merge(o, true)
	return d

func _step():
	if tut == null or tut_hold or tut_idx >= tut["steps"].size():
		return null
	return tut["steps"][tut_idx]

func _tut_pauses_game() -> bool:
	if tut == null:
		return false
	if tut_hold:
		return true
	var st = _step()
	return st != null and st["kind"] != TutKind.WATCH

func _tut_init(n: int) -> void:
	tut = null
	tut_idx = 0
	tut_hold = false
	tut_ufo = null
	tut_mem = null
	tut_boarded = false
	tut_queue.clear()
	var need := func(id: String) -> bool: return not Progress.has_guide(id)
	if n == 1 and need.call("basics"): tut_queue.append("basics")
	if n >= 2 and need.call("blocked") and _pick_blocked() != -1: tut_queue.append("blocked")
	if n >= UNLOCK_BOARD and need.call("board"): tut_queue.append("board")
	if n >= UNLOCK_SHUFFLE and need.call("shuffle"): tut_queue.append("shuffle")
	var has_mystery := false
	var has_group := false
	for u in level.ufos:
		if u.mystery: has_mystery = true
		if u.group >= 0: has_group = true
	if has_mystery and need.call("mystery"): tut_queue.append("mystery")
	if level.has_vip() and n >= Models.VIP_UNLOCK_LEVEL and need.call("vip"): tut_queue.append("vip")
	if has_group and need.call("spawn"): tut_queue.append("spawn")
	for m in level.rules.mechs:
		var gid := _mech_guide_id(m)
		if need.call(gid) and (m != Models.Mech.BUDGET or n == Models.MECH_UNLOCK[m]):
			tut_queue.append(gid)
	if level.layer_count() > 1 and need.call("layer"): tut_queue.append("layer")
	_tut_next_guide()

func _tut_next_guide() -> void:
	tut = null
	tut_ufo = null
	while not tut_queue.is_empty():
		var id: String = tut_queue.pop_front()
		var guide := _tut_guide(id)
		if guide["steps"].is_empty():
			continue
		tut = guide
		tut_shown = false
		_tut_goto(0)
		if tut != null:
			return

func _tut_goto(i: int) -> void:
	if tut == null:
		return
	if i >= tut["steps"].size():
		if tut_shown:
			Progress.add_guide(tut["id"])
			Progress.save()
		_tut_next_guide()
		return
	if i == 0:
		tut_mem = null
	tut_idx = i
	tut_step_ms = Time.get_ticks_msec()
	var st: Dictionary = tut["steps"][i]
	tut_ufo = null
	if st.has("ufo"):
		var r = (st["ufo"] as Callable).call()
		tut_ufo = r if (r != null and r != -1) else null
	if st.has("ufo") and tut_ufo == null:
		_tut_goto(i + 1)
	else:
		tut_shown = true
		if st.has("on_enter"):
			(st["on_enter"] as Callable).call()

func _tut_advance(hold_ms: int) -> void:
	var nxt := tut_idx + 1
	if hold_ms <= 0:
		_tut_goto(nxt)
		return
	tut_hold = true
	_after(hold_ms, func():
		tut_hold = false
		_tut_goto(nxt))

func _tut_skip_all() -> void:
	if tut != null:
		Progress.add_guide(tut["id"])
	for id in tut_queue:
		Progress.add_guide(id)
	Progress.save()
	vip_armed = false
	tut_queue.clear()
	tut = null
	tut_ufo = null
	tut_hold = false

func _tut_watch() -> void:
	var st = _step()
	if st == null or st["kind"] != TutKind.WATCH:
		return
	var now := Time.get_ticks_msec()
	var done: bool = st.has("done") and (st["done"] as Callable).call()
	if done or now - tut_step_ms > st["timeout"]:
		_tut_goto(tut_idx + 1)

func _tut_allow_tap(id: int) -> bool:
	if tut == null:
		return true
	if tut_hold:
		return false
	var st = _step()
	if st == null:
		return true
	if st["kind"] == TutKind.WATCH:
		return true
	if st["kind"] == TutKind.TAP_UFO:
		if tut_ufo != null and id == tut_ufo:
			return true
		_flash(L.t("Parlayan UFO'ya dokun", "Tap the glowing UFO"))
		return false
	if st["kind"] == TutKind.TAP_BTN:
		_flash(L.t("Parlayan düğmeye dokun", "Tap the glowing button"))
	return false

func _tut_after_tap(id: int) -> void:
	var st = _step()
	if st != null and st["kind"] == TutKind.TAP_UFO and tut_ufo != null and id == tut_ufo:
		tut_mem = id
		_tut_advance(st["hold"])

func _pick_launch(exclude: int = -1) -> int:
	var opts: Array = game.launchable().filter(func(id): return id != exclude)
	if opts.is_empty():
		return -1
	var score := func(id: int) -> int:
		var n := 0
		for p in game.cells:
			if p != null and p.color == game.ufos[id].spec.color:
				n += 1
		return n
	opts.sort_custom(func(a, b): return score.call(a) > score.call(b))
	return opts[0]

func _pick_blocked() -> int:
	var best := -1
	var best_d := 1e9
	for u in game.ufos:
		var id: int = u.spec.id
		if not u.in_grid or not u.spawned or game.can_launch(id):
			continue
		var b := game.first_blocker(id)
		if b == -1 or not game.can_launch(b):
			continue
		var d := game.blocker_distance(id)
		if d < best_d:
			best_d = d
			best = id
	return best

func _mech_guide_id(m: int) -> String:
	return "m_" + ["budget", "rotor", "faulty", "belt"][m]

func _home_open(u) -> bool:
	for o in game.ufos:
		if o.spec.id == u.spec.id or not o.in_grid or not o.spawned:
			continue
		if Geo.sweep_hit(u.spec, o.cur) >= 0.0:
			return false
	return true

func _pick_rotor_target() -> int:
	var any := -1
	for u in game.ufos:
		if not u.rotor or not u.in_grid or not u.spawned:
			continue
		if any == -1:
			any = u.spec.id
		if _home_open(u):
			tut_mem = u.spec.id
			return u.spec.id
	tut_mem = null
	return any

func _pick_belt_target() -> int:
	var any := -1
	for u in game.ufos:
		if not u.belt or not u.in_grid or not u.spawned:
			continue
		if any == -1:
			any = u.spec.id
		if _home_open(u):
			tut_mem = u.spec.id
			return u.spec.id
	tut_mem = null
	return any

func _pick_faulty_target() -> int:
	for u in game.ufos:
		if u.is_faulty() and u.in_grid and u.spawned:
			return u.spec.id
	return -1

func _pick_plain() -> int:
	for id in game.launchable():
		var u = game.ufos[id]
		if not u.is_faulty() and not u.rotor and not u.belt:
			return id
	return -1

func _pick_portal_front() -> int:
	for u in game.ufos:
		var gr: int = u.spec.group
		if gr < 0 or not u.in_grid or not u.spawned:
			continue
		if game.groups.get(gr, []).size() < 2:
			continue
		if game.can_launch(u.spec.id):
			return u.spec.id
	return -1


# ---- öğretici hedef yardımcıları (lambda yerine yöntem)
func _t_mem():
	return tut_mem

func _t_blocked():
	tut_mem = _pick_blocked()
	return tut_mem if tut_mem != -1 else null

func _t_first_blocker():
	return null if tut_mem == null else game.first_blocker(tut_mem)

func _t_launch_excl():
	return _pick_launch(tut_mem if tut_mem != null else -1)

func _t_mark_rot() -> void:
	tut_mark = game.rot_version

func _t_rot_done() -> bool:
	return game.rot_version != tut_mark

func _t_rot_clear() -> bool:
	return tut_mem != null and not game.ufos[tut_mem].flipped and game.can_launch(tut_mem)

func _t_flag_reset() -> void:
	tut_flag = false

func _t_belt_done() -> bool:
	var t = tut_mem
	if t == null:
		return true
	var open := game.belt_open(game.ufos[t])
	if not open:
		tut_flag = true
	return tut_flag and open

func _t_basics_done() -> bool:
	return tut_boarded and tut_mem != null and landed.has(tut_mem)

func _t_vip_pick():
	var b := _pick_blocked()
	return b if b != -1 else _pick_launch()

func _t_mystery():
	for u in game.ufos:
		if u.spec.mystery and u.in_grid and u.spawned:
			return u.spec.id
	return null

func _t_spawn_new():
	var m = tut_mem
	if m == null:
		return null
	var lst = game.groups.get(game.ufos[m].spec.group, null)
	if lst == null:
		return null
	for i2 in lst:
		var u = game.ufos[i2]
		if u.in_grid and u.spawned:
			return i2
	return null

func _tut_guide(id: String) -> Dictionary:
	var I := TutKind.INFO
	var T := TutKind.TAP_UFO
	var W := TutKind.WATCH
	var B := TutKind.TAP_BTN
	var got := L.t("Anladım", "Got it")
	var ok_s := L.t("Tamam", "OK")
	match id:
		"m_budget":
			return {"id": id, "steps": [
				_s(I, L.t("Dokunuş hakkın sınırlı. Kalan hamle burada yazıyor: %d. Bitince seviye biter." % game.moves_left(), "Your taps are limited. The moves you have left are shown here: %d. When they run out, the level ends." % game.moves_left()),
					{"title": "👆 " + Models.mech_title(Models.Mech.BUDGET), "region": "hud", "button": got}),
				_s(T, L.t("Önü kapalı bir UFO'ya dokun: boşa dokunuş da hamle sayılır. (Bu seferlik öğretmek için)", "Tap a blocked UFO: a wasted tap also counts as a move. (Just this once, to teach you)"),
					{"ufo": _t_blocked, "hold": 900}),
				_s(I, L.t("Gördün mü, sayaç düştü. Kapalı UFO'lara boşuna dokunma; önü açıkları çağırarak hamleni akıllıca kullan.", "See, the counter dropped. Don't waste taps on blocked UFOs; call the ones with a clear path and spend your moves wisely."),
					{"title": L.t("Hamle azaldı!", "Moves went down!"), "region": "hud", "ufo": _t_mem, "button": ok_s})]}
		"m_rotor":
			return {"id": id, "steps": [
				_s(I, L.t("Mavi halkalı UFO belli aralıkla yön değiştirir. Halka sarı yanıp sönerse dönmek üzere!", "The UFO with the blue ring changes direction at set intervals. If the ring blinks yellow, it is about to turn!"),
					{"title": "🔄 " + Models.mech_title(Models.Mech.ROTOR), "ufo": _pick_rotor_target, "button": got}),
				_s(W, L.t("İzle: UFO yön değiştiriyor. Okun gösterdiği yöne çıkar.", "Watch: the UFO is changing direction. It leaves in the direction its arrow points."),
					{"ufo": _t_mem, "on_enter": _t_mark_rot, "done": _t_rot_done}),
				_s(W, L.t("Şimdi önü açık yöne dönmesini bekle…", "Now wait for it to turn to a direction with a clear path…"),
					{"ufo": _t_mem, "done": _t_rot_clear}),
				_s(T, L.t("Önü açıkken dokun!", "Tap it while its path is clear!"), {"ufo": _t_mem, "hold": 700})]}
		"m_belt":
			return {"id": id, "steps": [
				_s(I, L.t("Bantta kayan UFO sadece bandın ortasındayken çağrılır. Ortaya gelince halkası yeşil yanar.", "A UFO sliding on the belt can only be called when it is in the middle of the belt. Its ring turns green when it gets there."),
					{"title": "⇆ " + Models.mech_title(Models.Mech.BELT), "ufo": _pick_belt_target, "button": got}),
				_s(W, L.t("İzle: UFO kayıyor. Yeşil halka yanınca ortadadır.", "Watch: the UFO is sliding. When the green ring lights up, it is in the middle."),
					{"ufo": _t_mem, "on_enter": _t_flag_reset, "done": _t_belt_done}),
				_s(T, L.t("Şimdi dokun! Kaçırırsan ceza yok, bir sonraki geçişi beklersin.", "Tap now! If you miss it, there is no penalty; you just wait for the next pass."), {"ufo": _t_mem, "hold": 700})]}
		"m_faulty":
			return {"id": id, "steps": [
				_s(I, L.t("Üstündeki sayı her UFO çıkışında düşer. 0 olursa UFO bozulur.", "The number on it drops every time a UFO leaves. If it reaches 0, the UFO breaks down."),
					{"title": "🔧 " + Models.mech_title(Models.Mech.FAULTY), "ufo": _pick_faulty_target, "button": got}),
				_s(T, L.t("Başka bir UFO çağır, sayacın düştüğünü gör.", "Call another UFO and watch the counter drop."), {"ufo": _pick_plain, "hold": 900}),
				_s(I, L.t("0 olursa reklamla tamir edersin ya da bırakırsın: UFO gider, birkaç hamle sonra geri gelir. Önündekileri temizleyip erken çağır.", "If it reaches 0, you can repair it with an ad or let it go: the UFO leaves and comes back after a few moves. Clear what is in front of it and call it early."),
					{"title": L.t("Sayaç düştü!", "Counter dropped!"), "ufo": _pick_faulty_target, "button": ok_s})]}
		"layer":
			return {"id": "layer", "steps": [
				_s(I, L.t("Bu seviye çok katlı! Önce görünen UFO'ları bitir; sonra alttaki kat asansörle yukarı çıkar. Her katta yolcular o katın renkleriyle gelir.", "This level has multiple floors! Finish the visible UFOs first; then the floor below rises up by elevator. On each floor, passengers arrive in that floor's colors."),
					{"title": L.t("⬆ Katman asansörü", "⬆ Floor elevator"), "button": got})]}
		"basics":
			return {"id": id, "steps": [
				_s(I, L.t("Uzaylılar halkada dönüyor. Amacın hepsini kendi renkli UFO'suna bindirmek.", "The aliens are circling on the ring. Your goal is to get each one onto the UFO of its own color."),
					{"title": L.t("Hoş geldin!", "Welcome!"), "region": "ring", "button": L.t("Başla", "Start")}),
				_s(T, L.t("Önü açık bir UFO'ya dokun. Park yerine uçar.", "Tap a UFO with a clear path. It flies to a parking slot."), {"ufo": _pick_launch, "hold": 700}),
				_s(W, L.t("Aynı renkteki uzaylılar kapıdan geçerken UFO'ya biner.", "Aliens of the same color board the UFO as they pass the gate."),
					{"region": "pads", "done": _t_basics_done}),
				_s(I, L.t("UFO'nun altındaki sayı kalan kapasite. Her uzaylıda azalır, 0 olunca UFO yolcularıyla gider.", "The number under the UFO is its remaining capacity. It goes down with every alien, and at 0 the UFO leaves with its passengers."),
					{"title": L.t("Kalan kapasite", "Remaining capacity"), "region": "counter", "button": got}),
				_s(I, L.t("Sadece %d park yerin var. Hepsi doluyken yeni UFO çağıramazsın; uygun renk gelmezse seviye biter. Yerleri akıllıca kullan." % level.slots, "You only have %d parking slots. When they are all full, you can't call a new UFO; if no matching color comes, the level ends. Use your slots wisely." % level.slots),
					{"title": L.t("Park yerlerin sınırlı", "Your parking slots are limited"), "region": "pads", "button": ok_s}),
				_s(T, L.t("Şimdi sıradaki UFO'yu sen çağır!", "Now call the next UFO yourself!"), {"ufo": _t_launch_excl, "hold": 500})]}
		"blocked":
			return {"id": id, "steps": [
				_s(T, L.t("Bu UFO'nun önü kapalı (ok yönüne bak). Dokun, ne olacağını gör.", "This UFO's path is blocked (look at its arrow). Tap it and see what happens."),
					{"ufo": _t_blocked, "hold": 900}),
				_s(I, L.t("UFO önündeki araca çarpıp geri döndü. Önce yoldaki UFO'yu çıkarman gerek.", "The UFO bumped into the vehicle ahead and came back. You need to clear the UFO in the way first."),
					{"title": L.t("Yol kapalı!", "Path blocked!"), "ufo": _t_first_blocker}),
				_s(T, L.t("Önündekini çıkar: ona dokun!", "Clear the one in front: tap it!"), {"ufo": _t_first_blocker, "hold": 600}),
				_s(I, L.t("Kural basit: UFO ok yönünde çıkar. Önü açıksa uçar, kapalıysa çarpar. Önünü açarak ilerle.", "The rule is simple: a UFO leaves in the direction of its arrow. If the path is clear it flies, if blocked it bumps. Make progress by clearing the way."),
					{"title": L.t("Güzel!", "Nice!"), "button": ok_s})]}
		"board":
			return {"id": "board", "steps": [
				_s(I, L.t("Park yerinde bekleyen UFO'lar için halkadaki uygun yolcuları anında bindirir. Stoğun olduğu sürece istediğin kadar kullan.", "Instantly boards the matching passengers on the ring onto the UFOs waiting in the parking slots. Use it as much as you like while you have stock."),
					{"title": L.t("Hemen Bin", "Board Now"), "boost": 0, "region": "pads", "button": got})]}
		"shuffle":
			return {"id": "shuffle", "steps": [
				_s(I, L.t("Kollarda bekleyen yolcuların sırasını değiştirir. İstediğin renk geç geliyorsa kullan. Stoğun olduğu sürece istediğin kadar.", "Changes the order of the passengers waiting on the arms. Use it if the color you want is coming late. As much as you like while you have stock."),
					{"title": L.t("Karıştır", "Shuffle"), "boost": 1, "region": "ring", "button": got})]}
		"vip":
			return {"id": "vip", "steps": [
				_s(I, L.t("Altın yuva VIP yuva: normal dokunuşla dolmaz. Işınla ile önü kapalı bile olsa istediğin UFO'yu buraya gönderirsin.", "The golden slot is the VIP slot: it can't be filled with a normal tap. With Teleport you can send any UFO here, even if its path is blocked."),
					{"title": L.t("Işınla & VIP yuva", "Teleport & VIP slot"), "boost": 2, "region": "vip"}),
				_s(B, L.t("Önce Işınla düğmesine dokun!", "First tap the Teleport button!"), {"boost": 2}),
				_s(T, L.t("Şimdi bir UFO seç: önü kapalı olsa da VIP yuvaya ışınlanır.", "Now pick a UFO: it teleports to the VIP slot even if its path is blocked."),
					{"ufo": _t_vip_pick, "hold": 1700}),
				_s(I, L.t("UFO altın VIP yuvada yolcu bekliyor. VIP yuva boşken Işınla'yı tekrar kullanabilirsin; stoğun bitince reklamla +1 alırsın.", "The UFO is waiting for passengers in the golden VIP slot. When the VIP slot is empty you can use Teleport again; when your stock runs out you get +1 by watching an ad."),
					{"title": L.t("Işınlandı!", "Teleported!"), "region": "vip", "button": ok_s})]}
		"mystery":
			return {"id": id, "steps": [
				_s(I, L.t("Siyah \"?\" işaretli UFO'nun rengi, önü kapalıyken gizli. Yolunu açınca rengi ortaya çıkar.", "The color of the UFO marked with a black \"?\" is hidden while its path is blocked. Clear its way and the color is revealed."),
					{"title": L.t("Gizemli UFO", "Mystery UFO"), "button": got,
					"ufo": _t_mystery})]}
	# spawn
	return {"id": "spawn", "steps": [
		_s(I, L.t("Mor kapıdan UFO'lar sırayla gelir: öndeki gidince arkasındaki yeni UFO kapıdan çıkar.", "UFOs come through the purple gate in order: when the front one leaves, the next UFO behind it comes out of the gate."),
			{"title": L.t("Işınlama kapısı", "Teleport gate"), "ufo": _pick_portal_front, "button": got}),
		_s(T, L.t("Kapıdaki öndeki UFO'yu çağır.", "Call the UFO at the front of the gate."), {"ufo": _pick_portal_front, "hold": 700}),
		_s(I, L.t("Kapıdan sıradaki UFO çıktı. Kapıdaki sayı (+N) kaç UFO daha beklediğini gösterir.", "The next UFO came out of the gate. The number on the gate (+N) shows how many more UFOs are waiting."),
			{"title": L.t("Yeni UFO geldi!", "A new UFO arrived!"), "button": ok_s,
			"ufo": _t_spawn_new})]}

# ------------------------------------------------------------ çizim

func _ease_in_out_cubic(t: float) -> float:
	return 4.0 * t * t * t if t < 0.5 else 1.0 - pow(-2.0 * t + 2.0, 3.0) / 2.0

func _ease_out(t: float) -> float:
	return 1.0 - (1.0 - t) * (1.0 - t)   # Curves.easeOut yaklaşığı (cubic-bezier .0,.0,.58,1)

func _ease_in(t: float) -> float:
	return t * t

func _ease_in_out(t: float) -> float:
	return t * t * (3.0 - 2.0 * t)

func _ease_out_cubic(t: float) -> float:
	return 1.0 - pow(1.0 - t, 3.0)

func _ease_in_cubic(t: float) -> float:
	return t * t * t

func _ease_out_back(t: float) -> float:
	var c1 := 1.70158
	var c3 := c1 + 1.0
	return 1.0 + c3 * pow(t - 1.0, 3.0) + c1 * pow(t - 1.0, 2.0)

func _draw() -> void:
	if game == null:
		return
	var W := size.x
	var H := size.y - _safe_bottom()
	last_w = W
	last_h = H
	last_top = _safe_top()
	var g := _geom(W, H)
	var now := Time.get_ticks_msec()
	var clock_v := fmod(now / 1000.0, 1.0)
	_hit_rects = []
	# arka plan
	UI.draw_cover(self, UI.tex("bg_station"), Rect2(Vector2.ZERO, size))
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 70.0 / 255.0))

	# halka + kollar görseli
	var shp: Dictionary = g.shape
	var rt := UI.tex(String(shp["asset"]).replace("res://assets/img/", "").replace(".webp", ""))
	UI.draw_clipped(self, rt, Rect2(g.img_left, g.ring_top, shp["imgW"] * g.sc, shp["imgH"] * g.sc), Rect2(0, g.ring_top, W, g.ring_h))

	# zemin paneli
	_draw_panel(g)
	# katman parıltısı
	var el := now - layer_flash_ms
	if el >= 0 and el <= 900:
		var f := el / 900.0
		var pr := Rect2(g.panel_left - 6, g.panel_top - 6, g.panel_w + 12, g.panel_h + 12)
		var pts := UI.rrect_pts(pr, 16)
		var cols := PackedColorArray()
		var stop := clampf(0.25 + 0.75 * f, 0.05, 1.0)
		for p in pts:
			var tt := 1.0 - (p.y - pr.position.y) / pr.size.y  # alttan yukarı
			var a := (160.0 * (1 - f) / 255.0) * clampf(1.0 - tt / stop, 0.0, 1.0)
			cols.append(Color(0.224, 0.902, 1.0, a))
		draw_polygon(pts, cols)

	_draw_ring_layer(g, now)
	_draw_slots(g)
	_draw_beams(g, now)
	for f2 in flies:
		_draw_fly(f2, g.alien, now)
	_draw_belts(g)
	_draw_portals(g, now, clock_v)
	_draw_ufos(g, now)
	_draw_counters(g, now)
	_draw_beaming(g)

	if vip_armed:
		var s := L.t("Bir UFO seç → VIP yuvaya ışınlansın", "Pick a UFO → teleport it to the VIP slot")
		var w := UI.text_width(s, 14, true) + 28
		var r := Rect2((W - w) / 2.0, g.slots_top + g.slots_h + 4, w, 32)
		UI.fill_rrect(self, r, 16, UI.argb(0xEEFFA000))
		UI.text_c(self, r, s, 14, Color.WHITE, true)

	# HUD degradesi
	var gh := g.top_inset + g.hud_h + 14
	for i in 12:
		var t0 := float(i) / 12
		draw_rect(Rect2(0, gh * t0, W, gh / 12 + 1), Color(0, 0, 0, 150.0 / 255.0 * (1.0 - t0)))
	_draw_hud(g)

	if message != null:
		var mw := UI.text_width(message, 14, true) + 32
		var mr := Rect2((W - mw) / 2.0, g.slots_top + g.slots_h + 4, mw, 36)
		UI.fill_rrect(self, mr, 20, UI.argb(0xEE37474F))
		UI.text_c(self, mr, message, 14, Color.WHITE, true)

	_draw_boosters(g, clock_v)
	_draw_tut_layer(g, W, H, clock_v)

func _draw_panel(g: G) -> void:
	var pr := Rect2(g.panel_left - 6, g.panel_top - 6, g.panel_w + 12, g.panel_h + 12)
	var tx := UI.tex("floor_tile")
	var ts := tx.get_size() / 2.2
	var pts := UI.rrect_pts(pr, 16)
	var uvs := PackedVector2Array()
	var ctr := pr.get_center()
	for p in pts:
		uvs.append(Vector2((p.x - ctr.x) / ts.x + 0.5, (p.y - ctr.y) / ts.y + 0.5))
	draw_colored_polygon(pts, Color(0.824, 0.824, 0.824, 1), uvs, tx)
	UI.stroke_rrect(self, Rect2(pr.position + Vector2(1, 1), pr.size - Vector2(2, 2)), 15, Color(0.224, 0.902, 1.0, 136.0 / 255.0), 2.0)

func _draw_ring_layer(g: G, now: int) -> void:
	# kapılar
	var n := game.slots.size()
	var half: float = g.road_w / 2.0 + 2.0
	for k in n:
		var id: int = game.slots[k]
		var col = null
		if id >= 0 and not game.ufos[id].departed:
			col = UI.COLORS[game.ufos[id].spec.color]
		var ft = gate_flash.get(k, null)
		var glow := 0.0
		if ft != null:
			glow = maxf(0.0, 1.0 - (now - ft) / 350.0)
		var p := _path_at(g, GameState.gate_s(k, n))
		var a := Vector2(p["x"] - p["nx"] * half, p["y"] - p["ny"] * half)
		var b := Vector2(p["x"] + p["nx"] * half, p["y"] + p["ny"] * half)
		if col != null and glow > 0.0:
			draw_line(a, b, UI.with_a(col, 45.0 * glow), (9 + 6 * glow) * 1.8, true)
			draw_line(a, b, UI.with_a(col, 90.0 * glow), 9 + 6 * glow, true)
		draw_line(a, b, UI.with_a(col, 235) if col != null else UI.argb(0x44FFFFFF), 3.5 if col != null else 2.0, true)
	# yolcular
	var dots: Array = []
	var ks: float = g.alien * (KERNEL_SIZE / 20.0)
	for a in 2:
		var taken: int = game.arm_head[a]
		var total_len: float = g.arm_cum[a].back()
		var arm_dots: Array = []
		for j in range(ARM_ROWS * ARM_LANES + 3):
			if taken + j >= game.arm_q[a].size():
				break
			var pos: float = j + (taken - arm_vis[a])
			var q: float = g.arm_wait + (pos / ARM_LANES) * ARM_GAP * g.k
			if q > total_len:
				break
			var lane := (taken + j) % ARM_LANES
			var off := (lane - (ARM_LANES - 1) / 2.0) * ARM_LANE_GAP * g.k
			var color: int = game.arm_q[a][taken + j]
			for k in KERNELS:
				var dq := (k - (KERNELS - 1) / 2.0) * (ARM_GAP * g.k / (KERNELS * 2.0))
				var pt := _arm_point(g, a, q + dq, off)
				arm_dots.append([pt.x, pt.y, ks * 0.9, color, 1.0])
		arm_dots.reverse()
		dots.append_array(arm_dots)
	var ring_dots: Array = []
	var cols := game.ring_cols()
	for i in game.cells.size():
		var p = game.cells[i]
		if p == null:
			continue
		if not birth.has(p.id):
			birth[p.id] = now
		var age: int = now - birth[p.id]
		var fade := clampf(age / 250.0, 0.0, 1.0)
		for k in KERNELS:
			var ds := (k - (KERNELS - 1) / 2.0) * (0.5 / cols)
			var pp := _path_at(g, game.cell_s(i) + ds)
			var lo := ((i % GameState.RING_LANES) - (GameState.RING_LANES - 1) / 2.0) * maxf(pp["gap"], 4.0)
			var pt := Vector2(pp["x"] + pp["nx"] * lo, pp["y"] + pp["ny"] * lo)
			if age < 260:
				var from := _arm_point(g, p.id % 2, g.arm_wait, 0.0)
				var e := _ease_out(age / 260.0)
				pt = from + (pt - from) * e
			var depth := clampf((pt.y - (g.cy - g.r)) / (2 * g.r), 0.0, 1.0)
			ring_dots.append([pt.x, pt.y, ks * (0.92 + 0.16 * depth) * (0.6 + 0.4 * fade), p.color, 1.0])
	ring_dots.sort_custom(func(a, b): return a[1] < b[1])
	dots.append_array(ring_dots)
	for d in dots:
		var tex := UI.alien_small(d[3])
		draw_texture_rect(tex, Rect2(d[0] - d[2] / 2.0, d[1] - d[2] * 0.62, d[2], d[2]), false, Color(1, 1, 1, d[4]))

func _draw_slots(g: G) -> void:
	var open_count := game.slots.size()
	var last_free := game.free_slot_count() == 1 and open_count >= 3
	for k in g.slot_count:
		var left: float = g.slots_left + k * g.slot_size
		var rect := Rect2(left, g.pad_top(), g.slot_size, g.slot_size)
		if k >= open_count:
			UI.draw_contain(self, UI.tex("pad_locked"), rect, Color(1, 1, 1, 0.85))
			var bw := UI.text_width("+ ▶", 11, true) + 12
			var br := Rect2(left + (g.slot_size - bw) / 2.0, rect.end.y - 2 - 15, bw, 15)
			UI.fill_rrect(self, br, 8, UI.argb(0xCC1B8E3E))
			UI.text_c(self, br, "+ ▶", 11, Color.WHITE, true)
			_hit_rects.append([rect, "slot", k])
			continue
		var is_free: bool = game.slots[k] == -1
		var vip := game.is_vip_slot(k)
		var t := UI.tex("pad_empty")
		if vip:
			t = UI.tinted("pad_empty", UI.argb(0xAAFFC400))
		elif last_free and is_free:
			t = UI.tinted("pad_empty", UI.argb(0xAAFF1744))
		UI.draw_contain(self, t, rect)
		if vip:
			UI.text_c(self, Rect2(left, g.pad_top() + g.slot_size - 14, g.slot_size, 14), "VIP", 11, UI.argb(0xFFFFC400), true)

func _draw_beams(g: G, now: int) -> void:
	for u in game.ufos:
		var id: int = u.spec.id
		var pend: int = pending.get(id, 0)
		if u.in_grid:
			continue
		if u.departed and pend == 0:
			continue
		var sz := _hover_size(g, u.spec.seats)
		var k := maxi(0, u.last_slot)
		var cx := _hover_cx(g, k)
		var stand := _pad_stand(g, k)
		var beam_top := _hover_bottom(g, sz) - sz * 0.10
		var beam_bottom := stand.y + g.slot_size * 0.10
		var beam_w := g.slot_size * 0.92
		var recent: bool = now - int(last_board.get(id, 0)) < 350
		var show: bool = landed.has(id) and (pend > 0 or recent)
		var col: Color = UI.COLORS[u.spec.color]
		# animasyonlu opaklık (220 ms)
		var key := "bo%d" % id
		var cur: float = float(_anim_val.get(key, 0.0))
		var tgt := 1.0 if show else 0.0
		cur = move_toward(cur, tgt, get_process_delta_time() / 0.22)
		_anim_val[key] = cur
		if cur <= 0.0:
			continue
		draw_texture_rect(UI.radial_tex(), Rect2(cx - g.slot_size * 0.36, stand.y - g.slot_size * 0.11, g.slot_size * 0.72, g.slot_size * 0.22), false, UI.with_a(col, 170.0 * cur))
		draw_texture_rect(UI.tex("beam"), Rect2(cx - beam_w / 2.0, beam_top, beam_w, maxf(8.0, beam_bottom - beam_top)), false, Color(1, 1, 1, 0.85 * cur))

var _anim_val := {}

func _draw_fly(f: Dictionary, alien: float, now: int) -> void:
	var mini_sz := alien * (KERNEL_SIZE / 20.0) * 1.1
	var t := clampf((now - f["t0"]) / float(FLY_MS), 0.0, 1.0)
	for k in range(KERNELS - 1, -1, -1):
		var delay := 0.16 * k
		var tt := clampf((t - delay) / (1.0 - delay), 0.0, 1.0)
		var lat := (k - (KERNELS - 1) / 2.0) * 9.0
		var x := 0.0
		var y := 0.0
		var sz := 0.0
		var op := 1.0
		var tilt := 0.0
		if tt < WALK_FRAC:
			var w := _ease_in(tt / WALK_FRAC) * 0.35 + (tt / WALK_FRAC) * 0.65
			var side := -1.0 if f["fx"] <= f["px"] else 1.0
			var step := sin(w * PI * 7)
			x = f["fx"] + (f["px"] - f["fx"]) * w + side * sin(w * PI) * 6 + lat * (1.0 - 0.6 * w)
			y = f["fy"] + (f["py"] - f["fy"]) * w - absf(step) * 4.0
			tilt = step * 0.2
			sz = mini_sz * (1.0 - 0.06 * w)
			op = 1.0
		else:
			var b := _ease_in((tt - WALK_FRAC) / (1.0 - WALK_FRAC))
			x = f["px"] + lat * 0.4 * (1.0 - b) + (f["tx"] - f["px"]) * b
			y = f["py"] + (f["ty"] - f["py"]) * b
			sz = maxf(7.0, mini_sz * 0.95 * (1.0 - 0.5 * b))
			op = 1.0 - 0.3 * b
		var c := Vector2(x, y - sz * 0.62 + sz / 2.0)
		draw_set_transform(c, tilt, Vector2.ONE)
		UI.draw_contain(self, UI.tex("alien_" + UI.COLOR_NAMES[f["color"]]), Rect2(Vector2(-sz / 2.0, -sz / 2.0), Vector2(sz, sz)), Color(1, 1, 1, op))
		draw_set_transform_matrix(Transform2D.IDENTITY)

func _draw_belts(g: G) -> void:
	for u in game.ufos:
		if not u.belt or not u.in_grid or not u.spawned:
			continue
		var c := _ufo_center(g, u.spec)
		var bw: float = g.unit * 2.8
		var bh := bw / 3.0
		draw_set_transform(c, u.spec.angle, Vector2.ONE)
		draw_texture_rect(UI.tex("belt"), Rect2(-bw / 2.0, -bh / 2.0, bw, bh), false)
		draw_set_transform_matrix(Transform2D.IDENTITY)

func _draw_portals(g: G, now: int, clock_v: float) -> void:
	for gid in game.groups:
		var members: Array = game.groups[gid]
		if members.size() < 2:
			continue
		if level.layer_of_ufo(members[0]) != game.cur_layer:
			continue
		var left := 0
		var waiting := 0
		var big := 4
		for id in members:
			var mu = game.ufos[id]
			big = maxi(big, mu.spec.seats)
			if mu.in_grid:
				left += 1
				if not mu.spawned:
					waiting += 1
		if left == 0:
			continue
		var c := _ufo_center(g, game.ufos[members[0]].spec)
		var d: float = g.unit * Models.ufo_diameter(big) * g.ufo_scale * 1.3
		var pulse := 0.5 + 0.5 * sin(clock_v * TAU)
		var fl = portal_flash.get(gid, null)
		var fe := 1.0 if fl == null else clampf((now - fl) / 700.0, 0.0, 1.0)
		draw_texture_rect(UI.radial_tex(), Rect2(c - Vector2(d, d) / 2.0, Vector2(d, d)), false, Color(0.486, 0.302, 1.0, (60 + 50 * pulse) / 255.0 * 0.0 + 0.5))
		draw_circle(c, d / 2.0 * 0.62, Color(0.224, 0.902, 1.0, (70 + 40 * pulse) / 255.0))
		draw_circle(c, d / 2.0 * 0.3, Color(0.486, 0.302, 1.0, (60 + 50 * pulse) / 255.0))
		draw_arc(c, d / 2.0 - 1, 0, TAU, 48, Color(0.224, 0.902, 1.0, (150 + 80 * pulse) / 255.0), 2.0, true)
		if fe < 1.0:
			draw_arc(c, d / 2.0 * (1.0 + 0.7 * fe), 0, TAU, 48, Color(1, 1, 1, 220.0 / 255.0 * (1 - fe)), 3.0, true)
		if waiting > 0:
			var s := "+%d" % waiting
			var bw := UI.text_width(s, 10, true) + 10
			var br := Rect2(c.x - bw / 2.0, c.y + d / 2.0 - 8, bw, 14)
			UI.fill_rrect(self, br, 8, UI.argb(0xFF5E35B1))
			UI.stroke_rrect(self, br, 8, Color.WHITE, 1.2)
			UI.text_c(self, br, s, 10, Color.WHITE, true)

func _ufo_rect_now(g: G, u, now: int) -> Rect2:
	var id: int = u.spec.id
	if u.in_grid:
		var sz := _grid_ufo_px(g, u.spec)
		var c := _ufo_center(g, u.spec)
		return Rect2(c - Vector2(sz, sz) / 2.0, Vector2(sz, sz))
	var k := maxi(0, u.last_slot)
	var sz2 := _hover_size(g, u.spec.seats)
	var to := Rect2(_hover_cx(g, k) - sz2 / 2.0, _hover_cy(g, sz2) - sz2 / 2.0, sz2, sz2)
	if launch_from.has(id):
		var lf: Array = launch_from[id]
		var t := clampf((now - lf[1]) / float(lf[2]), 0.0, 1.0)
		if t >= 1.0:
			return to
		var e := _ease_in_out_cubic(t)
		var fr: Rect2 = lf[0]
		return Rect2(fr.position.lerp(to.position, e), fr.size.lerp(to.size, e))
	return to

func _draw_ufos(g: G, now: int) -> void:
	for u in game.ufos:
		var id: int = u.spec.id
		var pend: int = pending.get(id, 0)
		var fly_away: bool = u.departed and pend == 0 and now - int(last_board.get(id, 0)) >= FLY_MS + DEPART_WAIT_MS
		if fly_away and not depart_start.has(id):
			depart_start[id] = now
			Audio.play(Audio.Sfx.UFO_DEPART)
		if u.in_grid and not u.spawned:
			continue
		var rect := _ufo_rect_now(g, u, now)
		var size_px := rect.size.x
		var home_left := rect.position.x
		var home_size := size_px
		var blocked: bool = u.in_grid and not game.can_launch(id)
		var hidden: bool = u.spec.mystery and blocked
		var center := rect.get_center()
		# dokunma kutusu
		if u.in_grid:
			var box := maxf(size_px, MIN_TAP)
			var box_h := box
			if _fit_for(g, id) > 1.0:
				box_h = maxf(size_px * _sprite_h(u.spec.seats) + 4.0, MIN_TAP * 0.8)
			var hc := center
			if u.belt:
				hc += Vector2(cos(u.spec.angle), sin(u.spec.angle)) * game.belt_pos(u) * g.unit * 0.9
			_hit_rects.append([Rect2(hc - Vector2(box, box_h) / 2.0, Vector2(box, box_h)), "ufo", id])
		# dönüşüm zinciri
		var xf := Transform2D(0.0, center)
		# yeni belirme + zıplama
		var sp_t := 1.0
		if spawn_ms.has(id):
			sp_t = clampf((now - spawn_ms[id]) / 260.0, 0.0, 1.0)
		var spawn_sc := _ease_out_back(sp_t) if sp_t < 1.0 else 1.0
		var bounce := 1.12 if bouncing.has(id) else 1.0
		xf = xf.scaled_local(Vector2.ONE * spawn_sc * bounce)
		var shimmer_fade := 0.0
		var shimmer_p := 0.0
		var sx := 1.0
		if u.in_grid:
			var b = bumps.get(id, null)
			if b != null:
				var el: int = now - b[0]
				if el < BUMP_MS:
					var t := el / float(BUMP_MS)
					var f := _ease_out(t / 0.42) if t < 0.42 else 1.0 - _ease_in((t - 0.42) / 0.58)
					var dist: float = b[1] * g.unit + g.unit * 0.12
					xf = xf.translated_local(Vector2(u.cur.dir_x() * (b[1] * g.unit_x + g.unit * 0.12) * f, u.cur.dir_y() * dist * f))
			if u.belt:
				var p := game.belt_pos(u)
				var amp: float = g.unit * 0.9
				xf = xf.translated_local(Vector2(cos(u.spec.angle) * p * amp, sin(u.spec.angle) * p * amp))
		else:
			var tms := now
			var ds = depart_start.get(id, null)
			var ls = spin_start.get(id, null)
			var ang := 0.0
			var fade := 0.0
			if ds != null:
				var f2 := clampf((tms - ds) / float(DEPART_MS), 0.0, 1.0)
				if f2 < 1.0:
					ang = TAU * 2 * _ease_in_out(f2)
					fade = _spin_fade(f2)
			elif ls != null:
				var f3 := clampf((tms - ls) / float(LAND_MS), 0.0, 1.0)
				if f3 < 1.0:
					ang = TAU * _ease_in_out(f3)
					fade = _spin_fade(f3)
			var shift := Vector2.ZERO
			if ds != null:
				var f4 := clampf((tms - ds) / float(DEPART_MS), 0.0, 1.0)
				var rise := DEPART_RISE * home_size
				if f4 < DEPART_SPLIT:
					shift = Vector2(0, -rise * _ease_out_cubic(f4 / DEPART_SPLIT))
				else:
					var q := clampf((f4 - DEPART_SPLIT) / (1 - DEPART_SPLIT), 0.0, 1.0)
					var dx := (g.W + home_size * 1.5) - home_left
					shift = Vector2(dx * _ease_in_cubic(q), -rise - home_size * 0.15 * q)
			xf = xf.translated_local(shift)
			if fade > 0.0:
				shimmer_fade = fade
				shimmer_p = fmod(ang / TAU * 3.0, 1.0)
				sx = 1.0 - 0.07 * fade * (1 - cos(ang * 3)) / 2.0
				xf = xf.scaled_local(Vector2(sx, 1.0))
			# titreme / süzülme
			var amp2 := 0.0
			if landed.has(id):
				if pend > 0:
					amp2 = 1.0
				else:
					var last = last_board.get(id, null)
					if last != null:
						amp2 = maxf(0.0, 1.0 - (tms - last) / 320.0)
			var sec := tms / 1000.0
			var hovering: bool = landed.has(id) and not depart_start.has(id)
			var bob := sin(sec * 2.4 + id * 1.3) * 2.2 if hovering else 0.0
			if amp2 > 0:
				xf = xf.translated_local(Vector2(sin(sec * 62) * 2.6 * amp2, cos(sec * 77) * 2.0 * amp2 + bob))
				xf = xf.rotated_local(sin(sec * 48) * 0.055 * amp2)
			elif bob != 0.0:
				xf = xf.translated_local(Vector2(0, bob))
		draw_set_transform_matrix(xf)
		_xf_cache = xf
		_draw_ufo_body(g, u, size_px, blocked, hidden, shimmer_fade, shimmer_p)
		draw_set_transform_matrix(Transform2D.IDENTITY)

func _draw_ufo_body(g: G, u, size_px: float, blocked: bool, hidden: bool, shimmer_fade: float, shimmer_p: float) -> void:
	var nm: String = "ufo%d_%s" % [_ufo_class(u.spec.seats), UI.COLOR_NAMES[u.spec.color]]
	var arrow_size := maxf(13.0, size_px * (0.3 if hidden else 0.44))
	var box := Rect2(Vector2(-size_px / 2.0, -size_px / 2.0), Vector2(size_px, size_px))
	var t: Texture2D = UI.mystery(nm) if hidden else UI.tex(nm)
	UI.draw_contain(self, t, box)
	if shimmer_fade > 0.0:
		var wt := UI.white_of(nm)
		var ts := t.get_size()
		var sc := minf(size_px / ts.x, size_px / ts.y)
		var dsz := ts * sc
		var dpos := -dsz / 2.0
		var strips := 28
		var cxp := -1.7 + 3.4 * shimmer_p
		for i in strips:
			var ax := -1.0 + 2.0 * (i + 0.5) / strips
			var tt := ((ax - (cxp - 0.6)) * 1.2 + 0.5 * 1.0) / (1.44 + 1.0)
			var a := 0.0
			if tt > 0.0 and tt < 1.0:
				a = (1.0 - absf(tt - 0.5) * 2.0) * (150.0 * shimmer_fade / 255.0)
			if a <= 0.0:
				continue
			var sw := dsz.x / strips
			var dst := Rect2(dpos.x + sw * i, dpos.y, sw + 0.5, dsz.y)
			var src := Rect2(ts.x * i / strips, 0, ts.x / strips, ts.y)
			draw_texture_rect_region(wt, dst, src, Color(1, 1, 1, a))
	var a_ang: float = u.cur.angle
	if u.rotor:
		var since: float = game.clock - u.flip_clock
		if since >= 0 and since < 0.35:
			a_ang = u.cur.angle - PI * (1 - _ease_out(since / 0.35))
	var warn: bool = u.rotor and u.in_grid and game.rot_time_left(u) < 0.7
	var blink: bool = warn and sin(game.clock * 20) > 0
	var arrow_at := 0.72 if hidden else 0.5
	if u.rotor and u.in_grid:
		draw_arc(Vector2.ZERO, size_px / 2.0 - 1.25, 0, TAU, 40, UI.argb(0xFFFFC400) if blink else UI.argb(0xFF40C4FF), 2.5, true)
	if u.belt and u.in_grid:
		var open := game.belt_open(u)
		draw_arc(Vector2.ZERO, size_px / 2.0 - 1.0, 0, TAU, 40, UI.argb(0xFF69F0AE) if open else UI.argb(0x66FFFFFF), 3.0 if open else 1.5, true)
	if u.in_grid:
		var half := (size_px - arrow_size) / 2.0
		var ac := Vector2(sin(a_ang) * arrow_at * half, -cos(a_ang) * arrow_at * half)
		draw_circle(ac, arrow_size / 2.0, Color(1, 1, 1, 235.0 / 255.0))
		draw_arc(ac, arrow_size / 2.0 - 1.0, 0, TAU, 24, Color(0.5, 0.5, 0.5) if hidden else UI.COLORS[u.spec.color], 2.0, true)
		var xf0 := Transform2D(a_ang, ac)
		draw_set_transform_matrix(_cur_xf() * xf0)
		UI.icon_arrow_up(self, Vector2.ZERO, arrow_size * 0.74 * 1.15, Color(0, 0, 0, 0.87))
		draw_set_transform_matrix(_cur_xf())
	if u.is_faulty() and u.in_grid:
		var s := "🔧%d" % u.fault
		var fs := maxf(9.0, size_px * 0.27)
		var bw := UI.text_width(s, fs, true) + 8
		var bh := fs * 1.15 + 2
		var half_x := (size_px - bw) / 2.0
		var half_y := (size_px - bh) / 2.0
		var br := Rect2(Vector2(0.85 * half_x - bw / 2.0, -0.9 * half_y - bh / 2.0), Vector2(bw, bh))
		UI.fill_rrect(self, br, 8, UI.argb(0xFFD32F2F) if u.fault <= 3 else UI.argb(0xFFEF6C00))
		UI.stroke_rrect(self, br, 8, Color.WHITE, 1.2)
		UI.text_c(self, br, s, fs, Color.WHITE, true)
	if hidden:
		var qs := maxf(18.0, size_px * 0.62)
		UI.text_c(self, Rect2(-size_px / 2.0, -0.1 * (size_px - qs) / 2.0 - qs / 2.0, size_px, qs), "?", qs, Color.WHITE, true, Color(0, 0, 0, 0.8))

var _xf_cache := Transform2D.IDENTITY
func _cur_xf() -> Transform2D:
	return _xf_cache

func _draw_counters(g: G, now: int) -> void:
	for u in game.ufos:
		var id: int = u.spec.id
		if u.in_grid or not landed.has(id):
			continue
		var pend: int = pending.get(id, 0)
		var gone: bool = u.departed and pend == 0 and now - int(last_board.get(id, 0)) >= FLY_MS + DEPART_WAIT_MS
		if gone:
			continue
		var k := maxi(0, u.last_slot)
		var remain: int = maxi(0, u.spec.seats - maxi(0, u.boarded - pend)) * Models.CAP_PER_PASSENGER
		var cap_full := float(u.spec.capacity())
		var val := int(clampi(int(ceil(cnt.get(id, cap_full))), remain, u.spec.capacity()))
		var s := str(val)
		var tw := UI.text_width(s, 12, true)
		var bw := tw + 14 + 3
		var bh := 12 * 1.25 + 3
		var area := Rect2(g.slots_left + k * g.slot_size, g.pad_top() + g.slot_size - 6, g.slot_size, COUNTER_BOX - 2)
		var br := Rect2(area.get_center().x - bw / 2.0, area.get_center().y - bh / 2.0, bw, bh)
		UI.fill_rrect(self, br, 9, Color(0, 0, 0, 185.0 / 255.0))
		UI.stroke_rrect(self, Rect2(br.position + Vector2(0.75, 0.75), br.size - Vector2(1.5, 1.5)), 8, UI.COLORS[u.spec.color], 1.5)
		UI.text_c(self, br, s, 12, Color.WHITE, true)

func _draw_beaming(g: G) -> void:
	for id in beaming:
		var from = beam_from.get(id, null)
		if from != null:
			draw_texture_rect(UI.tex("beam"), Rect2(from.x - 24, from.y - 52, 48, 78), false, Color(1, 1, 1, 0.9))
			UI.text_c(self, Rect2(from.x - 12, from.y - 14, 24, 28), "✨", 24, Color.WHITE, false)
		draw_texture_rect(UI.tex("beam"), Rect2(g.slots_left + g.slot_size / 2.0 - g.slot_size * 0.46, g.slots_top + g.hover_h * 0.25, g.slot_size * 0.92, g.hover_h * 0.75 + g.slot_size * 0.5), false, Color(1, 1, 1, 0.9))

func _draw_hud(g: G) -> void:
	var W := g.W
	var top := g.top_inset
	var hh := g.hud_h
	var cy := top + hh / 2.0
	_hit_rects.append([Rect2(0, top, 48, hh), "back", null])
	UI.icon_arrow_back(self, Vector2(24, cy), 24, Color.WHITE)
	_hit_rects.append([Rect2(W - 48, top, 48, hh), "refresh", null])
	UI.icon_refresh(self, Vector2(W - 24, cy), 24, Color.WHITE)
	var coin_s := str(Progress.coins)
	var cw := UI.text_width(coin_s, 16, true)
	var tx := W - 48 - cw
	UI.text_c(self, Rect2(tx, top, cw + 2, hh), coin_s, 16, Color.WHITE, true)
	var coin_x := tx - 4 - 24
	draw_texture_rect(UI.tex("coin"), Rect2(coin_x, cy - 12, 24, 24), false)
	var cx := (48 + coin_x) / 2.0
	var title := L.t("Seviye %d%s" % [level.number, "  •  ZOR" if level.is_hard() else ""], "Level %d%s" % [level.number, "  •  HARD" if level.is_hard() else ""])
	var rl := _rules_line()
	var tcol := UI.argb(0xFFFFC400) if level.is_hard() else Color.WHITE
	var ty := cy - (10.0 if rl != "" else 0.0)
	UI.text_c(self, Rect2(cx - 150, ty - 12, 300, 24), title, 20, tcol, true)
	if rl != "":
		var rc := UI.argb(0xFFFF8A80) if (level.rules.move_budget > 0 and game.moves_left() <= 3) else Color(1, 1, 1, 0.7)
		UI.text_c(self, Rect2(cx - 150, ty + 12, 300, 14), rl, 11.5, rc, true)

func _draw_boosters(g: G, clock_v: float) -> void:
	var W := g.W
	var items := [
		["booster_board", L.t("Hemen Bin", "Board Now"), UNLOCK_BOARD, 0],
		["booster_shuffle", L.t("Karıştır", "Shuffle"), UNLOCK_SHUFFLE, 1],
		["booster_vip", L.t("Seç…", "Pick…") if vip_armed else L.t("Işınla", "Teleport"), Models.VIP_UNLOCK_LEVEL, 2]]
	var widths: Array = []
	var total := 0.0
	for it in items:
		var lab: String = L.t("Sv %d" % it[2], "Lv %d" % it[2]) if level.number < it[2] else it[1]
		var w := maxf(58.0, UI.text_width(lab, 12, true))
		widths.append(w)
		total += w
	var gap := (W - total) / 4.0
	var x := gap
	var row_top := g.H - 6.0 - (g.boost_h - 6.0)
	var col_h := 52.0 + 2.0 + 15.0
	var top := row_top + (g.boost_h - 6.0 - col_h) / 2.0
	for i in 3:
		var it: Array = items[i]
		var w: float = widths[i]
		var locked: bool = level.number < it[2]
		var stock: int = Progress.boost_stock[it[3]]
		var glow: bool = new_boost == it[3] and not locked
		var pulse := 0.5 + 0.5 * sin(clock_v * TAU)
		var mod := Color(1, 1, 1, 1.0 if not ended and not locked else 0.4)
		var bx := x + (w - 58.0) / 2.0
		var ic := Vector2(bx + 29, top + 26)
		boost_rects[i] = Rect2(ic.x - 23, ic.y - 23, 46, 46)
		if glow:
			draw_texture_rect(UI.radial_tex(), Rect2(ic - Vector2(40, 40), Vector2(80, 80)), false, Color(1, 0.76, 0.03, (140 + 100 * pulse) / 255.0 * 0.8))
		draw_texture_rect(UI.tex(it[0]), Rect2(ic - Vector2(23, 23), Vector2(46, 46)), false, mod)
		if locked:
			UI.icon_lock(self, ic, 22, Color.WHITE)
		else:
			if stock > 0:
				var s := str(stock)
				var bw := maxf(20.0, UI.text_width(s, 12, true) + 10)
				var br := Rect2(bx + 58 - bw, top, bw, 20)
				UI.fill_rrect(self, br, 10, UI.argb(0xFFE53935))
				UI.stroke_rrect(self, br, 10, Color.WHITE, 1.5)
				UI.text_c(self, br, s, 12, Color.WHITE, true)
			var pr := Rect2(bx + 58 - 24, top + 52 - 24, 24, 24)
			draw_circle(pr.get_center(), 12, UI.argb(0xFF2E9E4F))
			draw_arc(pr.get_center(), 11.25, 0, TAU, 24, Color.WHITE, 1.5, true)
			UI.icon_plus(self, pr.get_center(), 24, Color.WHITE)
			_hit_rects.append([pr, "booster", [it[3], "plus"]])
		var lab: String = L.t("Sv %d" % it[2], "Lv %d" % it[2]) if locked else it[1]
		UI.text_c(self, Rect2(x, top + 54, w, 15), lab, 12, mod, true)
		_hit_rects.append([Rect2(x, top, w, col_h), "booster", [it[3], "use"]])
		x += w + gap

# ---- öğretici katmanı

func _key_rect_inflate(r: Rect2, v: float) -> Rect2:
	return Rect2(r.position - Vector2(v, v), r.size + Vector2(v, v) * 2.0)

func _draw_tut_layer(g: G, W: float, H: float, clock_v: float) -> void:
	var st = _step()
	if tut == null or st == null or ended:
		return
	var guide: Dictionary = tut
	var holes: Array = []   # [Rect2, radius]
	var hand_at = null
	var boost_rect = null
	if st.has("ufo") and tut_ufo != null and game.ufos[tut_ufo].in_grid:
		var u = game.ufos[tut_ufo]
		var c := _ufo_center(g, u.spec)
		var sz := _grid_ufo_px(g, u.spec)
		var rr := maxf(sz * 0.62, 26.0)
		holes.append([Rect2(c - Vector2(rr, rr), Vector2(rr, rr) * 2.0), rr])
		if st["kind"] == TutKind.TAP_UFO:
			hand_at = c
	if st.has("boost"):
		var r: Rect2 = boost_rects[st["boost"]]
		holes.append([_key_rect_inflate(r, 6), 14.0])
		boost_rect = _key_rect_inflate(r, 6)
		hand_at = r.get_center()
	match st.get("region", ""):
		"ring": holes.append([_key_rect_inflate(Rect2(4, g.ring_top, W - 8, g.ring_h), 6), 14.0])
		"pads": holes.append([_key_rect_inflate(Rect2(g.slots_left, g.slots_top, g.slot_size * g.slot_count, g.hover_h + g.slot_size + COUNTER_H), 6), 14.0])
		"vip": holes.append([_key_rect_inflate(Rect2(g.slots_left, g.slots_top, g.slot_size, g.hover_h + g.slot_size + COUNTER_H), 6), 14.0])
		"hud": holes.append([_key_rect_inflate(Rect2(W * 0.2, g.top_inset, W * 0.6, g.hud_h), 6), 14.0])
		"counter":
			var k := 0
			if tut_mem != null and not game.ufos[tut_mem].in_grid:
				k = maxi(0, game.ufos[tut_mem].last_slot)
			holes.append([_key_rect_inflate(Rect2(g.slots_left + k * g.slot_size, g.pad_top() + g.slot_size - 6, g.slot_size, COUNTER_BOX), 6), 14.0])
	var fy := H * 0.5
	if not holes.is_empty():
		var sum := 0.0
		for h in holes:
			sum += (h[0] as Rect2).get_center().y
		fy = sum / holes.size()
	var card_top := fy > H * 0.5
	var is_info: bool = st["kind"] == TutKind.INFO
	# karartma
	if st["kind"] != TutKind.WATCH:
		_dim_with_holes(W, H, holes)
	# bilgi adımında oyuna dokunuşu engelle (en altta)
	if is_info:
		_hit_rects.append([Rect2(0, 0, W, size.y), "tut_block", null])
		if boost_rect != null:
			_hit_rects.append([boost_rect, "tut_next", null])
	var pulse := 0.5 + 0.5 * sin(clock_v * TAU)
	for h in holes:
		var r: Rect2 = h[0]
		var rr2 := _key_rect_inflate(r, 2 + 4 * pulse)
		UI.stroke_rrect(self, rr2, float(h[1]) + 2 + 4 * pulse, Color(1.0, 0.76, 0.03, 220.0 / 255.0), 3.0)
	if hand_at != null:
		var hp: Vector2 = hand_at + Vector2(0, 9 * sin(clock_v * TAU))
		UI.icon_hand(self, hp + Vector2(0, 6), 46, Color.WHITE, Color(0, 0, 0, 0.6))
	# kart
	var cw := minf(380.0, W - 32.0)
	var tl := UI.wrap(st["text"], 14.5, cw - 32.0, true)
	var ch := 24.0 + tl.size() * 14.5 * 1.35
	if st["title"] != "":
		ch += 24 + 6
	if is_info:
		ch += 10 + 40
	ch += 2 + 28
	var cy := (g.top_inset + g.hud_h + 8) if card_top else (g.H - g.boost_h - 10 - ch)
	var card := Rect2((W - cw) / 2.0, cy, cw, ch)
	UI.shadow_rrect(self, card, 18, Color(0, 0, 0, 0.5), 12.0)
	UI.fill_rrect(self, card, 18, UI.argb(0xF22B1F6B))
	UI.stroke_rrect(self, card, 18, Color(1.0, 0.76, 0.03), 1.5)
	var y := card.position.y + 12
	if st["title"] != "":
		UI.text_c(self, Rect2(card.position.x, y, cw, 24), st["title"], 18, Color(1.0, 0.76, 0.03), true)
		y += 30
	for ln in tl:
		UI.text_c(self, Rect2(card.position.x + 16, y, cw - 32, 14.5 * 1.35), ln, 14.5, Color.WHITE, true)
		y += 14.5 * 1.35
	if is_info:
		y += 10
		var bw := maxf(88.0, UI.text_width(st["button"], 14, true) + 48)
		var br := Rect2(card.get_center().x - bw / 2.0, y, bw, 36)
		UI.fill_rrect(self, br, 18, UI.argb(0xFF7C4DFF))
		UI.text_c(self, br, st["button"], 14, Color.WHITE, true)
		_hit_rects.append([br, "tut_next", null])
		y += 40
	var skip := L.t("Öğreticiyi atla  (%d/%d)" % [tut_idx + 1, guide["steps"].size()], "Skip tutorial  (%d/%d)" % [tut_idx + 1, guide["steps"].size()]) if guide["steps"].size() > 1 else L.t("Öğreticiyi atla", "Skip tutorial")
	var sr := Rect2(card.position.x, y + 2, cw, 28)
	UI.text_c(self, sr, skip, 12, Color(1, 1, 1, 0.54), false)
	_hit_rects.append([sr, "tut_skip", null])

func _dim_with_holes(W: float, H: float, holes: Array) -> void:
	var dim := Color(0, 0, 0, 150.0 / 255.0)
	if holes.is_empty():
		draw_rect(Rect2(0, 0, W, size.y), dim)
		return
	var step := 4.0
	var y := 0.0
	while y < size.y:
		var yc := y + step / 2.0
		var iv: Array = []
		for h in holes:
			var r: Rect2 = h[0]
			var rad: float = minf(float(h[1]), minf(r.size.x, r.size.y) / 2.0)
			if yc < r.position.y or yc > r.end.y:
				continue
			var dy := 0.0
			if yc < r.position.y + rad:
				dy = r.position.y + rad - yc
			elif yc > r.end.y - rad:
				dy = yc - (r.end.y - rad)
			var inset := 0.0
			if dy > 0.0:
				inset = rad - sqrt(maxf(0.0, rad * rad - dy * dy))
			iv.append([r.position.x + inset, r.end.x - inset])
		iv.sort_custom(func(a, b): return a[0] < b[0])
		var x := 0.0
		for seg in iv:
			if seg[0] > x:
				draw_rect(Rect2(x, y, seg[0] - x, step), dim)
			x = maxf(x, seg[1])
		if x < W:
			draw_rect(Rect2(x, y, W - x, step), dim)
		y += step
