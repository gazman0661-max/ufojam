extends PanelUI.PanelScreen
# Mağaza ekranı: Reklamları Kaldır + 3 paket. Fiyatlar Google Play'den gelir.

# ------------------------------------------------------------------ ürün kartı
class ProductCard extends Control:
	signal pressed
	var pid := ""
	var title_s := ""
	var desc_s := ""
	var price_s := ""
	var icons: Array = []        # doku adları (2x2 ızgara)
	var badge := ""
	var owned := false
	var busy := false
	var _down := false
	var _down_pos := Vector2.ZERO

	const PAD := 14.0
	const ICON := 68.0
	const BTN_H := 48.0

	func _init() -> void:
		mouse_filter = Control.MOUSE_FILTER_PASS

	func _ready() -> void:
		resized.connect(_upd)
		_upd()

	func _text_w() -> float:
		return maxf(120.0, size.x - PAD * 2.0 - ICON - 12.0)

	func _desc_lines() -> Array:
		return UI.wrap(desc_s, 14.0, _text_w(), false)

	func _upd() -> void:
		var top_h := maxf(ICON, 26.0 + _desc_lines().size() * 19.0 + 2.0)
		custom_minimum_size = Vector2(0, PAD + top_h + 10.0 + BTN_H + PAD + 10.0)
		queue_redraw()

	func _btn_rect() -> Rect2:
		return Rect2(PAD, size.y - 10.0 - PAD - BTN_H, size.x - PAD * 2.0, BTN_H)

	func _gui_input(e: InputEvent) -> void:
		if not ((e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT) or e is InputEventScreenTouch):
			return
		if e.pressed:
			_down = _btn_rect().has_point(e.position) and not owned and not busy
			_down_pos = e.position
		else:
			# kaydırma sırasında yanlışlıkla satın alma tetiklenmesin
			if _down and _btn_rect().has_point(e.position) and e.position.distance_to(_down_pos) < 14.0:
				pressed.emit()
			_down = false
		queue_redraw()

	func _draw() -> void:
		var card := Rect2(0, 0, size.x, size.y - 10.0)
		UI.shadow_rrect(self, card, 22, Color(0, 0, 0, 0.35), 8.0, Vector2(0, 3))
		UI.grad_rrect_v(self, card, 22, UI.argb(0xFF2B1670), UI.argb(0xFF1B0F4A))
		UI.stroke_rrect(self, card, 22, Color(1, 1, 1, 0.22), 1.5)
		# rozet
		if badge != "":
			var bw := UI.text_width(badge, 11, true) + 18.0
			var br := Rect2(card.end.x - bw - 12.0, -2.0, bw, 22.0)
			UI.grad_rrect_v(self, br, 11, UI.argb(0xFFFFA84D), UI.argb(0xFFFF7A00))
			UI.text_c(self, br, badge, 11, Color.WHITE, true)
		# ikon alanı
		var ir := Rect2(PAD, PAD, ICON, ICON)
		UI.fill_rrect(self, ir, 16, Color(1, 1, 1, 0.07))
		if pid == IAP.ID_NO_ADS:
			_draw_no_ads(ir)
		else:
			_draw_icons(ir)
		# metin
		var tx := PAD + ICON + 12.0
		UI.text_tl(self, Vector2(tx, PAD + 2.0), title_s, 18.0, Color.WHITE, true)
		var y := PAD + 28.0
		for ln in _desc_lines():
			UI.text_tl(self, Vector2(tx, y), ln, 14.0, Color(1, 1, 1, 0.78), false)
			y += 19.0
		# düğme
		var b := _btn_rect()
		var label := price_s
		var c0 := UI.argb(0xFF6FE06F)
		var c1 := UI.argb(0xFF2EA84A)
		var edge := UI.argb(0xFF1B6B2E)
		if owned:
			label = L.t("✓ Satın alındı", "✓ Purchased")
			c0 = UI.argb(0xFF8C86A8)
			c1 = UI.argb(0xFF5E5880)
			edge = UI.argb(0xFF3A3558)
		elif busy:
			label = "..."
		elif label == "":
			label = L.t("Satın al", "Buy")
		var sc := 0.97 if _down else 1.0
		var br2 := Rect2(b.get_center() - b.size * sc / 2.0, b.size * sc)
		UI.fill_rrect(self, Rect2(br2.position + Vector2(0, 4), br2.size), br2.size.y / 2.0, edge)
		UI.grad_rrect_v(self, br2, br2.size.y / 2.0, c0, c1)
		UI.stroke_rrect(self, br2, br2.size.y / 2.0, Color(1, 1, 1, 0.6), 2.0)
		UI.text_c(self, br2, label, 19, Color.WHITE, true, Color(0, 0, 0, 0.4))

	func _draw_icons(r: Rect2) -> void:
		if icons.size() == 1:
			var t := UI.tex(icons[0])
			if t != null:
				UI.draw_contain(self, t, r.grow(-8.0))
			return
		var cell := r.size.x / 2.0
		for i in icons.size():
			var t := UI.tex(icons[i])
			if t == null:
				continue
			var cr := Rect2(r.position + Vector2((i % 2) * cell, (i >> 1) * cell), Vector2(cell, cell))
			UI.draw_contain(self, t, cr.grow(-3.0))

	func _draw_no_ads(r: Rect2) -> void:
		var c := r.get_center()
		UI.text_c(self, Rect2(c.x - 24, c.y - 14, 48, 28), "AD", 22, Color(1, 1, 1, 0.95), true)
		draw_arc(c, 25.0, 0, TAU, 40, UI.argb(0xFFFF5C7A), 5.0, true)
		draw_line(c + Vector2(-18, 18), c + Vector2(18, -18), UI.argb(0xFFFF5C7A), 5.0, true)

# ------------------------------------------------------------------ ekran
func _init() -> void:
	super(L.t("Mağaza", "Shop"))

func _ready() -> void:
	super._ready()
	IAP.state_changed.connect(_build)
	IAP.purchase_done.connect(_on_done)
	IAP.purchase_failed.connect(_on_failed)
	_build()

func _info(id: String) -> Dictionary:
	if id == IAP.ID_NO_ADS:
		return {
			"title": L.t("Reklamları Kaldır", "Remove Ads"),
			"desc": L.t("Bölüm geçişlerindeki reklamları kalıcı olarak kaldırır. İsteğe bağlı ödüllü reklamlar (x2 coin, devam et vb.) yine kullanılabilir.",
				"Permanently removes the ads shown between levels. Optional reward ads (x2 coins, continue, etc.) stay available."),
			"icons": [], "badge": ""}
	if id == IAP.ID_COINS_BOOST:
		return {
			"title": L.t("Mega Paket", "Mega Pack"),
			"desc": L.t("1000 coin + her güçlendiriciden 3'er adet (Hemen Bin, Karıştır, Işınla).",
				"1000 coins + 3 of each booster (Board Now, Shuffle, Teleport)."),
			"icons": ["coin", "booster_board", "booster_shuffle", "booster_vip"],
			"badge": L.t("EN AVANTAJLI", "BEST VALUE")}
	if id == IAP.ID_BOOST5:
		return {
			"title": L.t("Güçlendirici Paketi", "Booster Pack"),
			"desc": L.t("Hemen Bin, Karıştır ve Işınla güçlendiricilerinden 5'er adet.",
				"5 each of the Board Now, Shuffle and Teleport boosters."),
			"icons": ["booster_board", "booster_shuffle", "booster_vip"], "badge": ""}
	if id == IAP.ID_COINS:
		return {
			"title": L.t("1000 Coin", "1000 Coins"),
			"desc": L.t("Güçlendirici almak için 1000 coin.", "1000 coins to spend on boosters."),
			"icons": ["coin"], "badge": ""}
	return {"title": id, "desc": "", "icons": [], "badge": ""}

func _clear() -> void:
	for c in vbox.get_children():
		vbox.remove_child(c)
		c.queue_free()

func _build() -> void:
	if vbox == null:
		return
	_clear()
	title = L.t("Mağaza", "Shop")
	if not IAP.available():
		add_item(PanelUI.PanelText.new(L.t("Mağaza şu an kullanılamıyor.", "The shop is not available right now."), false))
		queue_redraw()
		return
	for id in IAP.ORDER:
		var inf := _info(id)
		var card := ProductCard.new()
		card.pid = id
		card.title_s = inf["title"]
		card.desc_s = inf["desc"]
		card.icons = inf["icons"]
		card.badge = inf["badge"]
		card.price_s = IAP.price_of(id)
		card.owned = (id == IAP.ID_NO_ADS and Progress.no_ads)
		card.busy = IAP.busy
		card.pressed.connect(func():
			Audio.play(Audio.Sfx.CLICK)
			IAP.buy(id))
		add_item(card)
	add_item(PanelUI.PanelGap.new(6))
	var rb := PanelUI.GlossyButton.new(L.t("Satın Alımları Geri Yükle", "Restore Purchases"), "", null, false, 56.0)
	rb.pressed.connect(func():
		Audio.play(Audio.Sfx.CLICK)
		IAP.restore()
		_notice(L.t("Kontrol ediliyor", "Checking"), L.t("Satın alımların Google Play'den kontrol ediliyor. Varsa otomatik eklenecek.", "Your purchases are being checked with Google Play. Anything found will be restored automatically."), "🔄"))
	add_item(rb)
	add_item(PanelUI.PanelGap.new(10))
	var bb := PanelUI.GlossyButton.new(L.t("Yedekleme Nasıl Yapılır?", "How to Back Up"), "", null, false, 56.0)
	bb.pressed.connect(func(): load("res://scripts/backup_help.gd").show(self))
	add_item(bb)
	add_item(PanelUI.PanelGap.new(10))
	var note := PanelUI.PanelText.new(L.t("Satın alımlar Google Play hesabına bağlıdır. Reklamları Kaldır geri yüklenebilir. Coin ve güçlendiriciler telefonunda saklanır, kaybetmemek için yedekleme açık olsun.", "Purchases are tied to your Google Play account. Remove Ads can be restored. Coins and boosters are stored on your phone, so keep backup turned on to avoid losing them."), false)
	add_item(note)
	queue_redraw()

func _notice(t: String, m: String, emoji: String) -> void:
	GamePopup.show_popup(self, {
		"emoji": emoji, "title": t, "message": m, "dismissible": true,
		"buttons": [{"label": L.t("Tamam", "OK"), "kind": GamePopup.Kind.PRIMARY, "value": null}]})

func _on_done(id: String) -> void:
	Audio.play(Audio.Sfx.COIN)
	var msg := ""
	if id == IAP.ID_NO_ADS:
		msg = L.t("Bölüm geçişi reklamları kaldırıldı.", "Level-transition ads have been removed.")
	elif id == IAP.ID_COINS_BOOST:
		msg = L.t("+1000 coin ve her güçlendiriciden +3 eklendi.", "+1000 coins and +3 of each booster added.")
	elif id == IAP.ID_BOOST5:
		msg = L.t("Her güçlendiriciden +5 eklendi.", "+5 of each booster added.")
	elif id == IAP.ID_COINS:
		msg = L.t("+1000 coin eklendi.", "+1000 coins added.")
	_notice(L.t("Teşekkürler!", "Thank you!"), msg, "🎉")
	_build()

func _on_failed(message: String) -> void:
	_notice(L.t("Satın alma", "Purchase"), message, "⚠️")
