class_name Models
extends RefCounted
# models.dart karşılığı (saf oyun modelleri)

const CAP_PER_PASSENGER := 4
const VIP_UNLOCK_LEVEL := 7
const STRIP_FACTOR := 0.5
const BODY_SHRINK := 0.8
const HARD_EARLY := [8, 11, 15, 20, 26, 29, 35, 40, 46, 51, 56, 59]

enum Mech { BUDGET, ROTOR, FAULTY, BELT }
const MECH_UNLOCK := {0: 16, 1: 21, 2: 32, 3: 45}

static func is_hard_level(n: int) -> bool:
	if n <= 59:
		return HARD_EARLY.has(n)
	return n > 60 and n % 5 == 0

static func is_relief_level(n: int) -> bool:
	return n > 1 and is_hard_level(n - 1)

static func ufo_diameter(seats: int) -> float:
	return 0.96 if seats >= 10 else (0.88 if seats >= 6 else 0.80)

static func ufo_width(seats: int) -> float:
	return ufo_diameter(seats)

static func ufo_length(seats: int) -> float:
	return ufo_diameter(seats)

static func mech_title(m: int) -> String:
	match m:
		Mech.BUDGET: return L.t("Hamle bütçesi", "Move budget")
		Mech.ROTOR: return L.t("Dönen UFO", "Rotating UFO")
		Mech.FAULTY: return L.t("Arızalı UFO", "Faulty UFO")
		Mech.BELT: return L.t("Bant UFO", "Belt UFO")
	return ""

static func mech_desc(m: int) -> String:
	match m:
		Mech.BUDGET: return L.t("Dokunuş hakkın sınırlı. Kapalı UFO'ya dokunmak da hamle sayılır.", "Your taps are limited. Tapping a blocked UFO also counts as a move.")
		Mech.ROTOR: return L.t("Mavi halkalı UFO belli aralıkla yön değiştirir. Önü açıkken dokun!", "The UFO with the blue ring changes direction at set intervals. Tap it while its path is clear!")
		Mech.FAULTY: return L.t("Üstündeki sayı her hamlede düşer. 0 olursa UFO bozulup gider.", "The number on it drops with every move. If it reaches 0, the UFO breaks down and leaves.")
		Mech.BELT: return L.t("Bant üstünde kayan UFO sadece ortadayken (yeşil halka) çağrılır.", "A UFO sliding on the belt can only be called when it is in the middle (green ring).")
	return ""

class LevelRules extends RefCounted:
	var mechs: Array = []
	var move_budget: int = 0
	var rotors: Array = []
	var rotor_on: float = 3.4
	var rotor_off: float = 1.8
	var faulty: Dictionary = {}
	var fault_slack: int = 6
	var belts: Array = []
	var belt_cycle: float = 4.0
	var belt_win: float = 0.3
	func is_empty() -> bool:
		return mechs.is_empty()

class UfoSpec extends RefCounted:
	var id: int
	var x: float
	var y: float
	var angle: float
	var color: int
	var seats: int
	var mystery: bool
	var group: int
	func _init(p_id: int, p_x: float, p_y: float, p_angle: float, p_color: int, p_seats: int, p_mystery: bool = false, p_group: int = -1) -> void:
		id = p_id
		x = p_x
		y = p_y
		angle = p_angle
		color = p_color
		seats = p_seats
		mystery = p_mystery
		group = p_group
	func capacity() -> int:
		return seats * 4
	func dir_x() -> float:
		return sin(angle)
	func dir_y() -> float:
		return -cos(angle)
	func flipped() -> UfoSpec:
		return UfoSpec.new(id, x, y, angle + PI, color, seats, mystery, group)

class LevelData extends RefCounted:
	var number: int = 1
	var stage: int = 0
	var slots: int = 4
	var color_count: int = 0
	var ufos: Array = []
	var arms: Array = [[], []]
	var ring_cap: int = 78
	var hint: String = ""
	var min_x: float = 0.0
	var min_y: float = 0.0
	var max_x: float = 0.0
	var max_y: float = 0.0
	var rules: LevelRules = LevelRules.new()
	var layer_of: Array = []
	var layer_bounds: Array = []
	var arm_cut: Array = []

	func layer_count() -> int:
		return 1 if layer_bounds.is_empty() else layer_bounds.size()

	func layer_of_ufo(id: int) -> int:
		return 0 if layer_of.is_empty() else int(layer_of[id])

	func layer_size(l: int) -> int:
		if layer_of.is_empty():
			return ufos.size()
		var n := 0
		for v in layer_of:
			if int(v) == l:
				n += 1
		return n

	func bounds_of(l: int) -> Array:
		if layer_bounds.is_empty():
			return [min_x, min_y, max_x, max_y]
		return layer_bounds[clampi(l, 0, layer_bounds.size() - 1)]

	func total_passengers() -> int:
		return arms[0].size() + arms[1].size()

	func board_w() -> float:
		return max_x - min_x

	func board_h() -> float:
		return max_y - min_y

	func is_hard() -> bool:
		return Models.is_hard_level(number)

	func has_vip() -> bool:
		return number >= Models.VIP_UNLOCK_LEVEL

	func reward() -> int:
		return 40 if is_hard() else 20
