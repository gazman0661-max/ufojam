extends PanelUI.PanelScreen
# settings_screen.dart karşılığı (Seçenekler) + OurGames / HowToPlay / Info ekranları

func _init() -> void:
	super(L.t("Seçenekler", "Options"))

static func make_info(p_title: String, sections: Array) -> Control:
	return load("res://scripts/info_screen.gd").new(p_title, sections)

func _ready() -> void:
	super._ready()
	_build()

func _clear() -> void:
	for c in vbox.get_children():
		c.queue_free()

func _gap(h: float = 12.0) -> void:
	add_item(PanelUI.PanelGap.new(h))

func _btn(label: String, icon: String, checked, cb: Callable, orange: bool = false, h: float = 64.0) -> void:
	var b := PanelUI.GlossyButton.new(label, icon, checked, orange, h)
	b.pressed.connect(cb)
	add_item(b)

func _build() -> void:
	_clear()
	title = L.t("Seçenekler", "Options")
	_btn(L.t("Oyunlarımız ve\nUygulamalarımız", "Our Games &\nApps"), "grid", null, func(): Nav.push(_our_games()), true, 86.0)
	add_item(PanelUI.PanelSection.new(L.t("SES", "SOUND")))
	_btn(L.t("Müzik", "Music"), "", Settings.music, func(): _toggle("music"))
	_gap()
	_btn(L.t("Ses Efektleri", "Sound Effects"), "", Settings.sfx, func(): _toggle("sfx"))
	add_item(PanelUI.PanelSection.new(L.t("CİHAZ", "DEVICE")))
	_btn(L.t("Titreşim", "Vibration"), "", Settings.vibration, func(): _toggle("vibration"))
	_gap()
	_btn(L.t("Ekran Efektleri", "Screen Effects"), "", Settings.screen_fx, func(): _toggle("screen_fx"))
	add_item(PanelUI.PanelSection.new(L.t("DİL", "LANGUAGE")))
	_btn("TÜRKÇE" if L.is_tr() else "ENGLISH", "lang", null, _language_dialog)
	add_item(PanelUI.PanelSection.new(L.t("YARDIM", "HELP")))
	_btn(L.t("Nasıl Oynanır?", "How to Play"), "help", null, func(): Nav.push(_how_to()))
	_gap()
	_btn(L.t("Yedekleme Nasıl Yapılır?", "How to Back Up"), "shield", null, func(): load("res://scripts/backup_help.gd").show(self))
	add_item(PanelUI.PanelSection.new(L.t("GİZLİLİK", "PRIVACY")))
	_btn(L.t("Reklam Rızasını Yönet", "Manage Ad Consent"), "shield", null, _consent_dialog)
	add_item(PanelUI.PanelSection.new(L.t("HAKKINDA", "ABOUT")))
	_btn(L.t("Kullanım Şartları", "Terms of Use"), "", null, func(): _open_doc(L.t("Kullanım Şartları", "Terms of Use"), Legal.terms_url(), Legal.terms_text()))
	_gap()
	_btn(L.t("Gizlilik Politikası", "Privacy Policy"), "", null, func(): _open_doc(L.t("Gizlilik Politikası", "Privacy Policy"), Legal.privacy_url(), Legal.privacy_text()))
	_gap(26)
	var v := Label.new()
	v.text = "UFO Bus Jam  •  v%s" % Settings.APP_VERSION
	v.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_theme_color_override("font_color", PanelUI.section_color())
	v.add_theme_font_size_override("font_size", 14)
	add_item(v)
	queue_redraw()

func _toggle(which: String) -> void:
	match which:
		"music": Settings.music = not Settings.music
		"sfx": Settings.sfx = not Settings.sfx
		"vibration": Settings.vibration = not Settings.vibration
		"screen_fx": Settings.screen_fx = not Settings.screen_fx
	Settings.save()
	Audio.refresh()
	Audio.play(Audio.Sfx.CLICK)
	Settings.vibe(Settings.SELECTION)
	_build()

func _open_doc(p_title: String, url: String, sections: Array) -> void:
	Audio.play(Audio.Sfx.CLICK)
	if Legal.open_url(url):
		return
	Nav.push(make_info(p_title, sections))

func _language_dialog() -> void:
	var p := GamePopup.show_popup(self, {
		"icon": "rocket", "title": L.t("Dil", "Language"), "dismissible": true,
		"buttons": [
			{"label": ("✓ " if L.is_tr() else "") + "Türkçe", "kind": GamePopup.Kind.PRIMARY, "value": "tr"},
			{"label": ("✓ " if L.is_en() else "") + "English", "kind": GamePopup.Kind.PRIMARY, "value": "en"},
			{"label": L.t("Vazgeç", "Cancel"), "kind": GamePopup.Kind.GHOST, "value": null}], "stacked": true})
	var v = await p.closed
	if v == "tr":
		L.set_lang(L.AppLang.TR)
	elif v == "en":
		L.set_lang(L.AppLang.EN)
	if v != null:
		_build()

func _stats_dialog() -> void:
	Audio.play(Audio.Sfx.CLICK)
	var rep := Stats.report()
	var lines: Array = UI.wrap(rep, 14.5, 300.0, false)
	var show_lines := lines.slice(0, 16)
	var bh := minf(320.0, show_lines.size() * 20.0)
	var p := GamePopup.show_popup(self, {
		"icon": "rocket", "title": L.t("İstatistikler", "Statistics"), "dismissible": true, "stacked": true,
		"body_h": bh,
		"body_draw": _stats_body.bind(show_lines),
		"buttons": [
			{"label": L.t("Veriyi kopyala (JSON)", "Copy data (JSON)"), "kind": GamePopup.Kind.REWARD, "value": "copy"},
			{"label": L.t("Sıfırla", "Reset"), "kind": GamePopup.Kind.DANGER, "value": "reset"},
			{"label": L.t("Kapat", "Close"), "kind": GamePopup.Kind.GHOST, "value": null}]})
	var v = await p.closed
	if v == "copy":
		DisplayServer.clipboard_set(Stats.to_json())
	elif v == "reset":
		Stats.reset()

func _consent_dialog() -> void:
	var p := GamePopup.show_popup(self, {
		"icon": "rocket", "title": L.t("Reklam Rızası", "Ad Consent"), "dismissible": true,
		"message": L.t("Oyunda şu an reklam bulunmuyor. Reklam eklendiğinde rıza tercihlerini buradan yönetebileceksin.",
			"There are no ads in the game right now. When ads are added, you will be able to manage your consent preferences here."),
		"buttons": [{"label": L.t("Kapat", "Close"), "kind": GamePopup.Kind.PRIMARY, "value": null}]})
	await p.closed

func _how_to() -> Control:
	return make_info(L.t("Nasıl Oynanır?", "How to Play"), [
		L.t("1. UFO'ya dokun", "1. Tap a UFO"),
		L.t("Izgaradaki bir UFO'ya dokununca UFO, alttaki park yerlerinden birine süzülür.", "Tap a UFO on the grid and it glides down into one of the parking slots below."),
		L.t("2. Yolcular biner", "2. Passengers board"),
		L.t("Halkada dönen yolcular, rengi uyan park etmiş UFO'ya ışınla biner.", "Passengers circling on the ring beam up into the parked UFO that matches their color."),
		L.t("3. UFO dolunca uçar", "3. A full UFO takes off"),
		L.t("Bir UFO'nun tüm koltukları dolunca yolcularıyla uçup gider ve park yeri boşalır.", "When all the seats of a UFO are filled, it flies off with its passengers and the parking slot frees up."),
		L.t("4. Yerin bitmesin", "4. Don't run out of space"),
		L.t("Park yerlerin dolmadan tüm yolcuları bindirmeye çalış. Kazanınca coin kazanır, sonraki seviyeye geçersin.", "Try to board every passenger before your parking slots fill up. When you win, you earn coins and move on to the next level."),
		L.t("Takılınca", "When you're stuck"),
		L.t("Hemen Bin, Karıştır ve Işınla güçlendiricileri sıkıştığın anda işe yarar. Stok bitince yenisini kazanabilirsin.", "The Board Now, Shuffle and Teleport boosters come in handy when you get stuck. When your stock runs out, you can earn more.")])

func _our_games() -> Control:
	return load("res://scripts/our_games_screen.gd").new()

func _stats_body(ci: CanvasItem, r: Rect2, show_lines: Array) -> void:
	var y := r.position.y
	for ln in show_lines:
		UI.text_tl(ci, Vector2(r.position.x, y), ln, 14.5, Color(1, 1, 1, 0.7), false)
		y += 20.0
