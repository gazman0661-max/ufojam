extends Node
# l10n.dart karşılığı: L.t('Türkçe', 'English')

signal changed
enum AppLang { TR, EN }
var lang: int = AppLang.EN

func is_tr() -> bool:
	return lang == AppLang.TR

func is_en() -> bool:
	return lang == AppLang.EN

func t(tr_s: String, en_s: String) -> String:
	return tr_s if lang == AppLang.TR else en_s

func device_lang() -> int:
	var code := OS.get_locale_language().to_lower()
	return AppLang.TR if code == "tr" else AppLang.EN

func load_lang() -> void:
	lang = device_lang()
	var saved = Store.get_v("s_lang", null)
	if saved == "tr":
		lang = AppLang.TR
	elif saved == "en":
		lang = AppLang.EN

func set_lang(l: int) -> void:
	if l == lang:
		return
	lang = l
	Store.set_v("s_lang", "tr" if l == AppLang.TR else "en")
	Store.save()
	changed.emit()
