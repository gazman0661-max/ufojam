extends RefCounted
# "Yedekleme nasıl yapılır?" bilgi popup'ı (Ayarlar ve Mağaza ortak kullanır).
# Kullanım: load("res://scripts/backup_help.gd").show(self)

static func show(parent: Node) -> void:
	Audio.play(Audio.Sfx.CLICK)
	GamePopup.show_popup(parent, {
		"emoji": "💾",
		"title": L.t("Yedekleme", "Backup"),
		"message": L.t(
			"İlerlemen (seviye, coin ve güçlendiriciler) sadece telefonunda saklanır. Uygulamayı silersen, verilerini temizlersen veya telefonu sıfırlarsan kaybolabilir.\n\nKorumak için telefonunda Google yedeklemesini aç:\nAyarlar > Google > Yedekleme > Şimdi yedekle\n(Menü adı telefona göre değişebilir.)\n\nYedek açıksa oyunu yeniden kurunca ilerlemen genellikle otomatik geri gelir.\n\nNot: Reklamları Kaldır, Google Play hesabına bağlıdır ve geri yüklenebilir. Coin ve güçlendirici paketleri ise sadece yedekle geri gelir.",
			"Your progress (levels, coins and boosters) is stored only on your phone. It can be lost if you uninstall the app, clear its data or reset the phone.\n\nTo protect it, turn on Google backup on your phone:\nSettings > Google > Backup > Back up now\n(The menu name may vary by phone.)\n\nWith backup on, your progress usually comes back automatically when you reinstall the game.\n\nNote: Remove Ads is tied to your Google Play account and can be restored. Coin and booster packs only come back through backup."),
		"dismissible": true,
		"buttons": [{"label": L.t("Anladım", "Got it"), "kind": GamePopup.Kind.PRIMARY, "value": null}]})
