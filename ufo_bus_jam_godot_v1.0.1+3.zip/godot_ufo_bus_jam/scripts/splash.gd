extends Control
# splash_screen.dart karşılığı: 3 sn'lik açılış sahnesi; sonra (gerekirse) yasal onay ve ana ekran.

const TOTAL := 3.0
const ALIENS := ["green", "pink", "orange", "yellow", "lightblue", "purple"]
var _t := 0.0
var _left := false

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	set_process(true)

func _process(d: float) -> void:
	_t += d
	if _t >= TOTAL and not _left:
		_left = true
		_go_home()
	queue_redraw()

func _go_home() -> void:
	if not Legal.accepted:
		var ok = await LegalDialog.show_consent(self)
		if not ok:
			return
	Nav.replace(load("res://scripts/home.gd").new())

static func seg(t: float, a: float, b: float, curve: int = 0) -> float:
	var x := clampf((t - a) / (b - a), 0.0, 1.0)
	match curve:
		1: # easeOutBack
			var c1 := 1.70158
			var c3 := c1 + 1.0
			return 1.0 + c3 * pow(x - 1.0, 3.0) + c1 * pow(x - 1.0, 2.0)
		2: # easeInOut
			return x * x * (3.0 - 2.0 * x) if false else (4.0 * x * x * x if x < 0.5 else 1.0 - pow(-2.0 * x + 2.0, 3.0) / 2.0)
		3: # easeIn
			return x * x * x * 0.0 + x * x
	return x

func _draw() -> void:
	var W := size.x
	var H := size.y
	var t := clampf(_t / TOTAL, 0.0, 1.0)
	draw_rect(Rect2(Vector2.ZERO, size), UI.argb(0xFF0B0620))
	UI.draw_cover(self, UI.tex("bg_station"), Rect2(Vector2.ZERO, size))
	_vgrad(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 120.0 / 255.0), Color(0, 0, 0, 30.0 / 255.0), Color(0, 0, 0, 130.0 / 255.0))

	var ufo_w := W * 0.62
	var ufo_h := ufo_w * 233.0 / 256.0
	var rest_top := H * 0.20
	var enter := seg(t, 0.0, 0.30, 1)
	var bob_amp := H * 0.008 * seg(t, 0.30, 0.42)
	var ufo_top := lerpf(-ufo_h, rest_top, enter) + sin(t * PI * 2 * 3) * bob_amp
	var tilt := sin(t * PI * 2 * 2.5) * 0.035 * seg(t, 0.2, 0.35)
	var aw0 := H * 0.085 * 203.0 / 256.0
	var ah0 := H * 0.085
	var floor_y := H * 0.80
	var target_x := W / 2.0
	var target_y := rest_top + ufo_h * 0.55
	var pulse := 0.0
	for i in ALIENS.size():
		var rs := 0.38 + 0.065 * i
		pulse += sin(seg(t, rs + 0.15, rs + 0.21) * PI) * 0.022
	var beam_op := seg(t, 0.30, 0.46) * (0.82 + 0.10 * sin(t * PI * 2 * 5))
	var beam_top := rest_top + ufo_h * 0.74
	var beam_h := floor_y - beam_top + H * 0.02
	var beam_w := W * 0.62
	var title_op := seg(t, 0.12, 0.32)
	var title_sc := lerpf(0.65, 1.0, seg(t, 0.12, 0.40, 1))

	_flyer("ufo4_pink", W, H, t, W * 0.20, H * 0.47, true, 0.0)
	_flyer("ufo4_yellow", W, H, t, W * 0.15, H * 0.585, false, 1.7)

	# başlık
	var fs := minf(W * 0.105, 46.0)
	var ctr := Vector2(W / 2.0, H * 0.075 + fs * 0.6)
	draw_set_transform(ctr, 0.0, Vector2(title_sc, title_sc))
	var tr := Rect2(-W / 2.0, -fs * 0.6, W, fs * 1.2)
	UI.text_c(self, Rect2(tr.position + Vector2(0, 3), tr.size), "UFO BUS JAM", fs, Color(0, 0, 0, 0.67 * title_op), true)
	UI.text_c(self, tr, "UFO BUS JAM", fs, Color(1, 1, 1, title_op), true, Color(0.49, 0.3, 1.0, 0.6 * title_op))
	draw_set_transform_matrix(Transform2D.IDENTITY)

	# ışın
	draw_texture_rect(UI.tex("beam"), Rect2((W - beam_w) / 2.0, beam_top, beam_w, beam_h), false, Color(1, 1, 1, clampf(beam_op, 0, 1)))

	for i in ALIENS.size():
		_alien(i, W, t, aw0, ah0, floor_y, target_x, target_y)

	# ana UFO
	var c := Vector2(W / 2.0, ufo_top + ufo_h / 2.0)
	draw_set_transform(c, tilt, Vector2.ONE * (1.0 + pulse))
	UI.draw_contain(self, UI.tex("ufo10_blue"), Rect2(Vector2(-ufo_w / 2.0, -ufo_h / 2.0), Vector2(ufo_w, ufo_h)))
	draw_set_transform_matrix(Transform2D.IDENTITY)

	# yükleme çubuğu
	var op := seg(t, 0.05, 0.2)
	var bar_w := W * 0.5
	var by := H - H * 0.07
	UI.text_c(self, Rect2(0, by - 36, W, 16), L.t("Yükleniyor...", "Loading..."), 13, Color(1, 1, 1, 0.7 * op), true)
	var bar := Rect2((W - bar_w) / 2.0, by - 14, bar_w, 9)
	UI.fill_rrect(self, bar, 6, Color(1, 1, 1, 40.0 / 255.0 * op))
	UI.stroke_rrect(self, bar, 6, Color(1, 1, 1, 60.0 / 255.0 * op), 1.0)
	var fw := bar_w * clampf(t, 0, 1)
	if fw > 2.0:
		var fr := Rect2(bar.position, Vector2(fw, 9))
		UI.shadow_rrect(self, fr, 6, Color(0.49, 0.3, 1.0, op), 8.0)
		var pts := UI.rrect_pts(fr, 6)
		var cols := PackedColorArray()
		for p in pts:
			cols.append(UI.argb(0xFF7C4DFF).lerp(UI.argb(0xFF18FFFF), (p.x - fr.position.x) / bar_w * (bar_w / maxf(fw, 1.0)) if false else clampf((p.x - fr.position.x) / fw, 0, 1)).darkened(0.0) * Color(1, 1, 1, op))
		draw_polygon(pts, cols)

func _vgrad(r: Rect2, a: Color, b: Color, c: Color) -> void:
	var n := 24
	for i in n:
		var t0 := float(i) / n
		var col: Color = a.lerp(b, t0 * 2.0) if t0 < 0.5 else b.lerp(c, (t0 - 0.5) * 2.0)
		draw_rect(Rect2(r.position.x, r.position.y + r.size.y * t0, r.size.x, r.size.y / n + 1), col)

func _flyer(asset: String, W: float, H: float, t: float, w: float, y: float, ltr: bool, phase: float) -> void:
	var h := w * 170.0 / 256.0
	var p := seg(t, 0.0, 1.0)
	var x := lerpf(-w, W + w * 0.2, p) if ltr else lerpf(W + w * 0.2, -w, p)
	var bob := sin(t * PI * 2 * 2 + phase) * H * 0.01
	UI.draw_contain(self, UI.tex(asset), Rect2(x, y + bob, w, h), Color(1, 1, 1, 0.92))

func _alien(i: int, W: float, t: float, aw0: float, ah0: float, floor_y: float, tx: float, ty: float) -> void:
	var n := ALIENS.size()
	var slot_x := W * (0.14 + (0.72 / (n - 1)) * i)
	var pop_at := 0.20 + 0.03 * i
	var pop := seg(t, pop_at, pop_at + 0.08, 1)
	var rs := 0.38 + 0.065 * i
	var rise := seg(t, rs, rs + 0.19)
	var cx := slot_x
	var cy := floor_y - ah0 / 2.0
	var sc := pop
	var op := seg(t, pop_at, pop_at + 0.04)
	var ang := 0.0
	if rise <= 0.0:
		cy -= absf(sin((t * 7 + i * 0.9) * PI)) * ah0 * 0.10 * pop
	else:
		var side := 1.0 if slot_x < W / 2.0 else -1.0
		var e := rise * rise * (3.0 - 2.0 * rise)
		cx = lerpf(slot_x, tx, e) + sin(rise * PI) * W * 0.05 * -side
		cy = lerpf(floor_y - ah0 / 2.0, ty, rise * rise)
		sc = lerpf(1.0, 0.25, rise * rise)
		op = 1.0 - seg(rise, 0.82, 1.0)
		ang = sin(rise * PI * 3) * 0.28
	draw_set_transform(Vector2(cx, cy), ang, Vector2.ONE * clampf(sc, 0.0, 2.0))
	UI.draw_contain(self, UI.tex("alien_" + ALIENS[i]), Rect2(Vector2(-aw0 / 2.0, -ah0 / 2.0), Vector2(aw0, ah0)), Color(1, 1, 1, clampf(op, 0, 1)))
	draw_set_transform_matrix(Transform2D.IDENTITY)
