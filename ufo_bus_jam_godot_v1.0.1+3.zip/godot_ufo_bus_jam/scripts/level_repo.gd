class_name LevelRepo
extends RefCounted
# level_repo.dart karşılığı

const EASY_COUNT := 25
const EARLY_START := 8
const EARLY_END := 70
const STORY_END := 123

static var _cache := {}
static var _pool: Array = []
static var _pool_built := false
static var _cycle_cache := {}

static func _build_pool() -> void:
	if _pool_built:
		return
	_pool_built = true
	StageData.load_all()
	var s := {}
	for i in range(STORY_END, StageData.stage_order.size()):
		s[StageData.stage_order[i]] = true
	_pool = s.keys()
	_pool.sort()

static func _cycle(c: int) -> Array:
	if _cycle_cache.has(c):
		return _cycle_cache[c]
	var prev_last: int
	if c == 0:
		prev_last = StageData.stage_order[STORY_END - 1]
	else:
		prev_last = _cycle(c - 1).back()
	var l: Array = _pool.duplicate()
	var s: int = (c * 7919 + 13) & 0x7fffffff
	var i := l.size() - 1
	while i > 0:
		s = (s * 1103515245 + 12345) & 0x7fffffff
		var nx: int = s >> 8
		var j: int = nx % (i + 1)
		var t = l[i]
		l[i] = l[j]
		l[j] = t
		i -= 1
	if l[0] == prev_last:
		var t2 = l[0]
		l[0] = l[1]
		l[1] = t2
	_cycle_cache[c] = l
	return l

static func stage_key_for(n: int) -> int:
	StageData.load_all()
	_build_pool()
	if n < 1:
		n = 1
	if n < EARLY_START:
		return 1000 + n
	if n <= EARLY_END:
		return StageData.early[n - EARLY_START]
	if n >= 71 and n < STORY_END:
		return StageData.story[n - 71]
	if n <= STORY_END:
		return StageData.stage_order[n - 1]
	var k := n - STORY_END - 1
	if k < StageData.late.size():
		return StageData.late[k]
	return _cycle(int(k / _pool.size()))[k % _pool.size()]

static func get_level(number: int) -> Models.LevelData:
	if not _cache.has(number):
		_cache[number] = _build(number)
	return _cache[number]

static func _build(number: int) -> Models.LevelData:
	var stage := stage_key_for(number)
	var st: Array = StageData.stages[stage]
	var lay: Array = StageData.layers.get(stage, [])
	var ufos: Array = []
	var max_color := 0
	var min_x := 1e9
	var min_y := 1e9
	var max_x := -1e9
	var max_y := -1e9
	var nl := 0
	if not lay.is_empty():
		var mx := 0
		for v in lay:
			if v > mx:
				mx = v
		nl = mx + 1
	var l_min_x: Array = []
	var l_min_y: Array = []
	var l_max_x: Array = []
	var l_max_y: Array = []
	for i in nl:
		l_min_x.append(1e9)
		l_min_y.append(1e9)
		l_max_x.append(-1e9)
		l_max_y.append(-1e9)
	var seat_tab := [0, 4, 6, 10]
	for row in String(st[0]).split(";"):
		var f := row.split(",")
		var seats: int = seat_tab[int(f[4])]
		var color := int(f[3])
		var x := float(f[0])
		var y := float(f[1])
		var deg := float(f[2])
		var id := ufos.size()
		ufos.append(Models.UfoSpec.new(id, x, y, deg * PI / 180.0, color, seats, f[5] == "1", int(f[6])))
		max_color = maxi(max_color, color)
		var r := Models.ufo_length(seats) / 2.0
		min_x = minf(min_x, x - r)
		max_x = maxf(max_x, x + r)
		min_y = minf(min_y, y - r)
		max_y = maxf(max_y, y + r)
		if nl > 0:
			var l: int = lay[id]
			l_min_x[l] = minf(l_min_x[l], x - r)
			l_max_x[l] = maxf(l_max_x[l], x + r)
			l_min_y[l] = minf(l_min_y[l], y - r)
			l_max_y[l] = maxf(l_max_y[l], y + r)
	var arm_rows = StageData.arms.get(stage, null)
	const PAD := 0.10
	var ld := Models.LevelData.new()
	ld.number = number
	ld.stage = stage
	ld.slots = 4
	ld.color_count = max_color + 1
	ld.ufos = ufos
	if arm_rows != null:
		ld.arms = [_arm(arm_rows[0]), _arm(arm_rows[1])]
	else:
		ld.arms = [_arm(st[1]), _arm(st[2])]
	ld.ring_cap = StageData.ring_cap_for(stage)
	ld.hint = hint_for(number)
	ld.min_x = min_x - PAD
	ld.min_y = min_y - PAD
	ld.max_x = max_x + PAD
	ld.max_y = max_y + PAD
	ld.layer_of = lay
	var lb: Array = []
	for l in nl:
		lb.append([l_min_x[l] - PAD, l_min_y[l] - PAD, l_max_x[l] + PAD, l_max_y[l] + PAD])
	ld.layer_bounds = lb
	ld.arm_cut = StageData.arm_cut.get(stage, [])
	ld.rules = Rules.build_rules(number, stage, ufos.size())
	return ld

static func _arm(s: String) -> Array:
	var o: Array = []
	if s == "":
		return o
	for p in s.split(" "):
		o.append(int(p))
	return o

static func hint_for(level: int) -> String:
	match level:
		1: return L.t("Önü açık bir UFO'ya dokun: park yerine uçar. Yolcular kapıdan geçerken kendi renkli UFO'ya biner.",
			"Tap a UFO with a clear path: it flies to a parking slot. Passengers board the UFO of their own color as they pass the gate.")
		2: return L.t("UFO ok yönünde çıkar. Önünde başka UFO varsa çarpıp geri döner. Sıkışırsan ⚡ Hemen Bin!",
			"A UFO leaves in the direction of its arrow. If another UFO is in the way, it bumps and comes back. If you get stuck, use ⚡ Board Now!")
		3: return L.t("Kollardaki renk sırasına bak: halkaya girecek rengin UFO'sunu önceden park et!",
			"Check the color order on the arms: park the UFO of the color that is about to enter the ring in advance!")
		10: return L.t("Gri \"?\" UFO'nun rengi önü açılınca belli olur. Altın VIP yuvaya sadece Işınla ile UFO konur.",
			"The color of the gray \"?\" UFO is revealed once its path is clear. Only Teleport can place a UFO in the golden VIP slot.")
		26: return L.t("Zor seviye! Park yerlerini boşa harcama.", "Hard level! Don't waste your parking slots.")
	return ""
