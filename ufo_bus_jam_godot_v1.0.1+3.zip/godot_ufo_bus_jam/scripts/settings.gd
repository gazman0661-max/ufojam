extends Node
# settings.dart karşılığı

const APP_VERSION := "1.0.1"
var music := true
var sfx := true
var vibration := true
var screen_fx := true

func load_all() -> void:
	music = bool(Store.get_v("s_music", true))
	sfx = bool(Store.get_v("s_sfx", true))
	vibration = bool(Store.get_v("s_vibration", true))
	screen_fx = bool(Store.get_v("s_screenFx", true))

func save() -> void:
	Store.set_v("s_music", music)
	Store.set_v("s_sfx", sfx)
	Store.set_v("s_vibration", vibration)
	Store.set_v("s_screenFx", screen_fx)
	Store.save()

# HapticFeedback karşılıkları (ms)
const LIGHT := 15
const MEDIUM := 30
const HEAVY := 55
const SELECTION := 8

func vibe(ms: int) -> void:
	if vibration:
		Input.vibrate_handheld(ms)
