class_name GameState
extends RefCounted
# engine.dart karşılığı (canlı oyun motoru). Çarpışma önbelleği (field_version) eklendi: sonuçlar aynı, sadece hız için.

const RING_LANES := 3
const LANE_STAGGER := 0.0
const PREFILL_FRONT := 0.3
const LAND_SEC := 2.2
const BEAM_SEC := 1.4
const INTRO_MUL := 4.0
const RING_SPEED := 0.09
const OPEN_SLOTS := 4
const LOCKED_SLOTS := 3
const FAULT_AWAY_MOVES := 3

static func frac_s(x: float) -> float:
	return x - floorf(x)

static func cell_offset(i: int, cols: int) -> float:
	return (float(int(i / RING_LANES)) + float(i % RING_LANES) * LANE_STAGGER) / cols

static func gate_s(_k: int, _count: int) -> float:
	return 0.0

class Passenger extends RefCounted:
	var id: int
	var color: int
	func _init(p_id: int, p_color: int) -> void:
		id = p_id
		color = p_color

class BoardEvent extends RefCounted:
	var ufo_id: int
	var passenger_id: int
	var color: int
	var cell: int
	var gate: int
	func _init(a: int, b: int, c: int, d: int, e: int) -> void:
		ufo_id = a
		passenger_id = b
		color = c
		cell = d
		gate = e

class UfoState extends RefCounted:
	var spec: Models.UfoSpec
	var cur: Models.UfoSpec
	var flip: Models.UfoSpec
	var boarded: int = 0
	var in_grid: bool = true
	var spawned: bool
	var departed: bool = false
	var last_slot: int = -1
	var rotor: bool = false
	var flipped: bool = false
	var rot_offset: float = 0.0
	var belt: bool = false
	var belt_offset: float = 0.0
	var flip_clock: float = -10.0
	var fault: int = 0
	var fault_base: int = 0
	var away: bool = false
	var away_moves: int = 0
	func _init(p_spec: Models.UfoSpec, p_spawned: bool) -> void:
		spec = p_spec
		spawned = p_spawned
		cur = p_spec
		flip = p_spec.flipped()
	func is_faulty() -> bool:
		return fault_base > 0

var level: Models.LevelData
var ufos: Array = []
var groups := {}
var cells: Array = []
var occupied: int = 0
var arm_q: Array = []
var arm_head: Array = [0, 0]
var intro_done := false
var slots: Array = []
var slot_ready: Array = []
var phase: float = 0.0
var clock: float = 0.0
var boarded_total: int = 0
var entry_l: float = 0.405
var entry_r: float = 0.595
var speed: float = RING_SPEED
var locked_slots: int = LOCKED_SLOTS
var moves_used: int = 0
var cur_layer: int = 0
var layer_events: int = 0
var rot_version: int = 0
var break_queue: Array = []
var fault_events: int = 0

# çarpışma önbelleği
var field_version: int = 0
var _blk_ver: int = -1
var _blk_dist := {}
var _blk_who := {}

func _init(p_level: Models.LevelData) -> void:
	level = p_level
	for i in level.ring_cap:
		cells.append(null)
	arm_q = [level.arms[0].duplicate(), level.arms[1].duplicate()]
	var sc: int = level.slots + (1 if level.has_vip() else 0)
	for i in sc:
		slots.append(-1)
		slot_ready.append(0.0)
	for s in level.ufos:
		if s.group >= 0:
			if not groups.has(s.group):
				groups[s.group] = []
			groups[s.group].append(s.id)
	for s in level.ufos:
		var first: bool = (s.group < 0 or groups[s.group][0] == s.id) and level.layer_of_ufo(s.id) == 0
		ufos.append(UfoState.new(s, first))
	var ri := 0
	for id in level.rules.rotors:
		if id < 0 or id >= ufos.size():
			continue
		ufos[id].rotor = true
		ufos[id].rot_offset = fmod(ri * 1.3, level.rules.rotor_on + level.rules.rotor_off)
		ri += 1
	var bi := 0
	for id in level.rules.belts:
		if id < 0 or id >= ufos.size():
			continue
		ufos[id].belt = true
		ufos[id].belt_offset = fmod(bi * 1.1, level.rules.belt_cycle)
		bi += 1
	for id in level.rules.faulty:
		if id < 0 or id >= ufos.size():
			continue
		var c: int = level.rules.faulty[id]
		ufos[id].fault = c
		ufos[id].fault_base = c
	# Halka bölüm başında HAZIR dolu başlar
	var pre: int = mini(level.ring_cap, level.total_passengers())
	var cols0: int = int(ceil(level.ring_cap / float(RING_LANES)))
	for i in pre:
		var a: int = 1 if (float(int(i / RING_LANES)) / cols0) < PREFILL_FRONT else 0
		if arm_head[a] >= arm_q[a].size():
			a = 1 - a
		cells[i] = Passenger.new(arm_id(a, arm_head[a]), arm_q[a][arm_head[a]])
		arm_head[a] += 1
		occupied += 1
	intro_done = true

func q_head() -> int:
	return arm_head[0] + arm_head[1]

func outside_count() -> int:
	return level.total_passengers() - q_head()

func arm_remaining(a: int) -> int:
	return arm_q[a].size() - arm_head[a]

func arm_id(a: int, m: int) -> int:
	return 2 * m + a

func remaining_total() -> int:
	return occupied + outside_count()

func ring_cols() -> int:
	return int(ceil(level.ring_cap / float(RING_LANES)))

func cell_s(i: int) -> float:
	return frac_s(phase - cell_offset(i, ring_cols()))

func move_budget() -> int:
	return level.rules.move_budget

func moves_left() -> int:
	return move_budget() - moves_used if move_budget() > 0 else 0

func out_of_moves() -> bool:
	if not (move_budget() > 0 and moves_used >= move_budget()):
		return false
	for u in ufos:
		if u.in_grid:
			return true
	return false

func note_wasted_tap() -> void:
	moves_used += 1

func grant_moves(n: int) -> void:
	moves_used = maxi(0, moves_used - n)

func intro_active() -> bool:
	if intro_done:
		return false
	if occupied >= mini(level.ring_cap, level.total_passengers()) or clock >= 10.0:
		intro_done = true
		return false
	return true

# ---------------------------------------------------------- saha

func is_on_field(id: int) -> bool:
	return ufos[id].in_grid and ufos[id].spawned

func _ensure_blk(id: int) -> void:
	if _blk_ver != field_version:
		_blk_ver = field_version
		_blk_dist.clear()
		_blk_who.clear()
	if _blk_dist.has(id):
		return
	var m = ufos[id].cur
	var best := -1.0
	var who := -1
	for o in ufos:
		if o.spec.id == id or not o.in_grid or not o.spawned:
			continue
		var d: float = Geo.sweep_hit(m, o.cur)
		if d >= 0.0 and (best < 0.0 or d < best):
			best = d
			who = o.spec.id
	_blk_dist[id] = best
	_blk_who[id] = who

func blocker_distance(id: int) -> float:
	_ensure_blk(id)
	return _blk_dist[id]

# Engel yoksa -1
func first_blocker(id: int) -> int:
	_ensure_blk(id)
	return _blk_who[id]

func can_launch(id: int) -> bool:
	if not is_on_field(id):
		return false
	if ufos[id].belt and not belt_open(ufos[id]):
		return false
	_ensure_blk(id)
	return _blk_who[id] == -1

func launchable() -> Array:
	var out: Array = []
	for u in ufos:
		if can_launch(u.spec.id):
			out.append(u.spec.id)
	return out

func remove_from_field(id: int) -> void:
	var u = ufos[id]
	u.in_grid = false
	u.away = false
	var g: int = u.spec.group
	if g >= 0:
		var lst: Array = groups[g]
		var i := lst.find(id)
		if i >= 0 and i + 1 < lst.size():
			ufos[lst[i + 1]].spawned = true
	field_version += 1
	_check_layer()

func _check_layer() -> void:
	while cur_layer < level.layer_count() - 1:
		var any_left := false
		for u in ufos:
			if u.in_grid and level.layer_of_ufo(u.spec.id) == cur_layer:
				any_left = true
				break
		if any_left:
			return
		cur_layer += 1
		layer_events += 1
		for u in ufos:
			var id: int = u.spec.id
			if not u.in_grid or level.layer_of_ufo(id) != cur_layer:
				continue
			var gr: int = u.spec.group
			if gr < 0 or groups[gr][0] == id:
				u.spawned = true
		field_version += 1

func is_vip_slot(k: int) -> bool:
	return level.has_vip() and k == 0

func free_slot() -> int:
	var start := 1 if level.has_vip() else 0
	for i in range(start, slots.size()):
		if slots[i] == -1:
			return i
	return -1

func free_slot_count() -> int:
	var n := 0
	var start := 1 if level.has_vip() else 0
	for i in range(start, slots.size()):
		if slots[i] == -1:
			n += 1
	return n

func tap(id: int) -> int:
	if not can_launch(id):
		return -1
	var k := free_slot()
	if k < 0:
		return -1
	var u = ufos[id]
	remove_from_field(id)
	moves_used += 1
	u.last_slot = k
	slots[k] = id
	slot_ready[k] = clock + LAND_SEC
	_after_move()
	return k

func tap_vip(id: int) -> int:
	if not level.has_vip() or slots[0] != -1:
		return -1
	var u = ufos[id]
	if not is_on_field(id):
		return -1
	remove_from_field(id)
	moves_used += 1
	u.last_slot = 0
	slots[0] = id
	slot_ready[0] = clock + BEAM_SEC
	_after_move()
	return 0

# ---------------------------------------------------------- arızalı UFO

func blocker_chain(id: int) -> int:
	var seen := {id: true}
	var stack: Array = [id]
	while not stack.is_empty():
		var a: int = stack.pop_back()
		var m = ufos[a].cur
		for o in ufos:
			if seen.has(o.spec.id) or not o.in_grid or not o.spawned:
				continue
			if Geo.sweep_hit(m, o.cur) >= 0.0:
				seen[o.spec.id] = true
				stack.append(o.spec.id)
	return seen.size() - 1

func _after_move() -> void:
	for u in ufos:
		if u.fault > 0 and u.in_grid and u.spawned and not u.away:
			u.fault -= 1
			if u.fault == 0 and not break_queue.has(u.spec.id):
				break_queue.append(u.spec.id)
		if u.away:
			u.away_moves += 1
	_try_return()

func _try_return() -> void:
	for u in ufos:
		if not u.away:
			continue
		var others := false
		for o in ufos:
			if o.spec.id != u.spec.id and o.in_grid and o.spawned and not o.away:
				others = true
				break
		if u.away_moves >= FAULT_AWAY_MOVES or not others:
			u.away = false
			u.spawned = true
			field_version += 1
			u.fault = blocker_chain(u.spec.id) + level.rules.fault_slack
			fault_events += 1

func repair_ufo(id: int) -> void:
	break_queue.erase(id)
	var u = ufos[id]
	u.fault = u.fault_base

func break_ufo(id: int) -> void:
	break_queue.erase(id)
	var u = ufos[id]
	u.fault = 0
	u.away = true
	u.away_moves = 0
	u.spawned = false
	field_version += 1
	fault_events += 1
	_try_return()

# ---------------------------------------------------------- bant UFO

func belt_pos(u) -> float:
	return sin(2.0 * PI * fmod(clock + u.belt_offset, level.rules.belt_cycle) / level.rules.belt_cycle)

func belt_open(u) -> bool:
	return absf(belt_pos(u)) < level.rules.belt_win

func missed_belt(id: int) -> bool:
	var u = ufos[id]
	if not u.belt or not is_on_field(id) or belt_open(u):
		return false
	_ensure_blk(id)
	return _blk_who[id] == -1

# ---------------------------------------------------------- dönen UFO

func rot_phase(u) -> float:
	var cyc: float = level.rules.rotor_on + level.rules.rotor_off
	return fmod(clock + u.rot_offset, cyc)

func rot_time_left(u) -> float:
	var ph := rot_phase(u)
	if ph < level.rules.rotor_on:
		return level.rules.rotor_on - ph
	return level.rules.rotor_on + level.rules.rotor_off - ph

func _update_rotors() -> void:
	if level.rules.rotors.is_empty():
		return
	for u in ufos:
		if not u.rotor:
			continue
		var f: bool = rot_phase(u) >= level.rules.rotor_on
		if f != u.flipped:
			u.flipped = f
			u.cur = u.flip if f else u.spec
			u.flip_clock = clock
			rot_version += 1
			field_version += 1

# ---------------------------------------------------------- zaman

func step(dt: float) -> Array:
	var ev: Array = []
	var left := dt
	while left > 1e-9:
		var h: float = 0.02 if left > 0.02 else left
		left -= h
		_advance(h, ev)
	return ev

func _advance(h: float, ev: Array) -> void:
	clock += h
	_update_rotors()
	var mul: float = INTRO_MUL if intro_active() else 1.0
	var dp: float = speed * mul * h
	var p0: float = phase
	phase += dp
	var n := slots.size()
	var cols := ring_cols()

	for g in n:
		var uid: int = slots[g]
		if uid < 0 or clock < slot_ready[g]:
			continue
		var u = ufos[uid]
		if u.departed:
			continue
		var gs := gate_s(g, n)
		for i in cells.size():
			var p = cells[i]
			if p == null:
				continue
			if u.boarded >= u.spec.seats:
				break
			if p.color != u.spec.color:
				continue
			var d: float = frac_s(gs - frac_s(p0 - cell_offset(i, cols)))
			if d > 0.0 and d <= dp:
				cells[i] = null
				occupied -= 1
				u.boarded += 1
				boarded_total += 1
				ev.append(BoardEvent.new(uid, p.id, p.color, i, g))
		if u.boarded >= u.spec.seats:
			u.departed = true

	if q_head() < level.total_passengers() and occupied < level.ring_cap:
		for i in cells.size():
			if cells[i] != null:
				continue
			if occupied >= level.ring_cap:
				break
			var off: float = frac_s(p0 - cell_offset(i, cols))
			for a in 2:
				if arm_head[a] >= arm_q[a].size():
					continue
				var es: float = entry_l if a == 0 else entry_r
				var d: float = frac_s(es - off)
				if d > 0.0 and d <= dp:
					cells[i] = Passenger.new(arm_id(a, arm_head[a]), arm_q[a][arm_head[a]])
					arm_head[a] += 1
					occupied += 1
					break

# ---------------------------------------------------------- bitiş

func won() -> bool:
	return occupied == 0 and q_head() >= level.total_passengers()

func stuck() -> bool:
	if free_slot() >= 0:
		return false
	for id in slots:
		if id >= 0 and ufos[id].departed:
			return false
	var need := {}
	for id in slots:
		if id < 0:
			continue
		var u = ufos[id]
		if u.boarded < u.spec.seats:
			need[u.spec.color] = true
	for p in cells:
		if p != null and need.has(p.color):
			return false
	var e: int = level.ring_cap - occupied
	var rem: int = level.total_passengers() - q_head()
	if rem < e:
		e = rem
	var h := [arm_head[0], arm_head[1]]
	var arm := 0
	for j in e:
		if h[arm] >= arm_q[arm].size():
			arm = 1 - arm
		if h[arm] >= arm_q[arm].size():
			break
		if need.has(arm_q[arm][h[arm]]):
			return false
		h[arm] += 1
		arm = 1 - arm
	return true

func lost() -> bool:
	return not won() and (out_of_moves() or stuck())

# ---------------------------------------------------------- booster'lar

func release_slot(uid: int) -> void:
	for i in slots.size():
		if slots[i] == uid and ufos[uid].departed:
			slots[i] = -1

func has_departing() -> bool:
	for id in slots:
		if id >= 0 and ufos[id].departed:
			return true
	return false

func add_slots(n: int) -> void:
	for i in n:
		slots.append(-1)
		slot_ready.append(0.0)

func unlock_slot() -> bool:
	if locked_slots <= 0:
		return false
	locked_slots -= 1
	add_slots(1)
	return true

func grant_slots(n: int) -> void:
	for i in n:
		if not unlock_slot():
			add_slots(1)

func direct_board() -> Array:
	var ev: Array = []
	for g in slots.size():
		var uid: int = slots[g]
		if uid < 0 or clock < slot_ready[g]:
			continue
		var u = ufos[uid]
		if u.departed:
			continue
		var i := 0
		while i < cells.size() and u.boarded < u.spec.seats:
			var p = cells[i]
			if p != null and p.color == u.spec.color:
				cells[i] = null
				occupied -= 1
				u.boarded += 1
				boarded_total += 1
				ev.append(BoardEvent.new(uid, p.id, p.color, i, g))
			i += 1
		if u.boarded >= u.spec.seats:
			u.departed = true
	return ev

func shuffle_queue(seed_v: int) -> void:
	var s: int = (seed_v * 2654435761) % 4294967296
	var cut: Array = level.arm_cut
	var phases := 1 if cut.is_empty() else 2
	for ph in phases:
		var pos: Array = []
		for a in 2:
			var lo: int = arm_head[a]
			var hi: int = arm_q[a].size()
			if not cut.is_empty():
				if ph == 0:
					hi = mini(hi, int(cut[a]))
				else:
					lo = maxi(lo, int(cut[a]))
			for m in range(lo, hi):
				pos.append([a, m])
		var vals: Array = []
		for q in pos:
			vals.append(arm_q[q[0]][q[1]])
		var i := vals.size() - 1
		while i > 0:
			s = (s * 1664525 + 1013904223) % 4294967296
			var j: int = s % (i + 1)
			var t = vals[i]
			vals[i] = vals[j]
			vals[j] = t
			i -= 1
		for k in pos.size():
			arm_q[pos[k][0]][pos[k][1]] = vals[k]
