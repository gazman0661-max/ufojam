class_name StageData
extends RefCounted
# level_data.dart / stage_extras.dart / ring_data.dart / ring_shapes.dart / *_order.dart verileri (data/levels.json)

static var loaded := false
static var stages := {}      # int -> Array[String] (araç satırları, kol1, kol2)
static var layers := {}      # int -> Array[int]
static var arms := {}        # int -> Array[String]
static var arm_cut := {}     # int -> Array[int]
static var rotors := {}      # int -> Array[int]
static var faulty := {}
static var belts := {}
static var ring_data := {}   # int -> Array[float]
static var stage_order: Array = []
static var story: Array = []
static var early: Array = []
static var late: Array = []
static var shapes := {}      # "kRingOval" -> Dictionary
static var stage_shapes := {} # int -> "kRingXxx"

static func _ints(a: Array) -> Array:
	var o: Array = []
	for v in a:
		o.append(int(v))
	return o

static func _int_map(d: Dictionary) -> Dictionary:
	var o := {}
	for k in d:
		o[int(k)] = _ints(d[k])
	return o

static func load_all() -> void:
	if loaded:
		return
	loaded = true
	var txt := FileAccess.get_file_as_string("res://data/levels.json")
	var d: Dictionary = JSON.parse_string(txt)
	for k in d["stages"]:
		stages[int(k)] = d["stages"][k]
	for k in d["arms"]:
		arms[int(k)] = d["arms"][k]
	layers = _int_map(d["layers"])
	arm_cut = _int_map(d["arm_cut"])
	rotors = _int_map(d["rotors"])
	faulty = _int_map(d["faulty"])
	belts = _int_map(d["belts"])
	for k in d["ring_data"]:
		ring_data[int(k)] = d["ring_data"][k]
	stage_order = _ints(d["stage_order"])
	story = _ints(d["story"])
	early = _ints(d["early"])
	late = _ints(d["late"])
	shapes = d["shapes"]
	for k in d["stage_shapes"]:
		stage_shapes[int(k)] = d["stage_shapes"][k]

static func ring_cap_for(stage: int) -> int:
	var r = ring_data.get(stage, null)
	return 78 if r == null else int(r[4])

static func shape_for(stage: int) -> Dictionary:
	var nm: String = stage_shapes.get(stage, "kRingOval")
	return shapes[nm]
