extends Node
# audio.dart karşılığı: müzik (döngü, ducking) + ses efekti havuzları.

enum MusicTrack { NONE, MENU, GAME }
enum Sfx { UFO_CALL, BEAM1, BEAM2, BEAM3, UFO_BLOCKED, UFO_FULL, UFO_DEPART, VIP_TELEPORT, SHUFFLE,
	BOOSTER_BOARD, LAYER_UP, UFO_BREAK, UFO_REPAIR, WIN, LOSE, CLICK, COIN, PORTAL_SPAWN, LEVEL_START, WARN }

const VOL_MENU := 0.30
const VOL_GAME := 0.26
const DUCK_FADE_OUT_MS := 160
const DUCK_FADE_IN_MS := 900

# file, pool, gapMs, vol
var DEFS := {
	Sfx.UFO_CALL: ["ufo_swoosh.mp3", 3, 0, 0.9],
	Sfx.BEAM1: ["beam_pop_1.mp3", 5, 0, 0.85],
	Sfx.BEAM2: ["beam_pop_2.mp3", 5, 0, 0.85],
	Sfx.BEAM3: ["beam_pop_3.mp3", 5, 0, 0.85],
	Sfx.UFO_BLOCKED: ["error_buzz.mp3", 2, 120, 0.75],
	Sfx.UFO_FULL: ["ufo_full.wav", 2, 0, 0.9],
	Sfx.UFO_DEPART: ["ufo_fly.mp3", 4, 0, 1.0],
	Sfx.VIP_TELEPORT: ["teleport.mp3", 2, 0, 1.0],
	Sfx.SHUFFLE: ["shuffle.wav", 2, 0, 1.0],
	Sfx.BOOSTER_BOARD: ["booster_board.wav", 2, 0, 1.0],
	Sfx.LAYER_UP: ["layer_up.wav", 2, 0, 1.0],
	Sfx.UFO_BREAK: ["ufo_break.wav", 2, 0, 1.0],
	Sfx.UFO_REPAIR: ["ufo_repair.wav", 2, 0, 1.0],
	Sfx.WIN: ["level_complete.mp3", 1, 0, 1.0],
	Sfx.LOSE: ["lose.wav", 1, 0, 0.95],
	Sfx.CLICK: ["ui_button.mp3", 2, 40, 1.0],
	Sfx.COIN: ["coin.mp3", 2, 60, 0.9],
	Sfx.PORTAL_SPAWN: ["teleport.mp3", 2, 150, 0.6],
	Sfx.LEVEL_START: ["level_start.wav", 1, 0, 0.85],
	Sfx.WARN: ["warn.wav", 2, 150, 0.8],
}

var _ready_flag := false
var _bg := false
var _music: AudioStreamPlayer
var _wanted: int = MusicTrack.NONE
var _loaded: int = MusicTrack.NONE
var _running := false
var _ducked := false
var _cur_vol := 0.0
var _target_vol := 0.0
var _fade_rate := 0.0 # doğrusal/sn
var _duck_token := 0
var _pools := {}
var _next := {}
var _last := {}
var _beam_idx := 0
var _beam_last := 0

func init() -> void:
	if _ready_flag:
		return
	_ready_flag = true
	_music = AudioStreamPlayer.new()
	add_child(_music)
	var s = load("res://assets/audio/bgm_main.mp3")
	if s is AudioStreamMP3:
		s.loop = true
	_music.stream = s
	for k in DEFS:
		var d: Array = DEFS[k]
		var st = load("res://assets/audio/" + d[0])
		var lst: Array = []
		for i in int(d[1]):
			var p := AudioStreamPlayer.new()
			p.stream = st
			p.volume_db = linear_to_db(float(d[3]))
			add_child(p)
			lst.append(p)
		_pools[k] = lst
	set_process(true)

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		_bg = true
		_sync()
	elif what == NOTIFICATION_APPLICATION_RESUMED or what == NOTIFICATION_WM_WINDOW_FOCUS_IN:
		_bg = false
		_sync()

func _vol_for(t: int) -> float:
	return VOL_GAME if t == MusicTrack.GAME else VOL_MENU

func _music_vol_now(t: int) -> float:
	return 0.0 if _ducked else _vol_for(t)

func music(t: int) -> void:
	_wanted = t
	_sync()

func refresh() -> void:
	_sync()

func _sync() -> void:
	if _music == null:
		return
	var want: int = _wanted if (Settings.music and not _bg) else MusicTrack.NONE
	if want == MusicTrack.NONE:
		if _running:
			_music.stream_paused = true
			_running = false
		return
	# menü ve oyun aynı dosyayı paylaşır: parça değişiminde müzik baştan başlamaz
	if not _music.playing:
		_cur_vol = _music_vol_now(want)
		_target_vol = _cur_vol
		_music.volume_db = linear_to_db(maxf(_cur_vol, 0.0001))
		_music.play()
		_music.stream_paused = false
		_running = true
		_loaded = want
		return
	if not _running:
		_music.stream_paused = false
		_running = true
		_cur_vol = _music_vol_now(want)
		_target_vol = _cur_vol
		_music.volume_db = linear_to_db(maxf(_cur_vol, 0.0001))
	if want != _loaded:
		_loaded = want
		_cur_vol = _music_vol_now(want)
		_target_vol = _cur_vol
		_music.volume_db = linear_to_db(maxf(_cur_vol, 0.0001))

func _fade_music(to: float, ms: int) -> void:
	if _music == null or not _running:
		_cur_vol = to
		_target_vol = to
		return
	_target_vol = to
	_fade_rate = absf(to - _cur_vol) / (maxf(ms, 1) / 1000.0)

func _process(delta: float) -> void:
	if _music == null or not _running:
		return
	if not is_equal_approx(_cur_vol, _target_vol):
		var step := _fade_rate * delta
		if _cur_vol < _target_vol:
			_cur_vol = minf(_target_vol, _cur_vol + step)
		else:
			_cur_vol = maxf(_target_vol, _cur_vol - step)
		_music.volume_db = linear_to_db(maxf(_cur_vol, 0.0001))

func duck_music(ms: int) -> void:
	_ducked = true
	_duck_token += 1
	var tok := _duck_token
	_fade_music(0.0, DUCK_FADE_OUT_MS)
	get_tree().create_timer(ms / 1000.0).timeout.connect(func():
		if tok != _duck_token:
			return
		_ducked = false
		_fade_music(_vol_for(_loaded), DUCK_FADE_IN_MS))

func play(s: int) -> void:
	if not Settings.sfx or not _ready_flag:
		return
	var d: Array = DEFS[s]
	var now := Time.get_ticks_msec()
	var gap: int = d[2]
	if gap > 0 and now - int(_last.get(s, 0)) < gap:
		return
	_last[s] = now
	var lst: Array = _pools[s]
	if lst.is_empty():
		return
	var idx: int = int(_next.get(s, 0)) % lst.size()
	_next[s] = idx + 1
	var p: AudioStreamPlayer = lst[idx]
	p.play()

func beam() -> void:
	if not Settings.sfx:
		return
	var now := Time.get_ticks_msec()
	if now - _beam_last > 1000:
		_beam_idx = 0
	_beam_last = now
	var seq := [Sfx.BEAM1, Sfx.BEAM2, Sfx.BEAM3, Sfx.BEAM2]
	play(seq[_beam_idx % seq.size()])
	_beam_idx += 1
