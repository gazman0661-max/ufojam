extends Node
# Navigator karşılığı: ekran yığını.

var root: Control
var stack: Array = []

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if stack.size() > 1:
			var top = stack.back()
			if top.has_method("on_back"):
				top.on_back()
			else:
				pop()

func push(screen: Control) -> void:
	if stack.size() > 0:
		var prev: Control = stack.back()
		prev.visible = false
		prev.process_mode = Node.PROCESS_MODE_DISABLED
	screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(screen)
	stack.append(screen)

func pop() -> void:
	if stack.is_empty():
		return
	var s: Control = stack.pop_back()
	s.queue_free()
	if stack.size() > 0:
		var prev: Control = stack.back()
		prev.visible = true
		prev.process_mode = Node.PROCESS_MODE_INHERIT
		if prev.has_method("on_resume"):
			prev.on_resume()

func replace(screen: Control) -> void:
	if stack.size() > 0:
		var s: Control = stack.pop_back()
		s.queue_free()
	screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(screen)
	stack.append(screen)
