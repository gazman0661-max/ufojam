extends Node
# shared_preferences karşılığı: user://save.json

const PATH := "user://save.json"
var data: Dictionary = {}

func _ready() -> void:
	if FileAccess.file_exists(PATH):
		var f := FileAccess.open(PATH, FileAccess.READ)
		if f:
			var j = JSON.parse_string(f.get_as_text())
			if typeof(j) == TYPE_DICTIONARY:
				data = j

func get_v(k: String, d = null):
	return data.get(k, d)

func set_v(k: String, v) -> void:
	data[k] = v

func save() -> void:
	var f := FileAccess.open(PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data))
