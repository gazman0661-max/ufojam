class_name UI
extends RefCounted
# Flutter widget/painter yardımcılarının Godot karşılıkları: renkler, yazı tipleri, dokular, çizim araçları.

static func argb(v: int) -> Color:
	return Color8((v >> 16) & 255, (v >> 8) & 255, v & 255, (v >> 24) & 255)

static func with_a(c: Color, a255: float) -> Color:
	return Color(c.r, c.g, c.b, clampf(a255 / 255.0, 0.0, 1.0))

static var COLOR_NAMES := ["red", "blue", "green", "yellow", "purple", "orange", "pink", "lightblue",
	"white", "black", "brown", "lime", "teal", "maroon", "navy"]
static var COLORS: Array = [
	argb(0xFFE53935), argb(0xFF3F6FFF), argb(0xFF43C443), argb(0xFFFFD600), argb(0xFF9C4DFF),
	argb(0xFFFF8F00), argb(0xFFFF6FB0), argb(0xFF5CC8FF), argb(0xFFF2F2F2), argb(0xFF787878),
	argb(0xFF8D5A3C), argb(0xFFB4E33D), argb(0xFF26C6A6), argb(0xFF9B1C1C), argb(0xFF283593)]

# ------------------------------------------------------------------ dokular

static var _tex := {}
static var _white := {}
static var _tinted := {}

# Mipmap'li kopya (Flutter'ın küçültme kalitesine yakın)
static func tex(name: String) -> Texture2D:
	if _tex.has(name):
		return _tex[name]
	var t: Texture2D = load("res://assets/img/" + name + ".webp")
	if t == null:
		t = load("res://assets/img/" + name + ".png")
	var out: Texture2D = t
	if t != null:
		var img := t.get_image()
		if img != null:
			if img.is_compressed():
				img.decompress()
			img.generate_mipmaps()
			out = ImageTexture.create_from_image(img)
	_tex[name] = out
	return out

# Alien sprite: Flutter'daki gibi 72 px genişliğe indirilmiş kopya
static func alien_small(color: int) -> Texture2D:
	var key := "alien_small_%d" % color
	if _tex.has(key):
		return _tex[key]
	var t: Texture2D = load("res://assets/img/alien_%s.webp" % COLOR_NAMES[color])
	var out: Texture2D = t
	if t != null:
		var img := t.get_image()
		if img != null:
			if img.is_compressed():
				img.decompress()
			var h := int(round(img.get_height() * 72.0 / img.get_width()))
			img.resize(72, h, Image.INTERPOLATE_LANCZOS)
			img.generate_mipmaps()
			out = ImageTexture.create_from_image(img)
	_tex[key] = out
	return out

# srcATop renk karışımı (ColorFilter.mode(color, BlendMode.srcATop))
static func tinted(name: String, tint: Color) -> Texture2D:
	var key := "%s|%s" % [name, tint.to_html(true)]
	if _tinted.has(key):
		return _tinted[key]
	var src: Texture2D = tex(name)
	var img := src.get_image()
	if img.is_compressed():
		img.decompress()
	img.convert(Image.FORMAT_RGBA8)
	for y in img.get_height():
		for x in img.get_width():
			var c := img.get_pixel(x, y)
			var r := Color(lerpf(c.r, tint.r, tint.a), lerpf(c.g, tint.g, tint.a), lerpf(c.b, tint.b, tint.a), c.a)
			img.set_pixel(x, y, r)
	img.generate_mipmaps()
	var t := ImageTexture.create_from_image(img)
	_tinted[key] = t
	return t

# Gizemli UFO filtresi (ColorFilter.matrix)
static func mystery(name: String) -> Texture2D:
	var key := "mys|" + name
	if _tinted.has(key):
		return _tinted[key]
	var src: Texture2D = tex(name)
	var img := src.get_image()
	if img.is_compressed():
		img.decompress()
	img.convert(Image.FORMAT_RGBA8)
	for y in img.get_height():
		for x in img.get_width():
			var c := img.get_pixel(x, y)
			if c.a <= 0.0:
				continue
			var r := clampf(0.16 * c.r + 0.16 * c.g + 0.16 * c.b + 8.0 / 255.0, 0.0, 1.0)
			var g := clampf(0.16 * c.r + 0.16 * c.g + 0.16 * c.b + 8.0 / 255.0, 0.0, 1.0)
			var b := clampf(0.17 * c.r + 0.17 * c.g + 0.17 * c.b + 14.0 / 255.0, 0.0, 1.0)
			img.set_pixel(x, y, Color(r, g, b, c.a))
	img.generate_mipmaps()
	var t := ImageTexture.create_from_image(img)
	_tinted[key] = t
	return t

# Beyaz siluet (parlama şeridi için)
static func white_of(name: String) -> Texture2D:
	var key := "wh|" + name
	if _white.has(key):
		return _white[key]
	var src: Texture2D = tex(name)
	var img := src.get_image()
	if img.is_compressed():
		img.decompress()
	img.convert(Image.FORMAT_RGBA8)
	for y in img.get_height():
		for x in img.get_width():
			var c := img.get_pixel(x, y)
			img.set_pixel(x, y, Color(1, 1, 1, c.a))
	img.generate_mipmaps()
	var t := ImageTexture.create_from_image(img)
	_white[key] = t
	return t

static var _radial: Texture2D
static func radial_tex() -> Texture2D:
	if _radial == null:
		var g := Gradient.new()
		g.offsets = PackedFloat32Array([0.0, 1.0])
		g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0)])
		var t := GradientTexture2D.new()
		t.gradient = g
		t.fill = GradientTexture2D.FILL_RADIAL
		t.fill_from = Vector2(0.5, 0.5)
		t.fill_to = Vector2(1.0, 0.5)
		t.width = 128
		t.height = 128
		_radial = t
	return _radial

# ------------------------------------------------------------------ yazı

static var _bold: FontVariation
static func font(bold: bool = true) -> Font:
	if not bold:
		return ThemeDB.fallback_font
	if _bold == null:
		_bold = FontVariation.new()
		_bold.base_font = ThemeDB.fallback_font
		_bold.variation_embolden = 0.7
	return _bold

static func text_width(s: String, size: float, bold: bool = true) -> float:
	return font(bold).get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, int(round(size))).x

# rect içinde yatay+dikey ortalı yazı
static func text_c(ci: CanvasItem, r: Rect2, s: String, size: float, col: Color, bold: bool = true, shadow: Color = Color(0, 0, 0, 0)) -> void:
	var f := font(bold)
	var fs := int(round(size))
	var w := f.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
	var asc := f.get_ascent(fs)
	var desc := f.get_descent(fs)
	var x := r.position.x + (r.size.x - w) / 2.0
	var y := r.position.y + (r.size.y + asc - desc) / 2.0
	if shadow.a > 0.0:
		ci.draw_string(f, Vector2(x + 1, y + 2), s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, shadow)
	ci.draw_string(f, Vector2(x, y), s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, col)

# sol-üst köşe verilen yazı
static func text_tl(ci: CanvasItem, p: Vector2, s: String, size: float, col: Color, bold: bool = true) -> void:
	var f := font(bold)
	var fs := int(round(size))
	ci.draw_string(f, Vector2(p.x, p.y + f.get_ascent(fs)), s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, col)

static func text_outlined_c(ci: CanvasItem, r: Rect2, s: String, size: float, fill: Color, outline: Color, ow: float) -> void:
	var f := font(true)
	var fs := int(round(size))
	var w := f.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
	var asc := f.get_ascent(fs)
	var desc := f.get_descent(fs)
	var x := r.position.x + (r.size.x - w) / 2.0
	var y := r.position.y + (r.size.y + asc - desc) / 2.0
	ci.draw_string_outline(f, Vector2(x, y), s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, int(ow), outline)
	ci.draw_string(f, Vector2(x, y), s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, fill)

# Satır sarma (genişliğe göre); satır listesi döner
static func wrap(s: String, size: float, width: float, bold: bool = false) -> Array:
	var lines: Array = []
	for para in s.split("\n"):
		var words := para.split(" ")
		var cur := ""
		for w in words:
			var t := w if cur == "" else cur + " " + w
			if text_width(t, size, bold) > width and cur != "":
				lines.append(cur)
				cur = w
			else:
				cur = t
		lines.append(cur)
	return lines

# ------------------------------------------------------------------ şekiller

static func rrect_pts(r: Rect2, rad: float, seg: int = 8) -> PackedVector2Array:
	rad = minf(rad, minf(r.size.x, r.size.y) / 2.0)
	var pts := PackedVector2Array()
	var corners := [
		[Vector2(r.position.x + r.size.x - rad, r.position.y + rad), -PI / 2],
		[Vector2(r.position.x + r.size.x - rad, r.position.y + r.size.y - rad), 0.0],
		[Vector2(r.position.x + rad, r.position.y + r.size.y - rad), PI / 2],
		[Vector2(r.position.x + rad, r.position.y + rad), PI],
	]
	for c in corners:
		for i in range(seg + 1):
			var a: float = c[1] + (PI / 2) * i / seg
			pts.append(c[0] + Vector2(cos(a), sin(a)) * rad)
	return pts

static func fill_rrect(ci: CanvasItem, r: Rect2, rad: float, col: Color) -> void:
	if col.a <= 0.0:
		return
	ci.draw_colored_polygon(rrect_pts(r, rad), col)

# Dikey degrade (üst -> alt), isteğe bağlı ara duraklar
static func grad_rrect_v(ci: CanvasItem, r: Rect2, rad: float, c0: Color, c1: Color) -> void:
	var pts := rrect_pts(r, rad)
	var cols := PackedColorArray()
	for p in pts:
		var t := clampf((p.y - r.position.y) / maxf(r.size.y, 0.001), 0.0, 1.0)
		cols.append(c0.lerp(c1, t))
	ci.draw_polygon(pts, cols)

static func grad_rrect_d(ci: CanvasItem, r: Rect2, rad: float, c0: Color, c1: Color, c2: Color) -> void:
	# sol-üst -> sağ-alt, 3 renk
	var pts := rrect_pts(r, rad)
	var cols := PackedColorArray()
	var d := Vector2(r.size.x, r.size.y)
	for p in pts:
		var rel := p - r.position
		var t := clampf((rel.x * d.x + rel.y * d.y) / (d.x * d.x + d.y * d.y), 0.0, 1.0)
		if t < 0.5:
			cols.append(c0.lerp(c1, t * 2.0))
		else:
			cols.append(c1.lerp(c2, (t - 0.5) * 2.0))
	ci.draw_polygon(pts, cols)

static func stroke_rrect(ci: CanvasItem, r: Rect2, rad: float, col: Color, w: float) -> void:
	var pts := rrect_pts(r, rad)
	pts.append(pts[0])
	ci.draw_polyline(pts, col, w, true)

# Bulanık gölge benzeri: genişleyen şeffaf katmanlar
static func shadow_rrect(ci: CanvasItem, r: Rect2, rad: float, col: Color, blur: float, offset: Vector2 = Vector2.ZERO, spread: float = 0.0) -> void:
	var steps := 5
	for i in range(steps, 0, -1):
		var k := float(i) / steps
		var e := spread + blur * k
		var rr := Rect2(r.position + offset - Vector2(e, e), r.size + Vector2(e, e) * 2.0)
		var c := Color(col.r, col.g, col.b, col.a * 0.22 / steps * 2.0)
		ci.draw_colored_polygon(rrect_pts(rr, rad + e), c)

static func circle(ci: CanvasItem, c: Vector2, r: float, col: Color) -> void:
	ci.draw_circle(c, r, col)

static func ring(ci: CanvasItem, c: Vector2, r: float, col: Color, w: float) -> void:
	ci.draw_arc(c, r, 0.0, TAU, 40, col, w, true)

# BoxFit.contain
static func draw_contain(ci: CanvasItem, t: Texture2D, box: Rect2, mod: Color = Color.WHITE) -> void:
	if t == null:
		return
	var ts := t.get_size()
	var s := minf(box.size.x / ts.x, box.size.y / ts.y)
	var sz := ts * s
	ci.draw_texture_rect(t, Rect2(box.position + (box.size - sz) / 2.0, sz), false, mod)

# BoxFit.cover (arka plan)
static func draw_cover(ci: CanvasItem, t: Texture2D, box: Rect2, mod: Color = Color.WHITE) -> void:
	if t == null:
		return
	var ts := t.get_size()
	var s := maxf(box.size.x / ts.x, box.size.y / ts.y)
	var sz := ts * s
	var dst := Rect2(box.position + (box.size - sz) / 2.0, sz)
	# kutu dışını kırp
	var inter := dst.intersection(box)
	var src := Rect2((inter.position - dst.position) / s, inter.size / s)
	ci.draw_texture_rect_region(t, inter, src, mod)

# Kırpmalı çizim (ClipRect)
static func draw_clipped(ci: CanvasItem, t: Texture2D, dst: Rect2, clip: Rect2) -> void:
	var inter := dst.intersection(clip)
	if inter.size.x <= 0 or inter.size.y <= 0:
		return
	var ts := t.get_size()
	var sx := ts.x / dst.size.x
	var sy := ts.y / dst.size.y
	var src := Rect2((inter.position - dst.position) * Vector2(sx, sy), inter.size * Vector2(sx, sy))
	ci.draw_texture_rect_region(t, inter, src)

# ------------------------------------------------------------------ simgeler (Material ikon yerine vektör)

static func icon_arrow_back(ci: CanvasItem, c: Vector2, s: float, col: Color) -> void:
	var h := s * 0.36
	ci.draw_line(c + Vector2(-h, 0), c + Vector2(h, 0), col, s * 0.11, true)
	ci.draw_polyline(PackedVector2Array([c + Vector2(-h * 0.1, -h * 0.85), c + Vector2(-h, 0), c + Vector2(-h * 0.1, h * 0.85)]), col, s * 0.11, true)

static func icon_refresh(ci: CanvasItem, c: Vector2, s: float, col: Color) -> void:
	var r := s * 0.30
	ci.draw_arc(c, r, -PI * 0.15, PI * 1.55, 24, col, s * 0.1, true)
	var a := PI * 1.55
	var tip := c + Vector2(cos(a), sin(a)) * r
	ci.draw_polyline(PackedVector2Array([tip + Vector2(-s * 0.02, -s * 0.2), tip, tip + Vector2(s * 0.2, s * 0.0)]), col, s * 0.1, true)

static func icon_arrow_up(ci: CanvasItem, c: Vector2, s: float, col: Color) -> void:
	var h := s * 0.38
	ci.draw_line(c + Vector2(0, h), c + Vector2(0, -h), col, s * 0.16, true)
	ci.draw_polyline(PackedVector2Array([c + Vector2(-h * 0.85, -h * 0.1), c + Vector2(0, -h), c + Vector2(h * 0.85, -h * 0.1)]), col, s * 0.16, true)

static func icon_lock(ci: CanvasItem, c: Vector2, s: float, col: Color) -> void:
	var w := s * 0.62
	var h := s * 0.46
	fill_rrect(ci, Rect2(c.x - w / 2, c.y - h * 0.15, w, h), s * 0.08, col)
	ci.draw_arc(c + Vector2(0, -h * 0.15), w * 0.3, PI, TAU, 14, col, s * 0.1, true)

static func icon_plus(ci: CanvasItem, c: Vector2, s: float, col: Color) -> void:
	ci.draw_line(c + Vector2(-s * 0.3, 0), c + Vector2(s * 0.3, 0), col, s * 0.13, true)
	ci.draw_line(c + Vector2(0, -s * 0.3), c + Vector2(0, s * 0.3), col, s * 0.13, true)

static func icon_play(ci: CanvasItem, c: Vector2, s: float, col: Color) -> void:
	ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-s * 0.28, -s * 0.36), c + Vector2(s * 0.38, 0), c + Vector2(-s * 0.28, s * 0.36)]), col)

static func icon_video(ci: CanvasItem, c: Vector2, s: float, col: Color) -> void:
	fill_rrect(ci, Rect2(c.x - s * 0.4, c.y - s * 0.28, s * 0.8, s * 0.56), s * 0.1, col)
	icon_play(ci, c, s * 0.5, Color(0, 0, 0, 0.55))

static func icon_hand(ci: CanvasItem, c: Vector2, s: float, col: Color, shadow: Color) -> void:
	# basit "dokun" eli: parmak + avuç
	for pass_i in 2:
		var cc := col if pass_i == 1 else shadow
		var o := Vector2(0, 0) if pass_i == 1 else Vector2(1.5, 2.5)
		fill_rrect(ci, Rect2(c.x - s * 0.1 + o.x, c.y - s * 0.46 + o.y, s * 0.2, s * 0.55), s * 0.1, cc)
		fill_rrect(ci, Rect2(c.x - s * 0.3 + o.x, c.y - s * 0.02 + o.y, s * 0.6, s * 0.42), s * 0.16, cc)
