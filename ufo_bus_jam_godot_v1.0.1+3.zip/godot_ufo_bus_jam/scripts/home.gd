extends Control
# home_screen.dart karşılığı

const TAU_ := TAU
const UFO_NAMES := ["blue", "pink", "green", "orange", "purple", "yellow", "red", "teal",
	"lightblue", "lime", "navy", "brown", "maroon", "white", "black"]
var _t0 := 0
var _pressed := false
var _press_ms := 0
var _stars: Array = []
var _rects := {}
var _down_key := ""

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	Audio.music(Audio.MusicTrack.MENU)
	_t0 = Time.get_ticks_msec()
	var r := RandomNumberGenerator.new()
	r.seed = 7
	for i in 28:
		_stars.append([r.randf(), r.randf(), r.randf() * TAU, 1.0 + r.randf() * 1.8])
	L.changed.connect(queue_redraw)
	set_process(true)

func on_resume() -> void:
	Audio.music(Audio.MusicTrack.MENU)
	queue_redraw()

func _process(_d: float) -> void:
	queue_redraw()

func _top() -> float:
	var sa := DisplayServer.get_display_safe_area()
	var win := DisplayServer.window_get_size()
	return maxf(0.0, sa.position.y * size.y / maxf(win.y, 1.0))

func _bottom() -> float:
	var sa := DisplayServer.get_display_safe_area()
	var win := DisplayServer.window_get_size()
	return maxf(0.0, (win.y - sa.end.y) * size.y / maxf(win.y, 1.0))

func _ease_out_cubic(x: float) -> float:
	return 1.0 - pow(1.0 - x, 3.0)

func _in(a: float, b: float) -> float:
	var intro := clampf((Time.get_ticks_msec() - _t0) / 1100.0, 0.0, 1.0)
	return _ease_out_cubic(clampf((intro - a) / (b - a), 0.0, 1.0))

func _gui_input(e: InputEvent) -> void:
	if not ((e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT) or e is InputEventScreenTouch):
		return
	if e.pressed:
		_down_key = ""
		for k in _rects:
			if (_rects[k] as Rect2).has_point(e.position):
				_down_key = k
		_pressed = _down_key == "play"
	else:
		var hit := ""
		for k in _rects:
			if (_rects[k] as Rect2).has_point(e.position):
				hit = k
		_pressed = false
		if hit != "" and hit == _down_key:
			_activate(hit)
		_down_key = ""

func _activate(k: String) -> void:
	match k:
		"settings":
			Audio.play(Audio.Sfx.CLICK)
			Nav.push(load("res://scripts/settings_screen.gd").new())
		"shop":
			Audio.play(Audio.Sfx.CLICK)
			Nav.push(load("res://scripts/store_screen.gd").new())
		"play":
			Audio.play(Audio.Sfx.CLICK)
			var gs = load("res://scripts/game_screen.gd").new()
			gs.start_level = Progress.level
			Nav.push(gs)
		"reset":
			_confirm_reset()

func _confirm_reset() -> void:
	var p := GamePopup.show_popup(self, {
		"emoji": "⚠️", "title": L.t("İlerleme sıfırlansın mı?", "Reset progress?"),
		"message": L.t("Seviyen ve coinlerin baştan başlar. Bu işlem geri alınamaz.", "Your level and coins will start over. This cannot be undone."),
		"accent": UI.argb(0xFFFF5252), "dismissible": true,
		"buttons": [
			{"label": L.t("Vazgeç", "Cancel"), "kind": GamePopup.Kind.GHOST, "value": false},
			{"label": L.t("Sıfırla", "Reset"), "kind": GamePopup.Kind.DANGER, "value": true}]})
	var ok = await p.closed
	if ok == true:
		Progress.reset()

func _draw() -> void:
	var W := size.x
	var H := size.y
	var t := fmod((Time.get_ticks_msec() - _t0) / 1000.0, 6.0) / 6.0
	draw_rect(Rect2(Vector2.ZERO, size), UI.argb(0xFF0B0620))
	UI.draw_cover(self, UI.tex("bg_station"), Rect2(Vector2.ZERO, size))
	var n := 24
	for i in n:
		var t0 := float(i) / n
		var a := 130.0 + (20.0 - 130.0) * t0 * 2.0 if t0 < 0.5 else 20.0 + (150.0 - 20.0) * (t0 - 0.5) * 2.0
		draw_rect(Rect2(0, H * t0, W, H / n + 1), Color(0, 0, 0, a / 255.0))
	for s in _stars:
		var tw := 0.5 + 0.5 * sin(t * PI * 2 * 2 + s[2])
		draw_circle(Vector2(s[0] * W, s[1] * H), s[3] * (0.7 + 0.6 * tw), Color(1, 1, 1, (40 + 190 * tw) / 255.0))
	_rects.clear()
	var top := _top()
	var bot := _bottom()
	# üst satır
	var p0 := _in(0.0, 0.4)
	var dy := -14.0 * (1 - p0)
	var sb := Rect2(16, top + 10 + dy, 46, 46)
	_rects["settings"] = sb
	draw_circle(sb.get_center(), 23, Color(0, 0, 0, 110.0 / 255.0 * p0))
	draw_arc(sb.get_center(), 22.25, 0, TAU, 40, Color(1, 1, 1, 70.0 / 255.0 * p0), 1.5, true)
	_gear(sb.get_center(), 24, Color(1, 1, 1, p0))
	var coin_s := str(Progress.coins)
	var cw := UI.text_width(coin_s, 18, true)
	var pw := 10 + 26 + 8 + cw + 12 + 26 + 8   # sağda "+" (mağaza) alanı
	var pr := Rect2(W - 16 - pw, top + 10 + dy + (46 - 38) / 2.0, pw, 38)
	UI.fill_rrect(self, pr, 22, Color(0, 0, 0, 110.0 / 255.0 * p0))
	UI.stroke_rrect(self, pr, 22, Color(1, 1, 1, 70.0 / 255.0 * p0), 1.5)
	draw_texture_rect(UI.tex("coin"), Rect2(pr.position.x + 10, pr.position.y + 6, 26, 26), false, Color(1, 1, 1, p0))
	UI.text_c(self, Rect2(pr.position.x + 44, pr.position.y, cw + 2, 38), coin_s, 18, Color(1, 1, 1, p0), true)
	_rects["shop"] = pr
	var plus_c := Vector2(pr.end.x - 8 - 13, pr.get_center().y)
	draw_circle(plus_c, 13, UI.with_a(UI.argb(0xFF4CD964), 235.0 * p0))
	UI.icon_plus(self, plus_c, 30, Color(1, 1, 1, p0))
	# logo
	var p1 := _in(0.05, 0.5)
	_logo_line("UFO BUS", 50, Vector2(W / 2.0, top + 10 + 46 + 6 + 34 + 26 * (1 - p1)), p1)
	_logo_line("JAM", 72, Vector2(W / 2.0, top + 10 + 46 + 6 + 34 + 26 * (1 - p1) + 70), p1)
	var sub_y := top + 10 + 46 + 6 + 34 + 70 + 52 + 6
	var p2 := _in(0.2, 0.6)
	UI.text_c(self, Rect2(0, sub_y + 26 * (1 - p2), W, 20), L.t("Yolcuları doğru UFO'ya bindir!", "Get the passengers on the right UFO!"), 15, Color(1, 1, 1, p2), true, Color(0, 0, 0, p2))
	# alt bloklar
	var play_y := H - bot - 10 - 24 - 6 - 70
	var lp_y := play_y - 12 - 30
	var hero_top := sub_y + 24
	var hero_h := lp_y - hero_top
	var p3 := _in(0.25, 0.8)
	_hero(W, hero_h, hero_top + 40 * (1 - p3), t, p3)
	var p4 := _in(0.5, 0.9)
	var lvl := L.t("SEVİYE %d" % Progress.level, "LEVEL %d" % Progress.level)
	var lw := UI.text_width(lvl, 14, true) + lvl.length() * 2.5 + 36
	var lr := Rect2((W - lw) / 2.0, lp_y + 10 * (1 - p4), lw, 30)
	UI.fill_rrect(self, lr, 18, Color(0, 0, 0, 110.0 / 255.0 * p4))
	UI.stroke_rrect(self, lr, 18, Color(1, 1, 1, 70.0 / 255.0 * p4), 1.5)
	UI.text_c(self, lr, lvl, 14, Color(1, 1, 1, p4), true)
	# oyna
	var p5 := _in(0.55, 1.0)
	var glow := 0.5 + 0.5 * sin(t * TAU * 3)
	var pb := Rect2((W - 280) / 2.0, play_y + 20 * (1 - p5), 280, 70)
	_rects["play"] = pb
	var sc := 0.95 if _pressed else 1.0
	var pbr := Rect2(pb.get_center() - pb.size * sc / 2.0, pb.size * sc)
	UI.shadow_rrect(self, pbr, 35, UI.with_a(UI.argb(0xFF7C4DFF), (90 + 110 * glow) * p5), 18 + 14 * glow)
	UI.shadow_rrect(self, pbr, 35, Color(0, 0, 0, 0.6 * p5), 8.0, Vector2(0, 5))
	var c0 := UI.argb(0xFFA67CFF)
	var c1 := UI.argb(0xFF6A3BFF)
	c0.a = p5
	c1.a = p5
	UI.grad_rrect_v(self, pbr, 35, c0, c1)
	UI.stroke_rrect(self, pbr, 35, Color(1, 1, 1, 160.0 / 255.0 * p5), 2.0)
	var hp := UI.rrect_pts(Rect2(pbr.position + Vector2(2, 2), Vector2(pbr.size.x - 4, pbr.size.y * 0.48)), 33)
	var hc := PackedColorArray()
	for p in hp:
		hc.append(Color(1, 1, 1, lerpf(90.0 / 255.0, 10.0 / 255.0, clampf((p.y - pbr.position.y) / (pbr.size.y * 0.48), 0, 1)) * p5))
	draw_polygon(hp, hc)
	var lab := L.t("OYNA", "PLAY")
	var lwid := UI.text_width(lab, 28, true) + lab.length() * 4
	var totw := 40.0 + 6.0 + lwid
	var sx := pbr.get_center().x - totw / 2.0
	UI.icon_play(self, Vector2(sx + 20, pbr.get_center().y), 40, Color(1, 1, 1, p5))
	for i in lab.length():
		var ch := lab[i]
		var cwid := UI.text_width(ch, 28, true)
		UI.text_c(self, Rect2(sx + 46 + _adv(lab, i), pbr.position.y, cwid + 2, pbr.size.y), ch, 28, Color(1, 1, 1, p5), true, Color(0, 0, 0, 0.53 * p5))
	# sıfırla
	var p6 := _in(0.7, 1.0)
	var rl := L.t("İlerlemeyi sıfırla", "Reset progress")
	var rw := UI.text_width(rl, 13, false) + 32
	var rr := Rect2((W - rw) / 2.0, H - bot - 10 - 36, rw, 36)
	_rects["reset"] = rr
	UI.text_c(self, rr, rl, 13, Color(1, 1, 1, 0.54 * p6), false)

func _adv(s: String, i: int) -> float:
	var w := 0.0
	for k in i:
		w += UI.text_width(s[k], 28, true) + 4
	return w

func _gear(c: Vector2, s: float, col: Color) -> void:
	draw_arc(c, s * 0.28, 0, TAU, 24, col, s * 0.11, true)
	for i in 8:
		var a := i * TAU / 8.0
		draw_line(c + Vector2(cos(a), sin(a)) * s * 0.33, c + Vector2(cos(a), sin(a)) * s * 0.46, col, s * 0.13, true)

func _logo_line(s: String, size_px: float, c: Vector2, op: float) -> void:
	var fs := int(size_px)
	var f := UI.font(true)
	var w := f.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x + s.length() * 2.0
	var r := Rect2(c.x - w / 2.0, c.y - size_px * 0.6, w, size_px * 1.2)
	var asc := f.get_ascent(fs)
	var desc := f.get_descent(fs)
	var y := r.position.y + (r.size.y + asc - desc) / 2.0
	var x := r.position.x
	for ch in s:
		var cw := f.get_string_size(ch, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		draw_string_outline(f, Vector2(x, y), ch, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, int(size_px * 0.18), Color(0.165, 0.08, 0.4, op))
		var g := Color(1, 1, 1, op).lerp(Color(0.75, 0.64, 1.0, op), 0.45)
		draw_string(f, Vector2(x, y), ch, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, g)
		x += cw + 2.0

func _hero(w: float, h: float, top_off: float, t: float, op: float) -> void:
	var ufo_w := minf(w * 0.31, h * 0.34 * 256.0 / 233.0)
	var ufo_h := ufo_w * 233.0 / 256.0
	var top := top_off + h * 0.10
	var floor_y := top_off + h * 0.97
	var beam_top := top + ufo_h * 0.74
	var beam_h := maxf(10.0, floor_y - beam_top)
	var ah := minf(h * 0.17, w * 0.11)
	var aw := ah * 203.0 / 256.0
	var beam_op := 0.62 + 0.14 * sin(t * TAU * 4)
	for u in 3:
		var nm: String = UFO_NAMES[(Progress.level + u * 5) % UFO_NAMES.size()]
		var cx := w * (0.18 + 0.32 * u)
		var bob := sin(t * TAU * 2 + u * 2.1) * h * 0.012
		var tilt := sin(t * TAU + u * 1.3) * 0.03
		draw_texture_rect(UI.tex("beam"), Rect2(cx - ufo_w * 0.5, beam_top + bob, ufo_w, beam_h), false, Color(1, 1, 1, clampf(beam_op, 0, 1) * op))
		for k in 2:
			var p := fmod(t * 2 + u * 0.31 + k * 0.5, 1.0)
			var wait := 0.28
			var lift := 0.0 if p < wait else pow((p - wait) / (1 - wait), 2.0)
			var y := floor_y - ah - (floor_y - ah - (top + ufo_h * 0.55)) * lift - (maxf(0.0, sin(t * TAU * 6 + k)) * ah * 0.12 if p < wait else 0.0)
			var sc := 1.0 - 0.65 * lift
			var o := (1 - lift) * 10.0 if lift > 0.9 else 1.0
			var dx := (-1 if k == 0 else 1) * aw * 0.8 * (1 - lift)
			draw_set_transform(Vector2(cx + dx, y + ah / 2.0), 0.0, Vector2.ONE * sc)
			UI.draw_contain(self, UI.tex("alien_" + nm), Rect2(Vector2(-aw / 2.0, -ah / 2.0), Vector2(aw, ah)), Color(1, 1, 1, clampf(o, 0, 1) * op))
			draw_set_transform_matrix(Transform2D.IDENTITY)
		draw_set_transform(Vector2(cx, top + bob + ufo_h / 2.0), tilt, Vector2.ONE)
		UI.draw_contain(self, UI.tex("ufo10_" + nm), Rect2(Vector2(-ufo_w / 2.0, -ufo_h / 2.0), Vector2(ufo_w, ufo_h)), Color(1, 1, 1, op))
		draw_set_transform_matrix(Transform2D.IDENTITY)
