extends Node
# Google Play Billing sarmalayıcısı (autoload adı: IAP). Sadece Android.
#
# Kullanılan eklenti: AndroidIAPP (GooglePlayBilling) — Godot 4.3+.
# Eklentiyi addons/ içine kur, Plugins'ten aç, sonra Project Settings > Autoload'a
# GooglePlayBilling.gd dosyasını "Billing" adıyla ekle (IAP'tan SONRA gelsin).
# Eklenti yoksa (editör/PC) bu sınıf sessizce "mağaza yok" modunda çalışır.

signal state_changed                  # fiyatlar / bağlantı / sahiplik değişti -> ekranlar yenilesin
signal purchase_done(product_id: String)
signal purchase_failed(message: String)

# Play Console'daki "Ürün kimlikleri" ile BİREBİR aynı olmalı.
const ID_NO_ADS := "remove_ads"                       # kalıcı (non-consumable)
const ID_COINS := "coins_1000"                        # tüketilebilir
const ID_COINS_BOOST := "coins_1000_boosters_3"       # 1000 coin + her booster'dan 3
const ID_BOOST5 := "boosters_5_each"                  # her booster'dan 5

# consumable: true  -> ödül verilince consume() edilir (tekrar alınabilir)
# consumable: false -> acknowledge() edilir (kalıcı)
const PRODUCTS := {
	ID_NO_ADS:     {"consumable": false, "coins": 0,    "boost": 0, "no_ads": true},
	ID_COINS:      {"consumable": true,  "coins": 1000, "boost": 0, "no_ads": false},
	ID_COINS_BOOST:{"consumable": true,  "coins": 1000, "boost": 3, "no_ads": false},
	ID_BOOST5:     {"consumable": true,  "coins": 0,    "boost": 5, "no_ads": false},
}
# Mağazada görünen sıra
const ORDER := [ID_NO_ADS, ID_COINS_BOOST, ID_BOOST5, ID_COINS]

const STATE_PURCHASED := 1            # Play Billing PurchaseState.PURCHASED
const STATE_PENDING := 2
const RESP_USER_CANCELED := 1         # BillingResponseCode.USER_CANCELED

var billing: Node = null              # eklenti düğümü (yoksa null)
var connected: bool = false
var prices: Dictionary = {}           # product_id -> "₺49,99"
var busy: bool = false                # satın alma akışı sürerken true

func available() -> bool:
	return billing != null or _editor_fake()

# Editörde (sadece editörde, export'ta DEĞİL) arayüzü denemek için sahte satın alma.
func _editor_fake() -> bool:
	return OS.has_feature("editor") and OS.get_name() != "Android"

func _ready() -> void:
	if OS.get_name() != "Android":
		return
	# Billing autoload'u IAP'tan sonra eklendiği için bir kare bekle.
	call_deferred("_attach")

func _attach() -> void:
	billing = get_node_or_null("/root/Billing")
	if billing == null:
		push_warning("IAP: 'Billing' autoload bulunamadı. Eklentiyi kurup Autoload'a 'Billing' adıyla ekle.")
		state_changed.emit()
		return
	billing.iap_connected.connect(_on_connected)
	billing.iap_disconnected.connect(_on_disconnected)
	billing.iap_product_details_received.connect(_on_details)
	billing.iap_purchases_updated.connect(_on_purchases)
	billing.iap_purchases_queried.connect(_on_purchases)
	billing.iap_error_occurred.connect(_on_error)
	# Eklenti IAP'tan önce bağlanmış olabilir
	if billing.has_method("is_ready") and billing.call("is_ready"):
		_on_connected()

# ------------------------------------------------------------------ bağlantı
func _on_connected() -> void:
	connected = true
	var ids: Array[String] = []
	for id in ORDER:
		ids.append(id)
	billing.query_details(ids, "inapp")
	restore()          # açılışta sahip olunanları kontrol et (kalıcı ürün + bekleyen satın alma)
	state_changed.emit()

func _on_disconnected() -> void:
	connected = false
	state_changed.emit()

# "Satın alımları geri yükle" butonu da bunu çağırır.
func restore() -> void:
	if billing != null and connected:
		billing.query_purchases("inapp")

# ------------------------------------------------------------------ fiyatlar
func _on_details(products: Array, unfetched: Array, _type: String) -> void:
	for p in products:
		var id := str(p.get("product_id", ""))
		var price := _find_price(p)
		if id != "" and price != "":
			prices[id] = price
	for u in unfetched:
		push_warning("IAP: ürün alınamadı (Play Console'da tanımlı + aktif mi?): %s" % str(u))
	state_changed.emit()

# Eklentinin sözlük yapısı sürüme göre değişebiliyor; "formatted_price" anahtarını derinlemesine ara.
func _find_price(v) -> String:
	if typeof(v) == TYPE_DICTIONARY:
		if v.has("formatted_price"):
			return str(v["formatted_price"])
		for k in v:
			var r := _find_price(v[k])
			if r != "":
				return r
	elif typeof(v) == TYPE_ARRAY:
		for e in v:
			var r := _find_price(e)
			if r != "":
				return r
	return ""

func price_of(id: String) -> String:
	return prices.get(id, "")

# ------------------------------------------------------------------ satın alma
func buy(id: String) -> void:
	if busy:
		return
	if _editor_fake():
		_grant(id)
		purchase_done.emit(id)
		return
	if billing == null or not connected:
		purchase_failed.emit(L.t("Mağazaya bağlanılamadı. Biraz sonra tekrar dene.", "Could not reach the store. Try again later."))
		return
	if id == ID_NO_ADS and Progress.no_ads:
		return
	busy = true
	state_changed.emit()
	billing.buy_inapp(id)

func _on_purchases(purchases: Array) -> void:
	await _handle_purchases(purchases)

func _handle_purchases(purchases: Array) -> void:
	# Kayıt yüklenmeden ödül verme (ilk karede gelebilir)
	while not Progress.loaded:
		await get_tree().process_frame
	for pu in purchases:
		var state := int(pu.get("purchase_state", 0))
		var token := str(pu.get("purchase_token", ""))
		var prods: Array = pu.get("products", [])
		if token == "" or prods.is_empty():
			continue
		var id := str(prods[0])
		if state == STATE_PENDING:
			purchase_failed.emit(L.t("Ödeme beklemede. Onaylanınca otomatik eklenecek.", "Payment is pending. It will be added once approved."))
			continue
		if state != STATE_PURCHASED or not PRODUCTS.has(id):
			continue
		var def: Dictionary = PRODUCTS[id]
		if def["consumable"]:
			# 1) ödülü KAYDEDİLEREK ver (token daha önce işlendiyse tekrar verme)
			if not Progress.has_token(token):
				_grant(id)
				Progress.add_token(token)
				Progress.save()
				purchase_done.emit(id)
			# 2) sonra consume et (başarısız olursa bir sonraki açılışta tekrar denenir)
			billing.consume(token)
		else:
			if not Progress.no_ads:
				_grant(id)
				Progress.save()
				purchase_done.emit(id)
			if not bool(pu.get("is_acknowledged", false)):
				billing.acknowledge(token)   # 3 gün içinde şart, yoksa Google iade eder
	busy = false
	state_changed.emit()

func _grant(id: String) -> void:
	var def: Dictionary = PRODUCTS.get(id, {})
	if def.is_empty():
		return
	Progress.coins += int(def["coins"])
	if int(def["boost"]) > 0:
		Progress.add_boosters(int(def["boost"]))
	if def["no_ads"]:
		Progress.no_ads = true
	Progress.save()

func _on_error(fun_name: String, response: Dictionary) -> void:
	busy = false
	state_changed.emit()
	push_warning("IAP hata (%s): %s" % [fun_name, str(response)])
	var code := int(response.get("response_code", -1))
	if code == RESP_USER_CANCELED:
		return   # kullanıcı vazgeçti, uyarı gösterme
	if fun_name.contains("consume") or fun_name.contains("acknowledge") or fun_name.contains("query"):
		return   # arka plan işlemleri; kullanıcıya gösterme, bir sonraki açılışta tekrar denenir
	purchase_failed.emit(L.t("Satın alma tamamlanamadı.", "Purchase could not be completed."))
