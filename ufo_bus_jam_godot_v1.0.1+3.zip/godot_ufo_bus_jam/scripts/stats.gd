extends Node
# stats.dart karşılığı

const I_START := 0
const I_WIN := 1
const I_LOSE_MOVES := 2
const I_LOSE_SLOTS := 3
const I_AD_OFFER := 4
const I_AD_WATCH := 5
const I_BOOSTER := 6
const N := 7

var levels: Dictionary = {} # int -> Array[int]
var ads: Dictionary = {}    # String -> [teklif, izlendi]
var coin_buys: int = 0
var current_level: int = 0
const KEY := "stats_v1"

func _lv(n: int) -> Array:
	if not levels.has(n):
		var a: Array = []
		for i in N:
			a.append(0)
		levels[n] = a
	return levels[n]

func _ad(tag: String) -> Array:
	if not ads.has(tag):
		ads[tag] = [0, 0]
	return ads[tag]

func load_all() -> void:
	var raw = Store.get_v(KEY, null)
	if raw == null:
		return
	var m = JSON.parse_string(str(raw))
	if typeof(m) != TYPE_DICTIONARY:
		return
	levels.clear()
	ads.clear()
	var lv = m.get("levels", {})
	for k in lv:
		var l: Array = []
		for i in N:
			l.append(0)
		var src: Array = lv[k]
		for i in range(mini(N, src.size())):
			l[i] = int(src[i])
		levels[int(k)] = l
	var ad = m.get("ads", {})
	for k in ad:
		var src: Array = ad[k]
		ads[str(k)] = [int(src[0]) if src.size() > 0 else 0, int(src[1]) if src.size() > 1 else 0]
	coin_buys = int(m.get("coinBuys", 0))

func save() -> void:
	Store.set_v(KEY, to_json())
	Store.save()

func to_json() -> String:
	var lv := {}
	for k in levels:
		lv[str(k)] = levels[k]
	return JSON.stringify({"v": 1, "levels": lv, "ads": ads, "coinBuys": coin_buys})

func reset() -> void:
	levels.clear()
	ads.clear()
	coin_buys = 0
	save()

func level_start(n: int) -> void:
	current_level = n
	_lv(n)[I_START] += 1
	save()

func level_win(n: int) -> void:
	_lv(n)[I_WIN] += 1
	save()

func level_lose(n: int, out_of_moves: bool) -> void:
	_lv(n)[I_LOSE_MOVES if out_of_moves else I_LOSE_SLOTS] += 1
	save()

func ad_offered(tag: String) -> void:
	_ad(tag)[0] += 1
	if current_level > 0:
		_lv(current_level)[I_AD_OFFER] += 1
	save()

func ad_watched(tag: String) -> void:
	_ad(tag)[1] += 1
	if current_level > 0:
		_lv(current_level)[I_AD_WATCH] += 1
	save()

func booster_used() -> void:
	if current_level > 0:
		_lv(current_level)[I_BOOSTER] += 1
	save()

func coin_buy() -> void:
	coin_buys += 1
	save()

func _ad_name(tag: String) -> String:
	match tag:
		"revive_moves": return L.t("+5 hamle (kayıpta)", "+5 moves (on loss)")
		"revive_slots": return L.t("+2 park yeri (kayıpta)", "+2 slots (on loss)")
		"slot_unlock": return L.t("Kilitli park yeri", "Locked parking slot")
		"booster_ad": return L.t("Booster (+1)", "Booster (+1)")
		"double_coins": return L.t("Coin x2", "Coin x2")
	return tag

func report() -> String:
	var starts := 0
	var wins := 0
	var losses := 0
	var boosters := 0
	for l in levels.values():
		starts += l[I_START]
		wins += l[I_WIN]
		losses += l[I_LOSE_MOVES] + l[I_LOSE_SLOTS]
		boosters += l[I_BOOSTER]
	if starts == 0:
		return L.t("Henüz veri yok. Birkaç seviye oyna, sonra tekrar bak.", "No data yet. Play a few levels, then check again.")
	var b := PackedStringArray()
	var loss_rate := 0
	if wins + losses != 0:
		loss_rate = int(round(100.0 * losses / (wins + losses)))
	b.append(L.t("Deneme: %d   Kazanma: %d   Kayıp: %d (%%%d)" % [starts, wins, losses, loss_rate],
		"Attempts: %d   Wins: %d   Losses: %d (%d%%)" % [starts, wins, losses, loss_rate]))
	b.append(L.t("Booster kullanımı: %d   Coinle alınan: %d" % [boosters, coin_buys], "Boosters used: %d   Bought with coins: %d" % [boosters, coin_buys]))
	b.append("")
	b.append(L.t("REKLAM (teklif → izlenen)", "ADS (offered → watched)"))
	if ads.is_empty():
		b.append(L.t("Henüz reklam teklifi yok.", "No ad offers yet."))
	else:
		var tags := ads.keys()
		tags.sort()
		for t in tags:
			var o: int = ads[t][0]
			var w: int = ads[t][1]
			var pct := 0 if o == 0 else int(round(100.0 * w / o))
			b.append("%s: %d → %d (%%%d)" % [_ad_name(t), o, w, pct])
	b.append("")
	b.append(L.t("EN ÇOK KAYBEDİLEN SEVİYELER", "MOST LOST LEVELS"))
	var rows: Array = []
	for k in levels:
		var v: Array = levels[k]
		if v[I_LOSE_MOVES] + v[I_LOSE_SLOTS] > 0:
			rows.append(k)
	rows.sort_custom(func(a, c):
		var la: int = levels[a][I_LOSE_MOVES] + levels[a][I_LOSE_SLOTS]
		var lc: int = levels[c][I_LOSE_MOVES] + levels[c][I_LOSE_SLOTS]
		if lc != la:
			return la > lc
		return a < c)
	if rows.is_empty():
		b.append(L.t("Henüz kayıp yok.", "No losses yet."))
	for i in range(mini(10, rows.size())):
		var k = rows[i]
		var v: Array = levels[k]
		var lost: int = v[I_LOSE_MOVES] + v[I_LOSE_SLOTS]
		b.append(L.t("Seviye %d: %d kayıp / %d deneme, reklam %d/%d" % [k, lost, v[I_START], v[I_AD_WATCH], v[I_AD_OFFER]],
			"Level %d: %d lost / %d tries, ads %d/%d" % [k, lost, v[I_START], v[I_AD_WATCH], v[I_AD_OFFER]]))
	return "\n".join(b)
