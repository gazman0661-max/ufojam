class_name Geo
extends RefCounted
# geometry.dart karşılığı. Çarpışma yoksa -1.0 döner (null yerine).

const SA := [1.0, 1.0, -1.0, -1.0]
const SB := [1.0, -1.0, -1.0, 1.0]

static func sweep_hit(m, o) -> float:
	var fx: float = m.dir_x()
	var fy: float = m.dir_y()
	var sx: float = cos(m.angle)
	var sy: float = sin(m.angle)
	var hl: float = Models.ufo_length(m.seats) / 2.0
	var hw: float = Models.ufo_width(m.seats) / 2.0 * Models.STRIP_FACTOR
	var ohl: float = Models.ufo_length(o.seats) / 2.0 * Models.BODY_SHRINK
	var ohw: float = Models.ufo_width(o.seats) / 2.0 * Models.BODY_SHRINK
	var ofx: float = o.dir_x()
	var ofy: float = o.dir_y()
	var osx: float = cos(o.angle)
	var osy: float = sin(o.angle)

	var us := [0.0, 0.0, 0.0, 0.0]
	var vs := [0.0, 0.0, 0.0, 0.0]
	for i in 4:
		var px: float = o.x + ofx * ohl * SA[i] + osx * ohw * SB[i]
		var py: float = o.y + ofy * ohl * SA[i] + osy * ohw * SB[i]
		var dx: float = px - m.x
		var dy: float = py - m.y
		us[i] = dx * fx + dy * fy - hl
		vs[i] = dx * sx + dy * sy

	var cu: Array = []
	var cv: Array = []
	for i in 4:
		var j: int = (i + 1) % 4
		var in_i: bool = us[i] >= 0
		var in_j: bool = us[j] >= 0
		if in_i:
			cu.append(us[i])
			cv.append(vs[i])
		if in_i != in_j:
			var t: float = us[i] / (us[i] - us[j])
			cu.append(0.0)
			cv.append(vs[i] + (vs[j] - vs[i]) * t)
	if cu.is_empty():
		return -1.0
	var min_v: float = cv[0]
	var max_v: float = cv[0]
	var min_u: float = cu[0]
	for i in range(1, cu.size()):
		min_v = minf(min_v, cv[i])
		max_v = maxf(max_v, cv[i])
		min_u = minf(min_u, cu[i])
	if max_v <= -hw + 1e-9 or min_v >= hw - 1e-9:
		return -1.0
	return maxf(0.0, min_u)
