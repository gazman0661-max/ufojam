extends PanelUI.PanelScreen
# Oyunlarımız ve Uygulamalarımız: Google Play kartları listesi.

# [başlık, ikon (assets/img/ içinde), Google Play linki]
const GAMES := [
	["Anne Terliği:Koridor", "game_anne_terligi", "https://play.google.com/store/apps/details?id=com.astrofelyx.pro"],
	["Worlds Merge:Puzzle & Town", "game_worlds_merge", "https://play.google.com/store/apps/details?id=com.sitora.ai"],
]

func _init() -> void:
	super(L.t("Oyunlarımız", "Our Games"))

func _ready() -> void:
	super._ready()
	for g in GAMES:
		var card := GameCard.new(g[0], g[1], g[2])
		card.pressed.connect(_open.bind(g[2]))
		add_item(card)
		add_item(PanelUI.PanelGap.new(14))

func _open(url: String) -> void:
	Audio.play(Audio.Sfx.CLICK)
	if not Legal.open_url(url):
		DisplayServer.clipboard_set(url)

# ---------------------------------------------------------------- Oyun kartı
class GameCard extends Control:
	signal pressed
	var game_name := ""
	var icon_name := ""
	var _down := false

	func _init(p_name: String, p_icon: String, _p_url: String) -> void:
		game_name = p_name
		icon_name = p_icon
		custom_minimum_size = Vector2(0, 112)
		mouse_filter = Control.MOUSE_FILTER_PASS

	func _gui_input(e: InputEvent) -> void:
		if (e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT) or e is InputEventScreenTouch:
			if e.pressed:
				_down = true
			else:
				if _down and Rect2(Vector2.ZERO, size).has_point(e.position):
					pressed.emit()
				_down = false
			queue_redraw()

	func _draw() -> void:
		var sc := 0.98 if _down else 1.0
		var full := Rect2(Vector2.ZERO, Vector2(size.x, size.y - 4.0))
		var r := Rect2(full.get_center() - full.size * sc / 2.0, full.size * sc)
		UI.fill_rrect(self, Rect2(r.position + Vector2(0, 4), r.size), 26, Color(0, 0, 0, 0.35))
		UI.grad_rrect_v(self, r, 26, UI.argb(0xFF3A2380), UI.argb(0xFF281660))
		UI.stroke_rrect(self, r, 26, Color(1, 1, 1, 0.45), 2.0)
		# ikon (yuvarlatılmış köşe)
		var ic := Rect2(r.position + Vector2(14, (r.size.y - 78) / 2.0), Vector2(78, 78))
		var t := UI.tex(icon_name)
		if t != null:
			var pts := UI.rrect_pts(ic, 18)
			var uvs := PackedVector2Array()
			var cols := PackedColorArray()
			for p in pts:
				uvs.append((p - ic.position) / ic.size)
				cols.append(Color.WHITE)
			draw_polygon(pts, cols, uvs, t)
		UI.stroke_rrect(self, ic, 18, Color(1, 1, 1, 0.55), 1.5)
		# metinler
		var tx := ic.end.x + 14.0
		var avail := r.end.x - 44.0 - tx
		var lines: Array = UI.wrap(game_name, 18.0, avail, true)
		var title_h := lines.size() * 22.0
		var total := title_h + 6.0 + 20.0
		var y := r.position.y + (r.size.y - total) / 2.0
		for ln in lines:
			UI.text_tl(self, Vector2(tx, y), ln, 18.0, Color.WHITE, true)
			y += 22.0
		y += 6.0
		# "Google Play'de aç" rozeti
		var tri := PackedVector2Array([Vector2(tx, y + 2), Vector2(tx, y + 18), Vector2(tx + 15, y + 10)])
		draw_colored_polygon(tri, UI.argb(0xFF7EE38D))
		UI.text_tl(self, Vector2(tx + 22, y), L.t("Google Play'de aç", "Open on Google Play"), 15.0, UI.argb(0xFF7EE38D), true)
		# ok
		var c := Vector2(r.end.x - 24, r.get_center().y)
		draw_polyline(PackedVector2Array([c + Vector2(-5, -11), c + Vector2(5, 0), c + Vector2(-5, 11)]), Color(1, 1, 1, 0.85), 3.5, true)
