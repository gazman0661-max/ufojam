extends PanelUI.PanelScreen
# InfoScreen: [başlık, metin, başlık, metin...] listesini gösterir.

var sections: Array = []

func _init(p_title: String = "", p_sections: Array = []) -> void:
	super(p_title)
	sections = p_sections

func _ready() -> void:
	super._ready()
	var i := 0
	while i + 1 < sections.size():
		add_item(PanelUI.PanelText.new(sections[i], true))
		add_item(PanelUI.PanelText.new(sections[i + 1], false))
		i += 2
