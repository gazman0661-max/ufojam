class_name GamePopup
extends Control
# game_popup.dart karşılığı: neon çerçeveli uzay paneli, üstte taşan rozet, parlak 3B düğmeler.
# Kullanım:  var p = GamePopup.show_popup(parent, {...}); var v = await p.closed

signal closed(value)

enum Kind { PRIMARY, REWARD, GOLD, GHOST, DANGER }

# Düğme sözlüğü: {label, icon:"video|play|none", kind, value, enabled, leading_tex, on_tap:Callable (kapatmaz)}
var opts: Dictionary = {}
var _btn_rects: Array = []
var _down := -1
var _t0 := 0
var _anim := 0.0
var _card := Rect2()
var _lines: Array = []
var _closed_flag := false
var _body_draw: Callable = Callable()

static func show_popup(parent: Node, o: Dictionary) -> GamePopup:
	var p := GamePopup.new()
	p.opts = o
	p.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	parent.add_child(p)
	return p

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	z_index = 100
	_t0 = Time.get_ticks_msec()
	set_process(true)

func _process(_d: float) -> void:
	_anim = clampf((Time.get_ticks_msec() - _t0) / 240.0, 0.0, 1.0)
	queue_redraw()

func close(v = null) -> void:
	if _closed_flag:
		return
	_closed_flag = true
	closed.emit(v)
	queue_free()

func _accent() -> Color:
	return opts.get("accent", UI.argb(0xFF7C4DFF))

func _fill(k: int) -> Array:
	match k:
		Kind.PRIMARY: return [UI.argb(0xFF9B6BFF), UI.argb(0xFF5E4BFF)]
		Kind.REWARD: return [UI.argb(0xFF45E08F), UI.argb(0xFF12A863)]
		Kind.GOLD: return [UI.argb(0xFFFFC53D), UI.argb(0xFFFF8A00)]
		Kind.DANGER: return [UI.argb(0xFFFF6B6B), UI.argb(0xFFE02D3C)]
	return [UI.argb(0x22FFFFFF), UI.argb(0x22FFFFFF)]

func _edge(k: int) -> Color:
	match k:
		Kind.PRIMARY: return UI.argb(0xFF2F1C9A)
		Kind.REWARD: return UI.argb(0xFF0A6B42)
		Kind.GOLD: return UI.argb(0xFFB35A00)
		Kind.DANGER: return UI.argb(0xFF8F1521)
	return Color(0, 0, 0, 0)

func _buttons() -> Array:
	return opts.get("buttons", [])

func _layout() -> void:
	var W := size.x
	var H := size.y
	var cw := minf(360.0, W - 44.0)
	var title: String = opts.get("title", "")
	var message = opts.get("message", null)
	var body_h: float = float(opts.get("body_h", 0.0))
	var btns := _buttons()
	var stacked: bool = bool(opts.get("stacked", false))
	_lines = []
	var h := 48.0
	h += 28.0 # başlık
	h += 12.0 + 2.0
	if message != null:
		_lines = UI.wrap(message, 16, cw - 40.0, false)
		h += 14.0 + _lines.size() * 22.4
	if body_h > 0.0:
		h += 14.0 + body_h
	h += 20.0
	var rows := 1 if (btns.size() == 2 and not stacked) else btns.size()
	h += rows * 54.0 + (rows - 1) * 10.0
	h += 20.0
	var total := h + 39.0
	_card = Rect2((W - cw) / 2.0, (H - total) / 2.0 + 39.0, cw, h)

func _gui_input(e: InputEvent) -> void:
	var pressed := false
	var released := false
	var pos := Vector2.ZERO
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
		pos = e.position
		pressed = e.pressed
		released = not e.pressed
	elif e is InputEventScreenTouch:
		pos = e.position
		pressed = e.pressed
		released = not e.pressed
	else:
		accept_event()
		return
	accept_event()
	if pressed:
		_down = _hit(pos)
	elif released:
		var h := _hit(pos)
		if h >= 0 and h == _down:
			_tap(h)
		elif h < 0 and _down < 0 and bool(opts.get("dismissible", false)) and not _card.has_point(pos):
			close(null)
		_down = -1

func _hit(p: Vector2) -> int:
	for i in _btn_rects.size():
		if (_btn_rects[i] as Rect2).has_point(p):
			return i
	return -1

func _tap(i: int) -> void:
	var b: Dictionary = _buttons()[i]
	if not bool(b.get("enabled", true)):
		return
	Audio.play(Audio.Sfx.CLICK)
	if b.has("on_tap"):
		var cb: Callable = b["on_tap"]
		cb.call(self)
		return
	close(b.get("value", null))

func _draw() -> void:
	_layout()
	var f := _anim
	var ease_back := _ease_out_back(f)
	var scale_v := lerpf(0.82, 1.0, ease_back)
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 175.0 / 255.0 * f))
	var ctr := _card.get_center() + Vector2(0, -19.5)
	draw_set_transform_matrix(Transform2D(0.0, Vector2(scale_v, scale_v), 0.0, ctr - ctr * scale_v))
	var accent := _accent()
	var light := accent.lerp(Color.WHITE, 0.45)
	var cr := _card
	# dış gölge + degrade çerçeve
	UI.shadow_rrect(self, cr, 30, UI.with_a(accent, 120), 26.0)
	UI.shadow_rrect(self, cr, 30, Color(0, 0, 0, 0.6), 14.0, Vector2(0, 10))
	UI.grad_rrect_d(self, cr, 30, UI.argb(0xFF6FE7FF), accent, UI.argb(0xFFB388FF))
	var inner := Rect2(cr.position + Vector2(2.5, 2.5), cr.size - Vector2(5, 5))
	UI.grad_rrect_v(self, inner, 27.5, UI.argb(0xFF2B1670), UI.argb(0xFF140B3A))
	# rozetin altından yayılan ışık
	var gl := UI.radial_tex()
	draw_texture_rect(gl, Rect2(cr.get_center().x - cr.size.x * 0.75, cr.position.y - cr.size.x * 0.75, cr.size.x * 1.5, cr.size.x * 1.5), false, UI.with_a(accent, 95))
	# sabit tohumlu yıldızlar
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	for i in 30:
		var sx := rng.randf() * inner.size.x
		var sy := rng.randf() * inner.size.y
		var sa := 40 + rng.randi() % 110
		var sr := 0.6 + rng.randf() * 1.1
		draw_circle(inner.position + Vector2(sx, sy), sr, Color(1, 1, 1, sa / 255.0))
	# başlık
	var y := cr.position.y + 48.0
	var title: String = opts.get("title", "")
	UI.text_c(self, Rect2(cr.position.x, y, cr.size.x, 28), title, 24, Color.WHITE, true, UI.argb(0xFF2A1466))
	y += 28.0 + 10.0
	# ayraç
	var lw := cr.size.x - 72.0
	for i in 20:
		var t0 := float(i) / 20.0
		var a := sin(t0 * PI)
		draw_line(Vector2(cr.position.x + 36 + lw * t0, y), Vector2(cr.position.x + 36 + lw * (t0 + 0.05), y), UI.with_a(light, 255.0 * a), 2.0)
	y += 2.0
	if opts.get("message", null) != null:
		y += 14.0
		for ln in _lines:
			UI.text_c(self, Rect2(cr.position.x + 20, y, cr.size.x - 40, 22.4), ln, 16, Color(1, 1, 1, 220.0 / 255.0), false)
			y += 22.4
	var body_h: float = float(opts.get("body_h", 0.0))
	if body_h > 0.0:
		y += 14.0
		if opts.has("body_draw"):
			var bd: Callable = opts["body_draw"]
			bd.call(self, Rect2(cr.position.x + 20, y, cr.size.x - 40, body_h))
		y += body_h
	y += 20.0
	# düğmeler
	_btn_rects = []
	var btns := _buttons()
	var stacked: bool = bool(opts.get("stacked", false))
	var bx := cr.position.x + 20.0
	var bw := cr.size.x - 40.0
	if btns.size() == 2 and not stacked:
		var w2 := (bw - 10.0) / 2.0
		for i in 2:
			var r := Rect2(bx + i * (w2 + 10.0), y, w2, 54)
			_btn_rects.append(r)
			_draw_btn(btns[i], r, i)
	else:
		for i in btns.size():
			var r := Rect2(bx, y, bw, 54)
			_btn_rects.append(r)
			_draw_btn(btns[i], r, i)
			y += 64.0
	# rozet
	_draw_badge(Vector2(cr.get_center().x, cr.position.y - 39.0 + 39.0), accent, light)
	draw_set_transform_matrix(Transform2D.IDENTITY)

func _ease_out_back(t: float) -> float:
	var c1 := 1.70158
	var c3 := c1 + 1.0
	return 1.0 + c3 * pow(t - 1.0, 3.0) + c1 * pow(t - 1.0, 2.0)

func _draw_badge(c: Vector2, accent: Color, light: Color) -> void:
	c = Vector2(c.x, _card.position.y)
	UI.shadow_rrect(self, Rect2(c - Vector2(39, 39), Vector2(78, 78)), 39, UI.with_a(accent, 200), 22.0, Vector2.ZERO, 2.0)
	draw_circle(c + Vector2(0, 4), 39, Color(0, 0, 0, 0.35))
	draw_circle(c, 39, accent.lerp(Color.BLACK, 0.45))
	draw_circle(c, 33, accent)
	draw_circle(c + Vector2(-8, -10), 22, UI.with_a(light, 150))
	draw_arc(c, 38.5, 0.0, TAU, 48, Color.WHITE, 3.0, true)
	var emoji = opts.get("emoji", null)
	if opts.has("badge_tex") and opts["badge_tex"] != null:
		draw_texture_rect(opts["badge_tex"], Rect2(c - Vector2(26, 26), Vector2(52, 52)), false)
	elif emoji != null:
		UI.text_c(self, Rect2(c - Vector2(39, 39), Vector2(78, 78)), emoji, 36, Color.WHITE, false)
	else:
		var ic: String = opts.get("icon", "rocket")
		if ic == "video":
			UI.icon_video(self, c, 38, Color.WHITE)
		else:
			UI.text_c(self, Rect2(c - Vector2(39, 39), Vector2(78, 78)), "🚀", 34, Color.WHITE, false)

func _draw_btn(b: Dictionary, r: Rect2, i: int) -> void:
	var kind: int = b.get("kind", Kind.PRIMARY)
	var ghost: bool = kind == Kind.GHOST
	var on: bool = bool(b.get("enabled", true))
	var fill: Array = _fill(kind) if on else [UI.argb(0xFF5A5575), UI.argb(0xFF3F3A58)]
	var edge: Color = _edge(kind) if on else UI.argb(0xFF2A2640)
	var txt: Color = Color.WHITE if on else Color(1, 1, 1, 0.54)
	var sc := 0.96 if _down == i else 1.0
	var c := r.get_center()
	var rr := Rect2(c - r.size * sc / 2.0, r.size * sc)
	if not ghost:
		UI.fill_rrect(self, Rect2(rr.position + Vector2(0, 4), rr.size), 27, edge)
		if on:
			UI.shadow_rrect(self, rr, 27, UI.with_a(fill[1], 90), 12.0, Vector2(0, 6))
	UI.grad_rrect_v(self, rr, 27, fill[0], fill[1])
	if ghost:
		UI.stroke_rrect(self, rr, 27, Color(1, 1, 1, 90.0 / 255.0), 1.5)
	elif on:
		# üst parlama
		var hl := Rect2(rr.position, Vector2(rr.size.x, 24))
		var pts := UI.rrect_pts(Rect2(rr.position, Vector2(rr.size.x, 27)), 27)
		var cols := PackedColorArray()
		for p in pts:
			if p.y > rr.position.y + 24.0:
				cols.append(Color(1, 1, 1, 0))
			else:
				cols.append(Color(1, 1, 1, lerpf(95.0 / 255.0, 0.0, (p.y - rr.position.y) / 24.0)))
		draw_polygon(pts, cols)
	var label: String = b.get("label", "")
	var fs := 16.0 if ghost else 17.0
	var tw := UI.text_width(label, fs, true)
	var ic: String = b.get("icon", "none")
	var lead = b.get("leading_tex", null)
	var total := tw
	if lead != null:
		total += 22 + 8
	elif ic != "none":
		total += 22 + 8
	var sx := c.x - total / 2.0
	if lead != null:
		draw_texture_rect(lead, Rect2(sx, c.y - 11, 22, 22), false)
		sx += 30
	elif ic == "video":
		UI.icon_video(self, Vector2(sx + 11, c.y), 22, txt)
		sx += 30
	elif ic == "play":
		UI.icon_play(self, Vector2(sx + 11, c.y), 22, txt)
		sx += 30
	elif ic == "replay":
		UI.icon_refresh(self, Vector2(sx + 11, c.y), 24, txt)
		sx += 30
	UI.text_c(self, Rect2(sx, r.position.y, tw + 2, r.size.y), label, fs, txt, true, Color(0, 0, 0, 0.53) if (on and not ghost) else Color(0, 0, 0, 0))
