# Play Billing + GitHub derleme

## Repo düzeni
Repo köküne sadece şunları koy:
- `ufo_bus_jam_godot_v1.0.1+2.zip` (bu zip; adı değişebilir)
- `.github/workflows/build.yml` (ayrı verilen build dosyası)

Zip'i yükleyince/güncelleyince workflow kendi kendine çalışır (zip'i açar, derler).
Birden fazla zip varsa en son commit'lenen kullanılır.

## Bir kerelik ayar (GitHub > Settings > Secrets and variables > Actions > Variables)
- `ANDROID_PACKAGE` = Play Console'daki paket adı (örn. com.firma.ufobusjam)
Secret gerekmez. İmzayı kendi bilgisayarında atıyorsun.

## Çıktı (Actions > çalışma > Artifacts > `ufo-bus-jam-android`)
- `ufo_bus_jam-debug.apk` (debug imzalı)
- `ufo_bus_jam-release-unsigned.aab` (imzasız release; imzayı sen atacaksın)

## Sürüm
Şu an **1.0.1+2** (ad 1.0.1, version code 2).
Değiştirmek için zip içinde: `ci/export_presets.android.cfg` (version/name, version/code) ve `scripts/settings.gd` (APP_VERSION).
Her yeni Play yüklemesinde version code'u artır.

## Play Console > Monetize > In-app products (ID'ler birebir)
| ID | Tür | İçerik |
|---|---|---|
| remove_ads | Kalıcı | Sadece bölüm geçişi reklamlarını kaldırır |
| coins_1000 | Tüketilebilir | 1000 coin |
| coins_1000_boosters_3 | Tüketilebilir | 1000 coin + her booster'dan 3 |
| boosters_5_each | Tüketilebilir | Her booster'dan 5 |

## Test
- Editörde (PC) mağaza sahte satın almayla açılır, sadece arayüz içindir.
- Gerçek test: Internal testing track'e yüklenen AAB + lisans test hesabı.
- Logcat: `adb logcat | grep AndroidIAPP`

## Reklam eklerken
Geçiş reklamı öncesi: `if not Progress.no_ads: ...` (ödüllü reklamlar no_ads ile kapanmaz)
