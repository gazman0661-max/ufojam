import re, json, sys
L = '/home/claude/src/ufo_bus_jam/lib/'
def read(p): return open(L+p, encoding='utf-8').read()

def map_body(src, name):
    m = re.search(r'const Map<int, [^>]*>*\s*' + name + r'\s*=\s*(?:<int,\s*[A-Za-z<>]+>)?\{', src)
    if not m:
        m = re.search(name + r'\s*=\s*\{', src)
    i = m.end(); depth = 1; j = i
    instr = None
    while depth:
        c = src[j]
        if instr:
            if c == '\\': j += 1
            elif c == instr: instr = None
        else:
            if c in "'\"": instr = c
            elif c == '{': depth += 1
            elif c == '}': depth -= 1
        j += 1
    return src[i:j-1]

def parse_int_map(body, conv):
    out = {}
    for m in re.finditer(r'^\s*(\d+):\s*(\[.*?\]),?\s*$', body, re.M | re.S):
        pass
    # line based
    for line in body.split('\n'):
        mm = re.match(r'\s*(\d+):\s*(.*?),?\s*$', line)
        if mm:
            out[int(mm.group(1))] = conv(mm.group(2))
    return out

def intlist(s): return json.loads(s)
def strlist(s):
    # ['a', 'b', 'c']
    return re.findall(r"'((?:[^'\\]|\\.)*)'", s)
def dlist(s): return json.loads(s)

data = {}
ls = read('game/level_data.dart')
data['stages'] = {str(k): v for k, v in parse_int_map(map_body(ls, 'kStages'), strlist).items()}
data['stage_order'] = json.loads(re.search(r'kStageOrder\s*=\s*(\[.*?\]);', ls, re.S).group(1))
se = read('game/stage_extras.dart')
data['layers'] = {str(k): v for k, v in parse_int_map(map_body(se, 'kStageLayers'), intlist).items()}
data['arms'] = {str(k): v for k, v in parse_int_map(map_body(se, 'kStageArms'), strlist).items()}
data['arm_cut'] = {str(k): v for k, v in parse_int_map(map_body(se, 'kStageArmCut'), intlist).items()}
data['rotors'] = {str(k): v for k, v in parse_int_map(map_body(se, 'kStageRotors'), intlist).items()}
data['faulty'] = {str(k): v for k, v in parse_int_map(map_body(se, 'kStageFaulty'), intlist).items()}
data['belts'] = {str(k): v for k, v in parse_int_map(map_body(se, 'kStageBelts'), intlist).items()}
rd = read('game/ring_data.dart')
data['ring_data'] = {str(k): v for k, v in parse_int_map(map_body(rd, 'kRingData'), dlist).items()}
data['story'] = json.loads(re.search(r'<int>\[(.*?)\];', read('game/story_order.dart'), re.S).group(0)[5:-1] if False else '[' + re.search(r'<int>\[(.*?)\];', read('game/story_order.dart'), re.S).group(1) + ']')
data['early'] = json.loads('[' + re.search(r'<int>\[(.*?)\];', read('game/early_order.dart'), re.S).group(1) + ']')
data['late'] = json.loads('[' + re.search(r'<int>\[(.*?)\];', read('game/late_order.dart'), re.S).group(1) + ']')

rs = read('ui/ring_shapes.dart')
shapes = {}
for m in re.finditer(r'const RingShape (\w+) = RingShape\((.*?)\n\);', rs, re.S):
    b = m.group(2)
    def f(k):
        return re.search(r'\b' + k + r':\s*([^,\n]+),', b).group(1).strip()
    def lst(k):
        return json.loads(re.search(r'\b' + k + r':\s*(\[\[.*?\]\]),', b, re.S).group(1))
    shapes[m.group(1)] = dict(
        name=f('name').strip("'"), asset=f('asset').strip("'").replace('assets/', 'res://assets/'),
        imgW=float(f('imgW')), imgH=float(f('imgH')), centerX=float(f('centerX')), fitW=float(f('fitW')),
        contentH=float(f('contentH')), gapTop=float(f('gapTop')), gapSide=float(f('gapSide')),
        gapBottom=float(f('gapBottom')), trackW=float(f('trackW')),
        ring=lst('ring'), armL=lst('armL'), armR=lst('armR'))
data['shapes'] = shapes
data['stage_shapes'] = {str(k): v for k, v in parse_int_map(re.search(r'kStageShapes\s*=\s*<int, RingShape>\{(.*?)\n\};', rs, re.S).group(1), lambda s: s.strip()).items()}
json.dump(data, open('/home/claude/godot_ufo_bus_jam/data/levels.json', 'w'), separators=(',', ':'))
print({k: (len(v) if hasattr(v, '__len__') else v) for k, v in data.items()})
print(list(shapes), shapes['kRingOval']['imgH'])
